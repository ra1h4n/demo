function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
  /***/
  "./$$_lazy_route_resource lazy recursive":
  /*!******************************************************!*\
    !*** ./$$_lazy_route_resource lazy namespace object ***!
    \******************************************************/

  /*! no static exports found */

  /***/
  function $$_lazy_route_resourceLazyRecursive(module, exports) {
    function webpackEmptyAsyncContext(req) {
      // Here Promise.resolve().then() is used instead of new Promise() to prevent
      // uncaught exception popping up in devtools
      return Promise.resolve().then(function () {
        var e = new Error("Cannot find module '" + req + "'");
        e.code = 'MODULE_NOT_FOUND';
        throw e;
      });
    }

    webpackEmptyAsyncContext.keys = function () {
      return [];
    };

    webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
    module.exports = webpackEmptyAsyncContext;
    webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/chart-of-account/chart-of-account.component.html":
  /*!*****************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/chart-of-account/chart-of-account.component.html ***!
    \*****************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAccountsChartOfAccountChartOfAccountComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\r\n    <h1>Chart of Accounts</h1>\r\n    <hr>\r\n    <app-tree [treeData]=\"this.AccList\"></app-tree>\r\n\r\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/chart-of-account/tree/tree.component.html":
  /*!**********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/chart-of-account/tree/tree.component.html ***!
    \**********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAccountsChartOfAccountTreeTreeComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ul *ngIf=\"treeData\">\r\n  <li *ngFor=\"let node of treeData\">\r\n    <span *ngIf=\"node.Children != 0\"><b>></b></span>\r\n    <span (click)=\"toggleChild(node)\" style=\"cursor: pointer;\"> {{ node.Data }} </span>\r\n    <app-tree *ngIf=\"node.showChildren\" [treeData]=\"node.Children\"></app-tree>\r\n  </li>\r\n</ul>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/expense/add-expense-type/add-expense-type.component.html":
  /*!*************************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/expense/add-expense-type/add-expense-type.component.html ***!
    \*************************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAccountsExpenseAddExpenseTypeAddExpenseTypeComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\n    <h1>Add New Expense Type</h1>\n    <hr>\n\n    <form (ngSubmit)=\"onSubmit()\" #addCategoryForm=\"ngForm\">\n        <div class=\"row\">\n            <div class=\"col-md-6 offset-3\">\n                <div class=\"form-group\">\n                    <label for=\"ExpenseName\">Expense Name</label>\n                    <input type=\"text\" class=\"form-control\" required [(ngModel)]=\"model.AccountName\" name=\"ExpenseName\"\n                        #ExpenseName=\"ngModel\">\n                </div>\n\n                <button type=\"submit\" class=\"btn btn-success submit\">Submit</button>\n            </div>\n        </div>\n    </form>\n    <hr>\n    <b>List of Expense Type:</b> <br>\n    <span *ngFor=\"let expenseAcc of this.expenseAccList\">{{expenseAcc.ExpenseName}} ||\n    </span>\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/expense/add-expense/add-expense.component.html":
  /*!***************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/expense/add-expense/add-expense.component.html ***!
    \***************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAccountsExpenseAddExpenseAddExpenseComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\n    <h1>Add New Expense</h1>\n    <hr>\n\n    <form (ngSubmit)=\"onSubmit()\" #addExpenseForm=\"ngForm\" autocomplete=\"off\">\n        <div class=\"row\">\n            <div class=\"col-md-6 offset-3\">\n                <div class=\"form-group\">\n                    <label for=\"ExpenseName\">Expense Name</label>\n                    <select class=\"form-control\" name=\"ExpenseName\" #ExpenseName=\"ngModel\" [(ngModel)]=\"model.ExpenseNo\"\n                        (ngModelChange)=\"onChange($event)\" required>\n                        <option *ngFor=\"let type of this.expenseTypes\" value=\"{{type.AccountKey}}\">{{type.AccountName}}\n                        </option>\n                    </select>\n                </div>\n\n                <div class=\"form-group\">\n                    <label for=\"PurchaseDate\">Expense Date</label>\n                    <input type=\"datetime-local\" step=\"1\" class=\"form-control\" required\n                        [(ngModel)]=\"this.PurchaseDateString\" name=\"PurchaseDate\" #PurchaseDate=\"ngModel\">\n                </div>\n\n                <div class=\"form-group\">\n                    <label for=\"PaymentType\">Payment Type</label>\n                    <select class=\"form-control\" name=\"PaymentType\" #PaymentType=\"ngModel\" required\n                        [(ngModel)]=\"model.PaymentType\">\n                        <option value=\"cash\">Cash</option>\n                        <option value=\"cheque\">Cheque</option>\n                        <option value=\"credit\">Accounts Payable</option>\n                    </select>\n                </div>\n\n                <div class=\"form-group\">\n                    <label for=\"Amount\">Amount</label>\n                    <input type=\"number\" class=\"form-control\" required [(ngModel)]=\"model.Amount\" name=\"Amount\"\n                        #Amount=\"ngModel\">\n                </div>\n\n                <div class=\"form-group\">\n                    <label for=\"Particulars\">Particulars</label>\n                    <input type=\"text\" class=\"form-control\" [(ngModel)]=\"model.Particulars\" name=\"Particulars\"\n                        #Particulars=\"ngModel\">\n                </div>\n\n                <button type=\"submit\" class=\"btn btn-success submit\" [disabled]=\"addExpenseForm.invalid\">Submit</button>\n            </div>\n        </div>\n    </form>\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/journal/journal.component.html":
  /*!***********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/journal/journal.component.html ***!
    \***********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAccountsJournalJournalComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\n    <h1>Journal</h1>\n    <hr>\n\n    <form (ngSubmit)=\"onShow()\" #DateRangeForm=\"ngForm\" autocomplete=\"off\">\n\n        <div class=\"form-group row offset-2\">\n            <label for=\"FromDate\" class=\"col-sm-1 col-form-label\">From: </label>\n            <div class=\"col-sm-3\">\n                <input type=\"date\" class=\"form-control\" required [(ngModel)]=\"this.FromDateStr\" name=\"FromDate\">\n            </div>\n\n            <label for=\"ToDate\" class=\"col-sm-1 col-form-label\">Till: </label>\n            <div class=\"col-sm-3\">\n                <input type=\"date\" class=\"form-control\" required [(ngModel)]=\"this.ToDateStr\" name=\"ToDate\">\n            </div>\n\n            <div class=\"col-md-2\">\n                <button type=\"submit\" class=\"btn btn-success submit\">Show</button>\n            </div>\n        </div>\n    </form>\n\n    <table class=\"table table-striped\">\n        <thead>\n            <tr>\n                <div class=\"row\" style=\"font-weight: bold;\">\n                    <div class=\"col-md-3\" style=\"text-align: center;\">Date</div>\n                    <div class=\"col-md-3\">Account Name</div>\n                    <div class=\"col-md-1\">Ref</div>\n                    <div class=\"col-md-1\">Debit</div>\n                    <div class=\"col-md-1\">Credit</div>\n                    <div class=\"col-md-3\">Particulars</div>\n                </div>\n            </tr>\n        </thead>\n        <tbody>\n            <tr *ngFor=\"let model of modelData\">\n                <div class=\"row\">\n                    <div class=\"col-md-3\">{{model[0].TrxDate | date: 'dd MMM, yyyy hh:mm a'}}</div>\n\n                    <div class=\"col-md-6\">\n                        <div class=\"row\" *ngFor=\"let trx of model\">\n                            <div class=\"col-md-6\">{{trx.AccountName}}</div>\n                            <div class=\"col-md-2\">{{trx.AccountNo}}</div>\n                            <div class=\"col-md-2\" style=\"text-align: left;\">\n                                <span\n                                    *ngIf=\"trx.DebitAmount != 0\">{{trx.DebitAmount | currency:'&#2547;':'symbol':'0.0-2'}}</span>\n                            </div>\n                            <div class=\"col-md-2\"><span\n                                    *ngIf=\"trx.CreditAmount != 0\">{{trx.CreditAmount | currency:'&#2547;':'symbol':'0.0-2'}}</span>\n                            </div>\n\n                        </div>\n                    </div>\n                    <div class=\"col-md-3\">{{model[0].Particulars}}</div>\n                </div>\n            </tr>\n        </tbody>\n    </table>\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/report/balance-sheet/balance-sheet.component.html":
  /*!******************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/report/balance-sheet/balance-sheet.component.html ***!
    \******************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAccountsReportBalanceSheetBalanceSheetComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\r\n    <h1>Balance Sheet</h1>\r\n\r\n    <hr>\r\n    <form (ngSubmit)=\"onShow()\" #DateRangeBalanceSheetForm=\"ngForm\" autocomplete=\"off\">\r\n\r\n        <div class=\"form-group row offset-2\">\r\n            <label for=\"FromDate\" class=\"col-sm-1 col-form-label\">From: </label>\r\n            <div class=\"col-sm-3\">\r\n                <input type=\"date\" class=\"form-control\" required [(ngModel)]=\"this.FromDateStr\" name=\"FromDate\">\r\n            </div>\r\n\r\n            <label for=\"ToDate\" class=\"col-sm-1 col-form-label\">Till: </label>\r\n            <div class=\"col-sm-3\">\r\n                <input type=\"date\" class=\"form-control\" required [(ngModel)]=\"this.ToDateStr\" name=\"ToDate\">\r\n            </div>\r\n\r\n            <div class=\"col-md-2\">\r\n                <button type=\"submit\" class=\"btn btn-success submit\">Show</button>\r\n            </div>\r\n        </div>\r\n    </form>\r\n\r\n\r\n    <div class=\"row\">\r\n        <div class=\"col-md-6 hd\">Assets</div>\r\n        <div class=\"col-md-6 hd\">Liabilities & Owner's Equity</div>\r\n    </div>\r\n    <div class=\"row\">\r\n        <div class=\"col-md-6\">\r\n            <table class=\"table table-striped\">\r\n                <thead>\r\n                    <th>Name</th>\r\n                    <th class=\"rt\">Amount</th>\r\n                </thead>\r\n                <tbody>\r\n                    <tr *ngFor=\"let trx of this.modelData[0]\">\r\n                        <td>{{trx.AccountName}}</td>\r\n                        <td class=\"rt\">{{trx.Debit | currency:'&#2547; ':'symbol':'0.0-2'}}</td>\r\n                    </tr>\r\n                </tbody>\r\n            </table>\r\n        </div>\r\n        <div class=\"col-md-6\">\r\n            <table class=\"table table-striped\">\r\n                <thead>\r\n                    <th>Name</th>\r\n                    <th class=\"rt\">Amount</th>\r\n                </thead>\r\n                <tbody>\r\n                    <tr *ngFor=\"let trx of this.modelData[1]\">\r\n                        <td>{{trx.AccountName}}</td>\r\n                        <td class=\"rt\">{{trx.Credit | currency:'&#2547; ':'symbol':'0.0-2'}}</td>\r\n                    </tr>\r\n                </tbody>\r\n            </table>\r\n        </div>\r\n        <!-- <p>B: {{1984516 | currency:'&#2547; ':'symbol':'4.2-2'}}</p> This is just a test -->\r\n    </div>\r\n\r\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/report/cash-ledger/cash-ledger.component.html":
  /*!**************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/report/cash-ledger/cash-ledger.component.html ***!
    \**************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAccountsReportCashLedgerCashLedgerComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\r\n    <h1>Cash Ledger</h1>\r\n    <hr>\r\n    <form (ngSubmit)=\"onShow()\" #DateRangeCashLedgerForm=\"ngForm\" autocomplete=\"off\">\r\n\r\n        <div class=\"form-group row offset-2\">\r\n            <label for=\"FromDate\" class=\"col-sm-1 col-form-label\">From: </label>\r\n            <div class=\"col-sm-3\">\r\n                <input type=\"date\" class=\"form-control\" required [(ngModel)]=\"this.FromDateStr\" name=\"FromDate\">\r\n            </div>\r\n\r\n            <label for=\"ToDate\" class=\"col-sm-1 col-form-label\">Till: </label>\r\n            <div class=\"col-sm-3\">\r\n                <input type=\"date\" class=\"form-control\" required [(ngModel)]=\"this.ToDateStr\" name=\"ToDate\">\r\n            </div>\r\n\r\n            <div class=\"col-md-2\">\r\n                <button type=\"submit\" class=\"btn btn-success submit\">Show</button>\r\n            </div>\r\n        </div>\r\n    </form>\r\n\r\n    <table class=\"table table-striped\">\r\n        <thead>\r\n            <tr>\r\n                <div class=\"row\" style=\"font-weight: bold;\">\r\n                    <div class=\"col-md-3\" style=\"text-align: center;\">Date</div>\r\n                    <div class=\"col-md-3\">Particulars</div>\r\n                    <!-- <div class=\"col-md-2\">Account Name</div> -->\r\n                    <!-- <div class=\"col-md-1\" style=\"text-align: right;\">Ref</div> -->\r\n                    <div class=\"col-md-2\" style=\"text-align: left;\">Debit</div>\r\n                    <div class=\"col-md-2\">Credit</div>\r\n                    <div class=\"col-md-2\">Balance</div>\r\n                </div>\r\n            </tr>\r\n        </thead>\r\n        <tbody>\r\n            <tr *ngFor=\"let trx of modelData\">\r\n                <div class=\"row\">\r\n                    <div class=\"col-md-3\">{{trx.TrxDate | date: 'dd MMM, yyyy hh:mm a'}}</div>\r\n                    <div class=\"col-md-3\">{{trx.Particulars}}</div>\r\n                    <!-- <div class=\"col-md-2\">{{trx.AccountName}}</div> -->\r\n                    <!-- <div class=\"col-md-1\">{{trx.AccountNo}}</div> -->\r\n                    <div class=\"col-md-2\" style=\"text-align: left;\">\r\n                        <span *ngIf=\"trx.DebitAmount != 0\">\r\n                            {{trx.DebitAmount | currency:'&#2547; ':'symbol':'0.0-2'}}\r\n                        </span>\r\n                    </div>\r\n                    <div class=\"col-md-2\">\r\n                        <span *ngIf=\"trx.CreditAmount != 0\">\r\n                            {{trx.CreditAmount | currency:'&#2547; ':'symbol':'0.0-2'}}\r\n                        </span>\r\n                    </div>\r\n                    <div class=\"col-md-2\">\r\n                        <span *ngIf=\"trx.Runningtotal != 0\">\r\n                            {{trx.Runningtotal | currency:'&#2547; ':'symbol':'0.0-2'}}\r\n                        </span>\r\n                    </div>\r\n                </div>\r\n            </tr>\r\n        </tbody>\r\n    </table>\r\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/report/general-ladger/general-ladger.component.html":
  /*!********************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/report/general-ladger/general-ladger.component.html ***!
    \********************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAccountsReportGeneralLadgerGeneralLadgerComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\r\n    <h1>General Ledger</h1>\r\n    <hr>\r\n\r\n    <form (ngSubmit)=\"onShow()\" #DateRangeLedgerForm=\"ngForm\" autocomplete=\"off\">\r\n\r\n        <div class=\"form-group row offset-2\">\r\n            <label for=\"FromDate\" class=\"col-sm-1 col-form-label\">From: </label>\r\n            <div class=\"col-sm-3\">\r\n                <input type=\"date\" class=\"form-control\" required [(ngModel)]=\"this.FromDateStr\" name=\"FromDate\">\r\n            </div>\r\n\r\n            <label for=\"ToDate\" class=\"col-sm-1 col-form-label\">Till: </label>\r\n            <div class=\"col-sm-3\">\r\n                <input type=\"date\" class=\"form-control\" required [(ngModel)]=\"this.ToDateStr\" name=\"ToDate\">\r\n            </div>\r\n\r\n            <div class=\"col-md-2\">\r\n                <button type=\"submit\" class=\"btn btn-success submit\">Show</button>\r\n            </div>\r\n        </div>\r\n    </form>\r\n\r\n    <div class=\"row\">\r\n        <div class=\"col-md-3\">\r\n            <ul>\r\n                <li *ngFor=\"let item of this.listData\">\r\n                    <span (click)=\"changeLedger(item.ID)\" style=\"cursor: pointer;\">{{item.Name}}</span>\r\n                </li>\r\n            </ul>\r\n        </div>\r\n\r\n        <div class=\"col-md-9\">\r\n\r\n            <table class=\"table table-striped\">\r\n                <thead>\r\n                    <tr>\r\n                        <div class=\"row\" style=\"font-weight: bold;\">\r\n                            <div class=\"col-md-3\" style=\"text-align: center;\">Date</div>\r\n                            <div class=\"col-md-3\">Particulars</div>\r\n                            <!-- <div class=\"col-md-2\">Account Name</div> -->\r\n                            <!-- <div class=\"col-md-1\" style=\"text-align: right;\">Ref</div> -->\r\n                            <div class=\"col-md-2\" style=\"text-align: left;\">Debit</div>\r\n                            <div class=\"col-md-2\">Credit</div>\r\n                            <div class=\"col-md-2\">Balance</div>\r\n                        </div>\r\n                    </tr>\r\n                </thead>\r\n                <tbody>\r\n                    <tr *ngFor=\"let trx of modelData\">\r\n                        <div class=\"row\">\r\n                            <div class=\"col-md-3\">{{trx.TrxDate | date: 'dd MMM, yyyy hh:mm a'}}</div>\r\n                            <div class=\"col-md-3\">{{trx.Particulars}}</div>\r\n                            <!-- <div class=\"col-md-2\">{{trx.AccountName}}</div> -->\r\n                            <!-- <div class=\"col-md-1\">{{trx.AccountNo}}</div> -->\r\n                            <div class=\"col-md-2\" style=\"text-align: left;\">\r\n                                <span *ngIf=\"trx.DebitAmount != 0\">\r\n                                    {{trx.DebitAmount | currency:'&#2547; ':'symbol':'0.0-2'}}\r\n                                </span>\r\n                            </div>\r\n                            <div class=\"col-md-2\">\r\n                                <span *ngIf=\"trx.CreditAmount != 0\">\r\n                                    {{trx.CreditAmount | currency:'&#2547; ':'symbol':'0.0-2'}}\r\n                                </span>\r\n                            </div>\r\n                            <div class=\"col-md-2\">\r\n                                <span *ngIf=\"trx.Runningtotal != 0\">\r\n                                    {{trx.Runningtotal | currency:'&#2547; ':'symbol':'0.0-2'}}\r\n                                </span>\r\n                            </div>\r\n                        </div>\r\n                    </tr>\r\n                </tbody>\r\n            </table>\r\n        </div>\r\n    </div>\r\n\r\n   \r\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/report/income-statement/income-statement.component.html":
  /*!************************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/report/income-statement/income-statement.component.html ***!
    \************************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAccountsReportIncomeStatementIncomeStatementComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\r\n    <h1>Income Statement</h1>\r\n    <hr>\r\n    <form (ngSubmit)=\"onShow()\" #DateRangeForm=\"ngForm\" autocomplete=\"off\">\r\n\r\n        <div class=\"form-group row offset-2\">\r\n            <label for=\"FromDate\" class=\"col-sm-1 col-form-label\">From: </label>\r\n            <div class=\"col-sm-3\">\r\n                <input type=\"date\" class=\"form-control\" required [(ngModel)]=\"this.FromDateStr\" name=\"FromDate\">\r\n            </div>\r\n\r\n            <label for=\"ToDate\" class=\"col-sm-1 col-form-label\">Till: </label>\r\n            <div class=\"col-sm-3\">\r\n                <input type=\"date\" class=\"form-control\" required [(ngModel)]=\"this.ToDateStr\" name=\"ToDate\">\r\n            </div>\r\n\r\n            <div class=\"col-md-2\">\r\n                <button type=\"submit\" class=\"btn btn-success submit\">Show</button>\r\n            </div>\r\n        </div>\r\n    </form>\r\n    <table class=\"table table-striped\">\r\n        <thead>\r\n            <tr>\r\n                <div class=\"row offset-1\" style=\"font-weight: bold;\">\r\n                    <div class=\"col-md-4\" style=\"text-align: left;\">Name</div>\r\n                    <div class=\"col-md-3\">Debit</div>\r\n                    <div class=\"col-md-3\">Credit</div>\r\n                </div>\r\n            </tr>\r\n        </thead>\r\n        <tbody>\r\n            <tr *ngFor=\"let trx of modelData\">\r\n                <div class=\"row offset-1\">\r\n                    <div class=\"col-md-4\" style=\"text-align: left;\">\r\n\r\n                        {{trx.AccountName}}</div>\r\n                    <div class=\"col-md-3\">\r\n                        <span *ngIf=\"trx.Debit != 0\">\r\n                            {{trx.Debit | currency:'&#2547; ':'symbol':'0.0-2'}}\r\n                        </span>\r\n                    </div>\r\n                    <div class=\"col-md-3\">\r\n                        <span *ngIf=\"trx.Credit != 0\">\r\n                            {{trx.Credit | currency:'&#2547; ':'symbol':'0.0-2'}}\r\n                        </span>\r\n                    </div>\r\n                </div>\r\n            </tr>\r\n        </tbody>\r\n    </table>\r\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/report/trial-balance/trial-balance.component.html":
  /*!******************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/report/trial-balance/trial-balance.component.html ***!
    \******************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAccountsReportTrialBalanceTrialBalanceComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\r\n    <h1>Trial Balance</h1>\r\n    <hr>\r\n\r\n    <form (ngSubmit)=\"onShow()\" #DateRangeForm=\"ngForm\" autocomplete=\"off\">\r\n\r\n        <div class=\"form-group row offset-2\">\r\n            <label for=\"FromDate\" class=\"col-sm-1 col-form-label\">From: </label>\r\n            <div class=\"col-sm-3\">\r\n                <input type=\"date\" class=\"form-control\" required [(ngModel)]=\"this.FromDateStr\" name=\"FromDate\">\r\n            </div>\r\n\r\n            <label for=\"ToDate\" class=\"col-sm-1 col-form-label\">Till: </label>\r\n            <div class=\"col-sm-3\">\r\n                <input type=\"date\" class=\"form-control\" required [(ngModel)]=\"this.ToDateStr\" name=\"ToDate\">\r\n            </div>\r\n\r\n            <div class=\"col-md-2\">\r\n                <button type=\"submit\" class=\"btn btn-success submit\">Show</button>\r\n            </div>\r\n        </div>\r\n    </form>\r\n    \r\n    <table class=\"table table-striped\">\r\n        <thead>\r\n            <tr>\r\n                <div class=\"row offset-1\" style=\"font-weight: bold;\">\r\n                    <div class=\"col-md-4\" style=\"text-align: left;\">Name</div>\r\n                    <div class=\"col-md-3\">Debit</div>\r\n                    <div class=\"col-md-3\">Credit</div>\r\n                </div>\r\n            </tr>\r\n        </thead>\r\n        <tbody>\r\n            <tr *ngFor=\"let trx of modelData\">\r\n                <div class=\"row offset-1\">\r\n                    <div class=\"col-md-4\" style=\"text-align: left;\">{{trx.AccountName}}</div>\r\n                    <div class=\"col-md-3\">\r\n                        <span *ngIf=\"trx.Debit !=0\">{{trx.Debit | currency:'&#2547; ':'symbol':'0.0-2'}}\r\n                        </span>\r\n                    </div>\r\n                    <div class=\"col-md-3\">\r\n                        <span *ngIf=\"trx.Credit !=0\">{{trx.Credit | currency:'&#2547; ':'symbol':'0.0-2'}}</span>\r\n                    </div>\r\n                </div>\r\n            </tr>\r\n        </tbody>\r\n    </table>\r\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
  /*!**************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
    \**************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAppComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"wrapper\" *ngIf=\"this.isLoggedIn\">\r\n  <div class=\"left\">\r\n    <app-side-menu></app-side-menu>\r\n  </div>\r\n  <div class=\"right\">\r\n    <router-outlet></router-outlet>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"jumbotron\" *ngIf=\"!this.isLoggedIn\">\r\n  <h1 style=\"text-align: center;\">Login</h1>\r\n  <hr />\r\n  <form\r\n    (ngSubmit)=\"onSubmit()\"\r\n    #LoginForm=\"ngForm\"\r\n    autocomplete=\"off\"\r\n  >\r\n    <div class=\"row\">\r\n      <div class=\"col-md-4 offset-4\">\r\n        <div class=\"form-group\">\r\n          <label for=\"UserName\">User Name</label>\r\n          <input\r\n            type=\"text\"\r\n            class=\"form-control\"\r\n            required\r\n            [(ngModel)]=\"this.username\"\r\n            name=\"UserName\"\r\n            #UserName=\"ngModel\"\r\n            placeholder=\"Type username\"\r\n          />\r\n        </div>\r\n\r\n        <div class=\"form-group\">\r\n          <label for=\"Password\">Password</label>\r\n          <input\r\n            type=\"password\"\r\n            accept=\"image/png, image/jpeg\"\r\n            class=\"form-control\"\r\n            [(ngModel)]=\"this.password\"\r\n            name=\"Password\"\r\n            #Password=\"ngModel\"\r\n            placeholder=\"Type password\"\r\n          />\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"col-md-4 offset-4\">\r\n        <button\r\n          type=\"submit\"\r\n          class=\"btn btn-lg btn-success submit\"\r\n          [disabled]=\"LoginForm.invalid\"\r\n        >\r\n          Submit\r\n        </button>\r\n      </div>\r\n    </div>\r\n  </form>\r\n</div>\r\n\r\n<!-- <app-side-menu></app-side-menu>\r\n<div>This is my life</div>\r\n<router-outlet></router-outlet> -->\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/banks/add-new-bank/add-new-bank.component.html":
  /*!******************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/banks/add-new-bank/add-new-bank.component.html ***!
    \******************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppBanksAddNewBankAddNewBankComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\n    <h1>Add New Bank</h1>\n    <hr>\n    <form (ngSubmit)=\"onSubmit()\" #addBankForm=\"ngForm\">\n        <div class=\"row\">\n            <div class=\"col-md-6\">\n                <div class=\"form-group\">\n\n                    <label for=\"BankName\">Bank Name</label>\n                    <input type=\"text\" class=\"form-control\" required [(ngModel)]=\"model.BankName\" name=\"BankName\"\n                        #BankName=\"ngModel\">\n\n                </div>\n\n                <div class=\"form-group\">\n\n                    <label for=\"AccountName\">Account Name</label>\n                    <input type=\"text\" class=\"form-control\" required [(ngModel)]=\"model.AccountName\" name=\"AccountName\"\n                        #AccountName=\"ngModel\">\n                </div>\n            </div>\n\n            <div class=\"col-md-6\">\n                <div class=\"form-group\">\n                    <label for=\"AccountNo\">Account No</label>\n                    <input type=\"text\" class=\"form-control\" required [(ngModel)]=\"model.AccountNo\" name=\"AccountNo\"\n                        #AccountNo=\"ngModel\">\n                </div>\n\n                <div class=\"form-group\">\n                    <label for=\"Branch\">Branch</label>\n                    <input type=\"text\" class=\"form-control\" required [(ngModel)]=\"model.Branch\" name=\"Branch\"\n                        #Branch=\"ngModel\">\n                </div>\n            </div>\n\n            <div class=\"col-md-12\">\n                <button type=\"submit\" class=\"btn btn-success submit\">Submit</button>\n            </div>\n        </div>\n    </form>\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/banks/manage-banks/manage-banks.component.html":
  /*!******************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/banks/manage-banks/manage-banks.component.html ***!
    \******************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppBanksManageBanksManageBanksComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\n    <h1>Manage Customers</h1>\n    <hr>\n    <table class=\"table table-hover table-striped\">\n        <thead>\n            <tr>\n                <th>Bank Name</th>\n                <th>Account Name</th>\n                <th>Account No</th>\n                <th>Branch</th>\n                <!-- <th>Bank Sign</th> -->\n                <th><a routerLink=\"/banks/add\"><i class=\"fa fa-plus\"></i></a></th>\n            </tr>\n        </thead>\n        <tbody>\n            <tr *ngFor=\"let model of modelData\">\n                <td>{{model.BankName}}</td>\n                <td>{{model.AccountName}}</td>\n                <td>{{model.AccountNo}}</td>\n                <td>{{model.Branch}}</td>\n                <!-- <td>{{model.BankSign}}</td> -->\n                <td>\n                    <button (click)=\"editBank(model.BankCode)\"><i class=\"fa fa-edit\"></i></button>\n                    <button (click)=\"deleteBank(model.BankCode)\"><i class=\"fa fa-trash\"></i></button>\n                </td>\n            </tr>\n        </tbody>\n    </table>\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/customers/add-customer/add-customer.component.html":
  /*!**********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/customers/add-customer/add-customer.component.html ***!
    \**********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCustomersAddCustomerAddCustomerComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\n    <h1>Add New Customer</h1>\n    <hr>\n    <form (ngSubmit)=\"onSubmit()\" #addCustomerForm=\"ngForm\" autocomplete=\"off\">\n        <div class=\"row\">\n            <div class=\"col-md-6\">\n                <div class=\"form-group\">\n\n                    <label for=\"CustomerName\">Customer Name</label>\n                    <input type=\"text\" class=\"form-control\" required [(ngModel)]=\"model.CustomerName\"\n                        name=\"CustomerName\" #CustomerName=\"ngModel\">\n\n                </div>\n\n                <div class=\"form-group\">\n\n                    <label for=\"CustomerMobile\">Mobile No</label>\n                    <input type=\"text\" class=\"form-control\" [(ngModel)]=\"model.CustomerMobile\" name=\"CustomerMobile\"\n                        #CustomerMobile=\"ngModel\" required>\n                </div>\n            </div>\n\n            <div class=\"col-md-6\">\n                <div class=\"form-group\">\n                    <label for=\"CustomerAddress\">Customer Address</label>\n                    <input type=\"text\" class=\"form-control\" [(ngModel)]=\"model.CustomerAddress\" name=\"CustomerAddress\"\n                        #CustomerAddress=\"ngModel\">\n                </div>\n\n                <div class=\"form-group\">\n                    <label for=\"CustomerEmail\">Customer Email</label>\n                    <input type=\"text\" class=\"form-control\" [(ngModel)]=\"model.CustomerEmail\" name=\"CustomerEmail\"\n                        #CustomerEmail=\"ngModel\">\n                </div>\n            </div>\n\n            <div class=\"col-md-4 offset-4\">\n                <button type=\"submit\" class=\"btn btn-lg btn-success submit\"\n                    [disabled]=\"addCustomerForm.invalid\">Submit</button>\n            </div>\n        </div>\n    </form>\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/customers/add-warrenty-card/add-warrenty-card.component.html":
  /*!********************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/customers/add-warrenty-card/add-warrenty-card.component.html ***!
    \********************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCustomersAddWarrentyCardAddWarrentyCardComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\r\n  <h1>Add Warrenty Card</h1>\r\n  <hr />\r\n  <form\r\n    (ngSubmit)=\"onSubmit()\"\r\n    #addWarrentyCardForm=\"ngForm\"\r\n    autocomplete=\"off\"\r\n  >\r\n    <div class=\"row\">\r\n      <div class=\"col-md-6 offset-3\">\r\n        <div class=\"form-group\">\r\n          <label for=\"CustomerName\">Customer Name</label>\r\n          <input\r\n            type=\"text\"\r\n            class=\"form-control\"\r\n            required\r\n            [(ngModel)]=\"model.CustomerName\"\r\n            name=\"CustomerName\"\r\n            #CustomerName=\"ngModel\"\r\n          />\r\n        </div>\r\n\r\n        <div class=\"form-group\">\r\n          <label for=\"CustomerEmail\">Customer Warrenty Card</label>\r\n          <input\r\n            type=\"file\"\r\n            accept=\"image/png, image/jpeg\"\r\n            class=\"form-control\"\r\n            [(ngModel)]=\"model.CustomerEmail\"\r\n            name=\"CustomerEmail\"\r\n            #CustomerEmail=\"ngModel\"\r\n          />\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"col-md-4 offset-4\">\r\n        <button\r\n          type=\"submit\"\r\n          class=\"btn btn-lg btn-success submit\"\r\n          [disabled]=\"addWarrentyCardForm.invalid\"\r\n        >\r\n          Submit\r\n        </button>\r\n      </div>\r\n    </div>\r\n  </form>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/customers/manage-customer/manage-customer.component.html":
  /*!****************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/customers/manage-customer/manage-customer.component.html ***!
    \****************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCustomersManageCustomerManageCustomerComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\n    <h1>Manage Customers</h1>\n    <hr>\n    <table class=\"table table-hover table-striped\">\n        <thead>\n            <tr>\n                <th>Customer ID</th>\n                <th>Name</th>\n                <th>Mobile</th>\n                <th>Address</th>\n                <th>Email</th>\n            </tr>\n        </thead>\n        <tbody>\n            <tr *ngFor=\"let model of modelData\">\n                <td>{{model.CustomerCode}}</td>\n                <td>{{model.CustomerName}}</td>\n                <td>{{model.CustomerMobile}}</td>\n                <td>{{model.CustomerAddress}}</td>\n                <td>{{model.CustomerEmail}}</td>\n            </tr>\n        </tbody>\n    </table>\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/dashboard/dashboard.component.html":
  /*!******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/dashboard/dashboard.component.html ***!
    \******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppDashboardDashboardComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\n    <h1 class=\"display-4\">Welcome to ERP for Electronics</h1>\n    <hr>\n    <div class=\"row\">\n\n        <div class=\"col-3 align-items-center\" *ngFor=\"let dash of dashElements\">\n            <div class=\"card text-white bg-info mb-3\">\n                <div class=\"card-body\">\n                    <h5 class=\"card-title\">{{dash.Count}}</h5>\n                    <h6 class=\"card-subtitle mb-2\">{{dash.Name}}</h6>\n                    <!-- <p class=\"card-text\">Some quick example text to build on the card title and make up the bulk of the\n                        card's\n                        content.</p>\n                    <a href=\"#\" class=\"card-link\">Card link</a>\n                    <a href=\"#\" class=\"card-link\">Another link</a> -->\n                </div>\n            </div>\n        </div>\n    </div>\n\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/offers/add-offer/add-offer.component.html":
  /*!*************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/offers/add-offer/add-offer.component.html ***!
    \*************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppOffersAddOfferAddOfferComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\n    <h1>Customer New Offer</h1>\n    <hr>\n\n    <form (ngSubmit)=\"onSubmit()\" #addOfferForm=\"ngForm\" autocomplete=\"off\">\n        <div class=\"row\">\n            <div class=\"col-md-6\">\n                <div class=\"form-group\">\n                    <label for=\"OfferName\">Offer Name</label>\n                    <input type=\"text\" class=\"form-control\" required [(ngModel)]=\"model.OfferName\" name=\"OfferName\"\n                        #OfferName=\"ngModel\">\n                </div>\n\n                <div class=\"form-group\">\n                    <label for=\"StartDate\">Start Date</label>\n                    <input type=\"date\" class=\"form-control\" required [(ngModel)]=\"model.StartDate\" name=\"StartDate\">\n                </div>\n\n                <div class=\"form-group\">\n                    <label for=\"ProductCode\">Product Name</label>\n                    <select class=\"form-control\" [(ngModel)]=\"model.ProductCode\" name=\"ProductCode\">\n                        <option *ngFor=\"let product of this.ProductList\" [value]=\"product.ProductCode\">\n                            {{product.ProductName}}\n                        </option>\n                    </select>\n                </div>\n\n                <!-- <input type=\"date\" class=\"form-control\" required [(ngModel)]=\"this.StartDateStr\" name=\"ToDate\"> -->\n            </div>\n            <div class=\"col-md-6\">\n                <div class=\"form-group\">\n                    <label for=\"OfferDetails\">Offer Details</label>\n                    <input type=\"text\" class=\"form-control\" [(ngModel)]=\"model.OfferDetails\" name=\"OfferDetails\"\n                        #OfferDetails=\"ngModel\">\n                </div>\n\n                <div class=\"form-group\">\n                    <label for=\"EndDate\">End Date</label>\n                    <input type=\"date\" class=\"form-control\" required [(ngModel)]=\"model.EndDate\" name=\"EndDate\">\n                </div>\n\n                <div class=\"form-group\">\n                    <label for=\"OfferAmount\">Offer Amount</label>\n                    <input type=\"number\" class=\"form-control\" required [(ngModel)]=\"model.OfferAmount\"\n                        name=\"OfferAmount\" #OfferAmount=\"ngModel\">\n                </div>\n\n\n            </div>\n            <button type=\"submit\" class=\"btn btn-success submit\" [disabled]=\"addOfferForm.invalid\">Submit</button>\n        </div>\n    </form>\n\n    <hr>\n    <b>List of Offers:</b> <br>\n    <span *ngFor=\"let offer of this.OfferList\">{{offer.OfferName}}: {{offer.ProductCode}}: &#2547;\n        {{offer.OfferAmount}} <br></span>\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/products/add-brand/add-brand.component.html":
  /*!***************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/products/add-brand/add-brand.component.html ***!
    \***************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppProductsAddBrandAddBrandComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\n    <h1>Add New Brand</h1>\n    <hr>\n\n    <form (ngSubmit)=\"onSubmit()\" #addBrandForm=\"ngForm\" autocomplete=\"off\">\n        <div class=\"row\">\n            <div class=\"col-md-6 offset-3\">\n                <div class=\"form-group\">\n                    <label for=\"BrandName\">Brand Name</label>\n                    <input type=\"text\" class=\"form-control\" required [(ngModel)]=\"model.BrandName\" name=\"BrandName\"\n                        #BrandName=\"ngModel\">\n                </div>\n\n                <div class=\"form-group\">\n                    <label for=\"BrandDetails\">Brand Details</label>\n                    <input type=\"text\" class=\"form-control\" [(ngModel)]=\"model.BrandDetails\" name=\"BrandDetails\"\n                        #BrandDetails=\"ngModel\">\n                </div>\n                <button type=\"submit\" class=\"btn btn-success submit\" [disabled]=\"addBrandForm.invalid\">Submit</button>\n            </div>\n        </div>\n    </form>\n\n    <hr>\n    <b>List of Brands:</b> <br>\n    <span *ngFor=\"let brand of this.brandList\">{{brand.BrandName}}</span>\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/products/add-category/add-category.component.html":
  /*!*********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/products/add-category/add-category.component.html ***!
    \*********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppProductsAddCategoryAddCategoryComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\n    <h1>Add New Category</h1>\n    <hr>\n\n    <form (ngSubmit)=\"onSubmit()\" #addCategoryForm=\"ngForm\" autocomplete=\"off\">\n        <div class=\"row\">\n            <div class=\"col-md-6 offset-3\">\n                <div class=\"form-group\">\n                    <label for=\"CategoryName\">Category Name</label>\n                    <input type=\"text\" class=\"form-control\" required [(ngModel)]=\"model.CategoryName\"\n                        name=\"CategoryName\" #CategoryName=\"ngModel\">\n                </div>\n\n                <div class=\"form-group\">\n                    <label for=\"CategoryDetails\">Category Details</label>\n                    <input type=\"text\" class=\"form-control\" [(ngModel)]=\"model.CategoryDetails\" name=\"CategoryDetails\"\n                        #CategoryDetails=\"ngModel\">\n                </div>\n                <button type=\"submit\" class=\"btn btn-success submit\"\n                    [disabled]=\"addCategoryForm.invalid\">Submit</button>\n            </div>\n        </div>\n    </form>\n    <hr>\n    <b>List of Categories:</b> <br>\n    <span *ngFor=\"let category of this.categoryList\">{{category.CategoryName}}</span>\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/products/add-product/add-product.component.html":
  /*!*******************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/products/add-product/add-product.component.html ***!
    \*******************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppProductsAddProductAddProductComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\r\n    <h1>Add New Product</h1>\r\n    <hr>\r\n    <form (ngSubmit)=\"onSubmit()\" #addProductForm=\"ngForm\" autocomplete=\"off\">\r\n        <div class=\"row\">\r\n\r\n            <div class=\"col-md-2 offset-2\">\r\n                <div class=\"form-group\">\r\n                    <label for=\"ProductSupplier\">Supplier</label>\r\n                    <select class=\"form-control\" [(ngModel)]=\"model.ProductSupplier\" name=\"ProductSupplier\"\r\n                        #ProductSupplier=\"ngModel\" (ngModelChange)=\"onSupplierChange($event)\" required>\r\n                        <option *ngFor=\"let supplier of this.Suppliers\" [value]=\"supplier.SupplierCode\">\r\n                            {{supplier.SupplierName}}\r\n                        </option>\r\n                    </select>\r\n                </div>\r\n            </div>\r\n\r\n            <div class=\"col-md-4\">\r\n                <div class=\"form-group\">\r\n                    <label for=\"ProductName\">Product Name</label>\r\n                    <input type=\"text\" class=\"form-control\" required [(ngModel)]=\"model.ProductName\" name=\"ProductName\"\r\n                        #ProductName=\"ngModel\">\r\n                </div>\r\n            </div>\r\n\r\n            <div class=\"col-md-2\">\r\n                <div class=\"form-group\">\r\n                    <label for=\"ProductDetails\">Product Description</label>\r\n                    <input type=\"text\" class=\"form-control\" [(ngModel)]=\"model.ProductDetails\" name=\"ProductDetails\"\r\n                        #ProductDetails=\"ngModel\">\r\n                </div>\r\n            </div>\r\n\r\n        </div>\r\n        <div class=\"row\">\r\n            \r\n\r\n            <div class=\"col-md-2 offset-2\">\r\n                <div class=\"form-group\">\r\n                    <label for=\"ProductCategory\">Category</label>\r\n                    <select class=\"form-control\" [(ngModel)]=\"model.ProductCategory\" name=\"ProductCategory\"\r\n                        #ProductCategory=\"ngModel\" required>\r\n                        <option *ngFor=\"let category of this.Categories\" [value]=\"category.CategoryCode\">\r\n                            {{category.CategoryName}}\r\n                        </option>\r\n                    </select>\r\n                </div>\r\n\r\n            </div>\r\n\r\n            \r\n\r\n            <div class=\"col-md-2\">\r\n                <div class=\"form-group\">\r\n                    <label for=\"ProductUnit\">Product Unit</label>\r\n                    <select class=\"form-control\" [(ngModel)]=\"model.ProductUnit\" name=\"ProductUnit\"\r\n                        #ProductUnit=\"ngModel\" required>\r\n                        <option *ngFor=\"let unit of this.ProductUnits\" [value]=\"unit\">\r\n                            {{unit}}\r\n                        </option>\r\n                    </select>\r\n                </div>\r\n            </div>\r\n\r\n            \r\n\r\n            \r\n\r\n            <div class=\"col-md-2\">\r\n                <div class=\"form-group\">\r\n                    <label for=\"ProductSalePrice\">Sell Price (M.R.P.)</label>\r\n                    <input type=\"number\" class=\"form-control\" required [(ngModel)]=\"model.ProductSalePrice\"\r\n                        name=\"ProductSalePrice\" #ProductSalePrice=\"ngModel\">\r\n                </div>\r\n            </div>\r\n            \r\n            \r\n        </div>\r\n        <div class=\"row\">\r\n            <div class=\"col-md-2 offset-2\">\r\n                <div class=\"form-group\">\r\n                    <label for=\"Brand\">Brand</label>\r\n                    <select class=\"form-control\" [(ngModel)]=\"model.ProductBrand\" name=\"ProductBrand\"\r\n                        #ProductBrand=\"ngModel\" required>\r\n                        <option *ngFor=\"let brand of this.Brands\" [value]=\"brand.BrandCode\">\r\n                            {{brand.BrandName}}\r\n                        </option>\r\n                    </select>\r\n                </div>\r\n            </div>\r\n            <div class=\"col-md-2\">\r\n                <div class=\"form-group\">\r\n                    <label for=\"CommissionType\">Commission Type</label>\r\n                    <select class=\"form-control\" name=\"CommissionType\" [(ngModel)]=\"this.commissionType\"\r\n                        #CommissionType=\"ngModel\" (ngModelChange)=\"commissionTypeChange($event)\" required>\r\n                        <option value=\"percentage\">\r\n                            Percentage(%)\r\n                        </option>\r\n                        <option value=\"rawAmount\">\r\n                            Amount(&#2547;)\r\n                        </option>\r\n                    </select>\r\n                </div>\r\n            </div>\r\n            <div class=\"col-md-2\">\r\n                <div class=\"form-group\">\r\n                    <label for=\"CommissionAmount\">Commission Amount</label>\r\n                    <input type=\"number\" class=\"form-control\" required [(ngModel)]=\"this.commissionAmount\"\r\n                        name=\"CommissionAmount\" #CommissionAmount=\"ngModel\"\r\n                        (ngModelChange)=\"commissionAmountChange($event)\">\r\n                </div>\r\n            </div>\r\n\r\n            <div class=\"col-md-2\">\r\n                <div class=\"form-group\">\r\n                    <label for=\"ProductPurchasePrice\">Purchase Price</label>\r\n                    <input type=\"number\" class=\"form-control\" required [(ngModel)]=\"model.ProductPurchasePrice\"\r\n                        name=\"ProductPurchasePrice\" #ProductPurchasePrice=\"ngModel\" readonly>\r\n                </div>\r\n            </div>\r\n\r\n\r\n\r\n            <div class=\"col-md-4 offset-4\">\r\n                <button type=\"submit\" class=\"btn btn-lg btn-success submit\"\r\n                    [disabled]=\"addProductForm.invalid\">Submit</button>\r\n            </div>\r\n        </div>\r\n    </form>\r\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/products/manage-products/manage-products.component.html":
  /*!***************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/products/manage-products/manage-products.component.html ***!
    \***************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppProductsManageProductsManageProductsComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\n    <h1>Manage Products</h1>\n    <hr>\n    <table class=\"table table-hover table-striped\">\n        <thead>\n            <tr>\n                <th>Name</th>\n                <th>Description</th>\n                <th>Unit</th>\n                <!-- <th>Purchase Price</th> -->\n                <th>Sell Price (MRP)</th>\n                <!-- <th>Bank Sign</th> -->\n                <th><a routerLink=\"/products/add\"><i class=\"fa fa-plus\"></i></a></th>\n            </tr>\n        </thead>\n        <tbody>\n            <tr *ngFor=\"let model of modelData\">\n                <td>{{model.ProductName}}</td>\n                <td>{{model.ProductDetails}}</td>\n                <td>{{model.ProductUnit}}</td>\n                <!-- <td>{{model.ProductPurchasePrice}}</td> -->\n                <td>{{model.ProductSalePrice}}</td>\n                <td>\n                    <button (click)=\"editProduct(model.ProductCode)\"><i class=\"fa fa-edit\"></i></button>\n                    <button (click)=\"deleteProduct(model.ProductCode)\"><i class=\"fa fa-trash\"></i></button>\n                </td>\n            </tr>\n        </tbody>\n    </table>\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/purchases/add-new-batch/add-new-batch.component.html":
  /*!************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/purchases/add-new-batch/add-new-batch.component.html ***!
    \************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPurchasesAddNewBatchAddNewBatchComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\r\n  <h1>Add New LOT</h1>\r\n  <hr />\r\n\r\n  <form (ngSubmit)=\"onSubmit()\" #addBatchForm=\"ngForm\" autocomplete=\"off\">\r\n    <div class=\"row\">\r\n      <div class=\"col-md-3 offset-3\">\r\n        <div class=\"form-group\">\r\n          <label for=\"BatchName\">LOT Name</label>\r\n          <input type=\"text\" class=\"form-control\" required [(ngModel)]=\"model.BatchName\" name=\"BatchName\"\r\n            #BatchName=\"ngModel\" />\r\n        </div>\r\n        <div class=\"row no-gutters\">\r\n          <div class=\"col-md-6\">\r\n            <div class=\"form-group\">\r\n              <label for=\"StartDate\">Start Date</label>\r\n              <input type=\"date\" class=\"form-control\" required [(ngModel)]=\"model.StartDate\" name=\"StartDate\" />\r\n            </div>\r\n          </div>\r\n          <div class=\"col-md-6\">\r\n            <div class=\"form-group\">\r\n              <label for=\"EndDate\">End Date</label>\r\n              <input type=\"date\" class=\"form-control\" required [(ngModel)]=\"model.EndDate\" name=\"EndDate\" />\r\n            </div>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"form-group\">\r\n          <label for=\"ProductCode\">Product Name</label>\r\n          <ng-select class=\"form-control dropdown\" [items]=\"this.ProductList\" bindLabel=\"ProductName\" autofocus\r\n            bindValue=\"ProductCode\" [(ngModel)]=\"this.model.ProductCode\" name=\"ProductCode\"\r\n            (ngModelChange)=\"onProductChange($event)\">\r\n          </ng-select>\r\n          <!-- <select\r\n            class=\"form-control\"\r\n            [(ngModel)]=\"model.ProductCode\"\r\n            name=\"ProductCode\"\r\n            (ngModelChange)=\"onProductChange($event)\"\r\n          >\r\n            <option\r\n              *ngFor=\"let product of this.ProductList\"\r\n              [value]=\"product.ProductCode\"\r\n            >\r\n              {{ product.ProductName }}\r\n            </option>\r\n          </select> -->\r\n        </div>\r\n\r\n        <!-- <input type=\"date\" class=\"form-control\" required [(ngModel)]=\"this.StartDateStr\" name=\"ToDate\"> -->\r\n      </div>\r\n      <div class=\"col-md-3\">\r\n        <div class=\"form-group\">\r\n          <label for=\"BatchDetails\">LOT Details</label>\r\n          <input type=\"text\" class=\"form-control\" [(ngModel)]=\"model.BatchDetails\" name=\"BatchDetails\"\r\n            #BatchDetails=\"ngModel\" />\r\n        </div>\r\n\r\n        <div class=\"row no-gutters\">\r\n          <div class=\"col-md-6\">\r\n            <div class=\"form-group\">\r\n              <label for=\"MRP\">Base Price</label>\r\n              <input type=\"number\" class=\"form-control border border-danger\" required readonly\r\n                [(ngModel)]=\"this.productSalePrice\" name=\"ProductSalePrice\" #ProductSalePrice=\"ngModel\" />\r\n            </div>\r\n          </div>\r\n          <div class=\"col-md-6\" style=\"padding-left: 10px;\">\r\n            <div class=\"form-group\">\r\n              <label for=\"MRP\">\r\n                Price\r\n              </label>\r\n              <input type=\"number\" class=\"form-control border border-success\" required readonly\r\n                [(ngModel)]=\"this.productPurchasePrice\" name=\"ProductPurchasePrice\" #ProductPurchasePrice=\"ngModel\" />\r\n            </div>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"row no-gutters\">\r\n          <div class=\"col-md-6\">\r\n            <div class=\"form-group\">\r\n              <label for=\"CommissionType\">Commission</label>\r\n              <select class=\"form-control\" name=\"CommissionType\" [(ngModel)]=\"this.commissionType\"\r\n                #CommissionType=\"ngModel\" (ngModelChange)=\"commissionTypeChange($event)\" required>\r\n                <option value=\"percentage\">\r\n                  ( % )\r\n                </option>\r\n                <option value=\"rawAmount\">\r\n                  ( &#2547; )\r\n                </option>\r\n              </select>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"col-md-6\">\r\n            <div class=\"form-group\">\r\n              <label for=\"CommissionAmount\">&#2547;</label>\r\n              <input type=\"number\" class=\"form-control\" required [(ngModel)]=\"model.CommissionAmount\"\r\n                name=\"CommissionAmount\" #CommissionAmount=\"ngModel\" (ngModelChange)=\"commissionAmountChange()\" />\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"col-md-4 offset-4\">\r\n        <button type=\"submit\" class=\"btn btn-lg btn-success submit\" [disabled]=\"addBatchForm.invalid\">\r\n          Submit\r\n        </button>\r\n      </div>\r\n    </div>\r\n  </form>\r\n\r\n  <hr />\r\n  <b>List of LOT(s):</b> <br />\r\n  <span *ngFor=\"let batch of this.BatchList\">{{ batch.BatchName }}: {{ batch.ProductCode }}: &#2547;\r\n    {{ batch.CommissionAmount }} <br /></span>\r\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/purchases/add-purchase/add-purchase.component.html":
  /*!**********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/purchases/add-purchase/add-purchase.component.html ***!
    \**********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPurchasesAddPurchaseAddPurchaseComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\n    <h1>Add New Purchase</h1>\n    <hr>\n    <form (ngSubmit)=\"onSubmit()\" #addPurchaseForm=\"ngForm\" autocomplete=\"off\" class=\"bg-info text-light\">\n        <div class=\"row\">\n            <div class=\"col-md-4\">\n                <div class=\"form-group\">\n                    <label for=\"PurchaseDate\">Purchase Date</label>\n                    <input type=\"datetime-local\" class=\"form-control\" [(ngModel)]=\"this.PurchaseDateString\"\n                        name=\"PurchaseDate\" #PurchaseDate=\"ngModel\" required>\n                </div>\n            </div>\n\n            <div class=\"col-md-2\">\n                <div class=\"form-group\">\n                    <label for=\"PaymentType\">Payment Type</label>\n                    <select class=\"form-control\" name=\"PaymentType\" #PaymentType=\"ngModel\" required\n                        [(ngModel)]=\"modelHead.PaymentType\">\n                        <option value=\"cash\">Cash</option>\n                        <option value=\"cheque\">Cheque</option>\n                        <option value=\"credit\">Accounts Payable</option>\n                    </select>\n                </div>\n            </div>\n            <div class=\"col-md-3\">\n                <div class=\"form-group\">\n                    <label for=\"InvoiceID\">InvoiceID</label>\n                    <input type=\"text\" class=\"form-control\" required [(ngModel)]=\"modelHead.InvoiceID\" name=\"InvoiceID\"\n                        #InvoiceID=\"ngModel\" placeholder=\"Supplier invoice ID\">\n                </div>\n            </div>\n            <div class=\"col-md-3\">\n                <div class=\"form-group\">\n                    <label for=\"Details\">Details</label>\n                    <input type=\"text\" class=\"form-control\" [(ngModel)]=\"modelHead.Details\" name=\"Details\"\n                        #Details=\"ngModel\" placeholder=\"(Optional)\">\n                </div>\n            </div>\n        </div>\n\n        <table class=\"table table-striped table-secondary\">\n            <tbody>\n                <tr *ngFor=\"let model of models; let i = index\">\n                    <td>\n                        <div class=\"row\">\n                            <div class=\"col-1\">\n                                <label for=\"Company\">Supplier:</label>\n                            </div>\n                            <div class=\"col-3\">\n                                <select class=\"form-control\" [(ngModel)]=\"model.Company\" name=\"{{i}}Company\"\n                                    (change)=\"onSupplierChange($event.target.value, i)\" required>\n                                    <option *ngFor=\"let supplier of this.Suppliers[i]\" [value]=\"supplier.SupplierCode\">\n                                        {{supplier.SupplierName}}\n                                    </option>\n                                </select>\n                            </div>\n                            <!-- Brand was here -->\n                            <div class=\"col-1\">\n                                <label for=\"Product\">Product:</label>\n                            </div>\n                            <div class=\"col-6\">\n                                <select class=\"form-control\" [(ngModel)]=\"model.ProductName\" name=\"{{i}}Product\"\n                                    (change)=\"OnProductSelect($event.target.value, i)\" required>\n                                    <option *ngFor=\"let product of this.ProductNames[i]\" [value]=\"product.ProductCode\">\n                                        {{product.ProductName}}\n                                    </option>\n                                </select>\n                            </div>\n                            <div class=\"col-1\" style=\"text-align: right;\">\n                                <span title=\"Remove this product\" (click)=\"removeRow(i)\"\n                                    class=\"btn btn-sm btn-outline-danger\" style=\"cursor: pointer;\"><i\n                                        class=\"fa fa-trash\"></i>\n                                </span>\n                            </div>\n                        </div>\n\n                        <div class=\"row\">\n                            <div class=\"col-1\">\n                                <label for=\"Category\">Category:</label>\n                            </div>\n                            <div class=\"col-3\">\n                                <select class=\"form-control\" [(ngModel)]=\"model.Category\" name=\"{{i}}Category\"\n                                    (change)=\"onCategoryChange($event.target.value, i)\" required>\n                                    <option *ngFor=\"let category of this.Categories[i]\" [value]=\"category.CategoryCode\">\n                                        {{category.CategoryName}}\n                                    </option>\n                                </select>\n                            </div>\n                            <div class=\"col-1\">\n                                <label for=\"BatchNo\">Lot No:</label>\n                            </div>\n                            <div class=\"col-3\">\n                                <div class=\"row\">\n                                    <div class=\"col-8\">\n                                        <select class=\"form-control\" [(ngModel)]=\"model.BatchNo\" name=\"{{i}}BatchNo\"\n                                            (change)=\"onBatchChange($event.target.value, i)\" required>\n                                            <option *ngFor=\"let batch of this.Batches[i]\" [value]=\"batch.BatchCode\">\n                                                {{batch.BatchName}}\n                                            </option>\n                                        </select>\n                                    </div>\n\n                                    <div class=\"col-4\">\n                                        <span (click)=\"addLOT(addPurchaseForm)\" class=\"btn btn-sm btn-outline-primary\"\n                                            style=\"cursor: pointer; padding-left: 5px;\" title=\"Add a lot\"><i\n                                                class=\"fa fa-plus\"></i>\n                                        </span>\n                                    </div>\n                                </div>\n\n\n                            </div>\n                            <!-- <div class=\"col-1\" style=\"text-align: left;\">\n                                \n                            </div> -->\n                            <div class=\"col-1\">\n                                <label for=\"SaleRate\">Price:</label>\n                            </div>\n                            <div class=\"col-2\">\n                                <input type=\"number\" class=\"form-control\" [(ngModel)]=\"model.Rate\" name=\"{{i}}SaleRate\"\n                                    readonly>\n                            </div>\n\n\n                        </div>\n\n                        <div class=\"row\">\n                            <div class=\"col-1\">\n                                <label for=\"Brand\">Brand:</label>\n                            </div>\n                            <div class=\"col-3\">\n                                <select class=\"form-control\" [(ngModel)]=\"model.Brand\" name=\"{{i}}Brand\"\n                                    (change)=\"onBrandChange($event.target.value, i)\" required>\n                                    <option *ngFor=\"let brand of this.Brands[i]\" [value]=\"brand.BrandCode\">\n                                        {{brand.BrandName}}\n                                    </option>\n                                </select>\n                            </div>\n\n                            <div class=\"col-1\">\n                                <label for=\"Quantity\">Quantity:</label>\n                            </div>\n                            <div class=\"col-2\">\n                                <input type=\"number\" class=\"form-control\" required [(ngModel)]=\"model.Quantity\"\n                                    name=\"{{i}}Quantity\" placeholder=\"0\" (ngModelChange)=\"updateTotal(i)\">\n                            </div>\n                            <div class=\"col-1\"></div>\n                            <div class=\"col-1\">\n                                <label for=\"Total\"><b>Total:</b></label>\n                            </div>\n                            <!-- Total -->\n                            <div class=\"col-2\">\n                                <input type=\"number\" class=\"form-control\" [(ngModel)]=\"model.Total\" name=\"{{i}}Total\"\n                                    readonly>\n                            </div>\n                        </div>\n                    </td>\n                </tr>\n\n                <tr>\n                    <div class=\"row\">\n                        <div class=\"col-md-3\">\n                            <div (click)=\"addRow()\" class=\"btn btn-outline-success\"\n                                style=\"cursor: pointer; margin-left: 20px;\">\n                                <i class=\"fa fa-plus\"> Add Another Product</i>\n                            </div>\n                        </div>\n                        <div class=\"col-md-9\" style=\"text-align: right; padding-right: 50px;\">Total:\n                            {{grandTotalInForm}} </div>\n                    </div>\n                </tr>\n            </tbody>\n        </table>\n\n        <div class=\"col-md-12 bg-light\">\n            <div class=\"col-md-4 offset-4\" style=\"padding-top: 10px; padding-bottom: 10px;\">\n                <button type=\"submit\" [disabled]=\"addPurchaseForm.invalid\"\n                    class=\"btn btn-lg btn-success submit\">Submit</button>\n            </div>\n        </div>\n\n    </form>\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/sales/add-sale/add-sale.component.html":
  /*!**********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sales/add-sale/add-sale.component.html ***!
    \**********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSalesAddSaleAddSaleComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\n    <h1>Add New Sale</h1>\n    <hr>\n    <form (ngSubmit)=\"onSubmit()\" #addSaleForm=\"ngForm\" autocomplete=\"off\" class=\"bg-info text-light\">\n        <div class=\"row align-self-center\">\n            <div class=\"col-md-1\"></div>\n            <div class=\"col-md-3\">\n                <div class=\"form-group\">\n                    <label for=\"CustomerName\">Customer Name</label>\n                    <!-- <input type=\"text\" class=\"form-control\" required [(ngModel)]=\"modelHead.CustomerName\"\n                        name=\"CustomerName\" #CustomerName=\"ngModel\"> -->\n                    <div class=\"row no-gutters align-items-center\">\n                        <div class=\"col-md-9\">\n                            <select class=\"form-control\" [(ngModel)]=\"modelHead.CustomerName\" name=\"CustomerName\"\n                                required>\n                                <option *ngFor=\"let customer of this.CustomerList\" [value]=\"customer.CustomerCode\">\n                                    {{customer.CustomerName}} :: {{customer.CustomerMobile}}\n                                </option>\n                            </select>\n                        </div>\n                        <div class=\"col-md-3\" style=\"padding-left: 10px;\">\n                            <span (click)=\"addCustomer()\" class=\"btn btn-sm btn-outline-dark btn-light\"\n                                style=\"cursor: pointer; padding-left: 5px;\" title=\"Add New Customer\"><i\n                                    class=\"fa fa-plus\"></i>\n                            </span>\n                        </div>\n                    </div>\n\n                </div>\n            </div>\n\n            <div class=\"col-md-2\">\n                <div class=\"form-group\">\n                    <label for=\"PaymentType\">Payment Type</label>\n                    <select class=\"form-control\" name=\"PaymentType\" #PaymentType=\"ngModel\" required\n                        [(ngModel)]=\"modelHead.PaymentType\">\n                        <option value=\"cash\">Cash</option>\n                        <option value=\"cheque\">Cheque</option>\n                        <option value=\"credit\">Accounts Receivable</option>\n                    </select>\n                </div>\n            </div>\n\n            <div class=\"col-md-3\">\n                <div class=\"form-group\">\n                    <label for=\"SaleDate\">Date</label>\n                    <input type=\"datetime-local\" class=\"form-control no-spinner\" required [(ngModel)]=\"SaleDateString\"\n                        name=\"SaleDate\" #SaleDate=\"ngModel\">\n                </div>\n            </div>\n\n            <div class=\"col-md-2\">\n                <div class=\"form-group\">\n                    <label for=\"SaleDetails\">Sale Details</label>\n                    <input type=\"text\" class=\"form-control\" [(ngModel)]=\"modelHead.SaleDetails\" name=\"SaleDetails\"\n                        #SaleDetails=\"ngModel\">\n                </div>\n            </div>\n        </div>\n        <table class=\"table table-striped table-secondary\">\n            <tbody>\n                <tr *ngFor=\"let model of models; let i = index\">\n                    <td>\n                        <small>\n                            <div class=\"row align-items-center no-gutters\">\n                                <div class=\"col-1\">\n                                    <label for=\"Company\">Supplier:</label>\n                                </div>\n                                <div class=\"col-2\">\n                                    <select class=\"form-control form-control-sm\" [(ngModel)]=\"model.Company\"\n                                        name=\"{{i}}Company\" (change)=\"onSupplierChange($event.target.value, i)\"\n                                        required>\n                                        <option *ngFor=\"let supplier of this.Suppliers[i]\"\n                                            [value]=\"supplier.SupplierCode\">\n                                            {{supplier.SupplierName}}\n                                        </option>\n                                    </select>\n                                </div>\n                                <div class=\"col-1\">\n                                    <label for=\"Product\">Product:</label>\n                                </div>\n                                <div class=\"col-2\">\n                                    <select class=\"form-control form-control-sm\" [(ngModel)]=\"model.Product\"\n                                        name=\"{{i}}Product\" (change)=\"onProductSelect($event.target.value, i)\" required>\n                                        <option *ngFor=\"let product of this.Products[i]\" [value]=\"product.ProductCode\">\n                                            {{product.ProductName}}\n                                        </option>\n                                    </select>\n                                </div>\n                                <div class=\"col-1\">\n                                    <!-- <label for=\"SaleQuantity\">Quantity:</label> -->\n                                </div>\n                                <div class=\"col-1\">\n                                    <!-- <input type=\"number\" class=\"form-control\" required [(ngModel)]=\"model.SaleQuantity\"\n                                    name=\"{{i}}SaleQuantity\" placeholder=\"0\" (ngModelChange)=\"updateTotal(i)\"> -->\n                                </div>\n\n\n                                <div class=\"col-1\">\n                                    <label for=\"SaleRate\">MRP:</label>\n                                </div>\n                                <div class=\"col-2\">\n                                    <input type=\"number\" class=\"form-control form-control-sm\"\n                                        [(ngModel)]=\"model.SaleRate\" name=\"{{i}}SaleRate\" readonly>\n\n                                </div>\n                                <div class=\"col-1\" style=\"text-align: right;\">\n                                    <span (click)=\"removeRow(i)\" class=\"btn btn-sm btn-outline-danger\"\n                                        style=\"cursor: pointer;\" title=\"Remove this Product\"><i\n                                            class=\"fa fa-trash\"></i></span>\n                                </div>\n                            </div>\n\n                            <div class=\"row align-items-center no-gutters\">\n                                <div class=\"col-1\">\n                                    <label for=\"Category\">Category:</label>\n                                </div>\n                                <div class=\"col-2\">\n                                    <select class=\"form-control form-control-sm\" [(ngModel)]=\"model.Category\"\n                                        name=\"{{i}}Category\" (change)=\"onCategoryChange($event.target.value, i)\"\n                                        required>\n                                        <option *ngFor=\"let category of this.Categories[i]\"\n                                            [value]=\"category.CategoryCode\">\n                                            {{category.CategoryName}}\n                                        </option>\n                                    </select>\n                                </div>\n                                <div class=\"col-1\">\n                                    <label for=\"BatchNo\">Lot No:</label>\n                                </div>\n                                <div class=\"col-2\">\n                                    <select class=\"form-control form-control-sm\" [(ngModel)]=\"model.BatchNo\"\n                                        name=\"{{i}}BatchNo\" (change)=\"onBatchChange($event.target.value, i)\" required>\n                                        <option *ngFor=\"let batch of this.Batches[i]\" [value]=\"batch.Batch\">\n                                            {{batch.BatchName}}\n                                        </option>\n                                    </select>\n                                </div>\n                                <div class=\"col-2\"></div>\n                                <!-- <div class=\"col-1\">\n                                <label for=\"SaleRate\">MRP:</label>\n                            </div>\n                            <div class=\"col-1\">\n                                <input type=\"number\" class=\"form-control\" [(ngModel)]=\"model.SaleRate\"\n                                    name=\"{{i}}SaleRate\" readonly>\n                            </div> -->\n                                <div class=\"col-1\">\n                                    <label for=\"Offers\">Offers:</label>\n                                </div>\n                                <div class=\"col-2\">\n                                    <input type=\"number\" class=\"form-control form-control-sm\" [(ngModel)]=\"model.Offers\"\n                                        name=\"{{i}}Offers\" readonly>\n                                </div>\n                            </div>\n\n                            <div class=\"row align-items-center no-gutters\">\n                                <div class=\"col-1\">\n                                    <label for=\"Brand\">Brand:</label>\n                                </div>\n                                <div class=\"col-2\">\n                                    <select class=\"form-control form-control-sm\" [(ngModel)]=\"model.Brand\"\n                                        name=\"{{i}}Brand\" (change)=\"onBrandChange($event.target.value, i)\" required>\n                                        <option *ngFor=\"let brand of this.Brands[i]\" [value]=\"brand.BrandCode\">\n                                            {{brand.BrandName}}\n                                        </option>\n                                    </select>\n                                </div>\n                                <div class=\"col-1\">\n                                    <label for=\"AvailableQuantity\">Quantity:</label>\n                                </div>\n\n                                <div class=\"col-2\">\n                                    <div class=\"row no-gutters\">\n                                        <div class=\"col-sm-5\" title=\"Quantity\">\n                                            <!-- Quantity -->\n                                            <input type=\"number\" class=\"form-control form-control-sm\" required\n                                                [(ngModel)]=\"model.SaleQuantity\" name=\"{{i}}SaleQuantity\"\n                                                placeholder=\"0\" (ngModelChange)=\"updateTotal(i)\" min=\"1\">\n                                        </div>\n                                        <div class=\"col-sm-2 align-self-center\" style=\"text-align: center;\">/</div>\n                                        <div class=\"col-sm-5\">\n                                            <input type=\"number\" class=\"form-control form-control-sm\"\n                                                [(ngModel)]=\"model.AvailableQuantity\" name=\"{{i}}AvailableQuantity\"\n                                                readonly>\n                                        </div>\n                                    </div>\n                                </div>\n                                <!-- <div class=\"col-1\">\n                                    <label for=\"DiscountInPercent\">Discount:</label>\n                                </div>\n                                <div class=\"col-1\">\n                                    <input type=\"number\" class=\"form-control form-control-sm no-spinner\"\n                                        [(ngModel)]=\"model.DiscountInPercent\" name=\"{{i}}DiscountInPercent\"\n                                        (ngModelChange)=\"updateTotal(i)\" required>\n                                    <span id=\"percent-sign\">%</span>\n                                </div> -->\n                                <div class=\"col-2\"></div>\n                                <div class=\"col-1\">\n                                    <label for=\"Total\">Total:</label>\n                                </div>\n                                <div class=\"col-2\">\n                                    <input type=\"number\" class=\"form-control form-control-sm\" [(ngModel)]=\"model.Total\"\n                                        name=\"{{i}}Total\" readonly>\n                                    <input type=\"hidden\" class=\"form-control\" [(ngModel)]=\"model.PurchaseTotal\"\n                                        name=\"{{i}}PurchaseTotal\" readonly>\n                                </div>\n                            </div>\n\n                        </small>\n                    </td>\n                </tr>\n\n                <tr>\n                    <div class=\"row no-gutters text-success align-items-center\">\n                        <div class=\"col-md-3\">\n                            <div (click)=\"addRow()\" class=\"btn btn-outline-success\"\n                                style=\"cursor: pointer; margin-left: 20px;\">\n                                <i class=\"fa fa-plus\"> Add Another Product</i>\n                            </div>\n                        </div>\n                        <div class=\"col-md-3\"></div>\n                        <div class=\"col-1 col-md-1\">\n                            Discount:\n                        </div>\n                        <div class=\"col-1\">\n                            <input type=\"number\" class=\"form-control form-control-sm no-spinner\"\n                                [(ngModel)]=\"modelHead.DiscountInPercent\" name=\"DiscountInPercent\"\n                                (ngModelChange)=\"updateGrandTotal()\" required>\n                            <span id=\"percent-sign\">%</span>\n                        </div>\n                        <div class=\"col-1 col-md-1\" style=\"text-align: right; padding-right: 50px;\">\n                            <strong>Total:</strong>\n                        </div>\n                        <div class=\"col-md-2\">\n                            {{grandTotalInForm | currency:'&#2547; ':'symbol':'0.0-2'}} </div>\n                    </div>\n                </tr>\n            </tbody>\n        </table>\n        <div class=\"col-md-12 bg-light\">\n            <div class=\"col-md-4 offset-4\" style=\"padding-top: 10px; padding-bottom: 10px;\">\n                <button type=\"submit\" class=\"btn btn-lg btn-success submit\"\n                    [disabled]=\"addSaleForm.invalid\">Submit</button>\n            </div>\n        </div>\n    </form>\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/setup/add-previous-cash/add-previous-cash.component.html":
  /*!****************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/setup/add-previous-cash/add-previous-cash.component.html ***!
    \****************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSetupAddPreviousCashAddPreviousCashComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\r\n    <h1>Adjust Cash</h1>\r\n    <hr>\r\n\r\n    <form (ngSubmit)=\"onSubmit()\" #addCashAdjustmentForm=\"ngForm\" autocomplete=\"off\">\r\n        <div class=\"row\">\r\n            <div class=\"col-md-6 offset-3\">\r\n                <div class=\"form-group\">\r\n                    <label for=\"Amount\">Amount</label>\r\n                    <input type=\"text\" class=\"form-control\" required [(ngModel)]=\"this.amount\" name=\"Amount\"\r\n                        #Amount=\"ngModel\" placeholder=\"Enter the adjustment amount\">\r\n                </div>\r\n\r\n                \r\n            </div>\r\n        </div>\r\n        <div class=\"col-md-4 offset-4\">\r\n            <button type=\"submit\" class=\"btn btn-lg btn-success submit\">Submit</button>\r\n        </div>\r\n    </form>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/setup/add-previous-stock/add-previous-stock.component.html":
  /*!******************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/setup/add-previous-stock/add-previous-stock.component.html ***!
    \******************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSetupAddPreviousStockAddPreviousStockComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\r\n    <h1>Adjust Inventory</h1>\r\n    <hr>\r\n    <form (ngSubmit)=\"onSubmit()\" #addPurchaseForm=\"ngForm\" autocomplete=\"off\" class=\"bg-info text-light\">\r\n        <!-- <div class=\"row\">\r\n            <div class=\"col-md-4\">\r\n                <div class=\"form-group\">\r\n                    <label for=\"PurchaseDate\">Purchase Date</label>\r\n                    <input type=\"datetime-local\" class=\"form-control\" [(ngModel)]=\"this.PurchaseDateString\"\r\n                        name=\"PurchaseDate\" #PurchaseDate=\"ngModel\" required>\r\n                </div>\r\n            </div>\r\n\r\n            <div class=\"col-md-2\">\r\n                <div class=\"form-group\">\r\n                    <label for=\"PaymentType\">Payment Type</label>\r\n                    <select class=\"form-control\" name=\"PaymentType\" #PaymentType=\"ngModel\" required\r\n                        [(ngModel)]=\"modelHead.PaymentType\">\r\n                        <option value=\"cash\">Cash</option>\r\n                        <option value=\"cheque\">Cheque</option>\r\n                        <option value=\"credit\">Accounts Payable</option>\r\n                    </select>\r\n                </div>\r\n            </div>\r\n            <div class=\"col-md-3\">\r\n                <div class=\"form-group\">\r\n                    <label for=\"InvoiceID\">InvoiceID</label>\r\n                    <input type=\"text\" class=\"form-control\" required [(ngModel)]=\"modelHead.InvoiceID\" name=\"InvoiceID\"\r\n                        #InvoiceID=\"ngModel\" placeholder=\"Supplier invoice ID\">\r\n                </div>\r\n            </div>\r\n            <div class=\"col-md-3\">\r\n                <div class=\"form-group\">\r\n                    <label for=\"Details\">Details</label>\r\n                    <input type=\"text\" class=\"form-control\" [(ngModel)]=\"modelHead.Details\" name=\"Details\"\r\n                        #Details=\"ngModel\" placeholder=\"(Optional)\">\r\n                </div>\r\n            </div>\r\n        </div> -->\r\n\r\n        <table class=\"table table-striped table-secondary\">\r\n            <tbody>\r\n                <tr *ngFor=\"let model of models; let i = index\">\r\n                    <td>\r\n                        <div class=\"row\">\r\n                            <div class=\"col-1\">\r\n                                <label for=\"Company\">Supplier:</label>\r\n                            </div>\r\n                            <div class=\"col-3\">\r\n                                <select class=\"form-control\" [(ngModel)]=\"model.Company\" name=\"{{i}}Company\"\r\n                                    (change)=\"onSupplierChange($event.target.value, i)\" required>\r\n                                    <option *ngFor=\"let supplier of this.Suppliers[i]\" [value]=\"supplier.SupplierCode\">\r\n                                        {{supplier.SupplierName}}\r\n                                    </option>\r\n                                </select>\r\n                            </div>\r\n                            <!-- Brand was here -->\r\n                            <div class=\"col-1\">\r\n                                <label for=\"Product\">Product:</label>\r\n                            </div>\r\n                            <div class=\"col-6\">\r\n                                <select class=\"form-control\" [(ngModel)]=\"model.ProductName\" name=\"{{i}}Product\"\r\n                                    (change)=\"OnProductSelect($event.target.value, i)\" required>\r\n                                    <option *ngFor=\"let product of this.ProductNames[i]\" [value]=\"product.ProductCode\">\r\n                                        {{product.ProductName}}\r\n                                    </option>\r\n                                </select>\r\n                            </div>\r\n                            <div class=\"col-1\" style=\"text-align: right;\">\r\n                                <span title=\"Remove this product\" (click)=\"removeRow(i)\"\r\n                                    class=\"btn btn-sm btn-outline-danger\" style=\"cursor: pointer;\"><i\r\n                                        class=\"fa fa-trash\"></i>\r\n                                </span>\r\n                            </div>\r\n                        </div>\r\n\r\n                        <div class=\"row\">\r\n                            <div class=\"col-1\">\r\n                                <label for=\"Category\">Category:</label>\r\n                            </div>\r\n                            <div class=\"col-3\">\r\n                                <select class=\"form-control\" [(ngModel)]=\"model.Category\" name=\"{{i}}Category\"\r\n                                    (change)=\"onCategoryChange($event.target.value, i)\" required>\r\n                                    <option *ngFor=\"let category of this.Categories[i]\" [value]=\"category.CategoryCode\">\r\n                                        {{category.CategoryName}}\r\n                                    </option>\r\n                                </select>\r\n                            </div>\r\n                            <div class=\"col-1\">\r\n                                <label for=\"BatchNo\">Lot No:</label>\r\n                            </div>\r\n                            <div class=\"col-3\">\r\n                                <div class=\"row\">\r\n                                    <div class=\"col-8\">\r\n                                        <select class=\"form-control\" [(ngModel)]=\"model.BatchNo\" name=\"{{i}}BatchNo\"\r\n                                            (change)=\"onBatchChange($event.target.value, i)\" required>\r\n                                            <option *ngFor=\"let batch of this.Batches[i]\" [value]=\"batch.BatchCode\">\r\n                                                {{batch.BatchName}}\r\n                                            </option>\r\n                                        </select>\r\n                                    </div>\r\n\r\n                                    <div class=\"col-4\">\r\n                                        <span (click)=\"addLOT(addPurchaseForm)\" class=\"btn btn-sm btn-outline-primary\"\r\n                                            style=\"cursor: pointer; padding-left: 5px;\" title=\"Add a lot\"><i\r\n                                                class=\"fa fa-plus\"></i>\r\n                                        </span>\r\n                                    </div>\r\n                                </div>\r\n\r\n\r\n                            </div>\r\n                            <!-- <div class=\"col-1\" style=\"text-align: left;\">\r\n                                \r\n                            </div> -->\r\n                            <div class=\"col-1\">\r\n                                <label for=\"SaleRate\">Price:</label>\r\n                            </div>\r\n                            <div class=\"col-2\">\r\n                                <input type=\"number\" class=\"form-control\" [(ngModel)]=\"model.Rate\" name=\"{{i}}SaleRate\"\r\n                                    readonly>\r\n                            </div>\r\n\r\n\r\n                        </div>\r\n\r\n                        <div class=\"row\">\r\n                            <div class=\"col-1\">\r\n                                <label for=\"Brand\">Brand:</label>\r\n                            </div>\r\n                            <div class=\"col-3\">\r\n                                <select class=\"form-control\" [(ngModel)]=\"model.Brand\" name=\"{{i}}Brand\"\r\n                                    (change)=\"onBrandChange($event.target.value, i)\" required>\r\n                                    <option *ngFor=\"let brand of this.Brands[i]\" [value]=\"brand.BrandCode\">\r\n                                        {{brand.BrandName}}\r\n                                    </option>\r\n                                </select>\r\n                            </div>\r\n\r\n                            <div class=\"col-1\">\r\n                                <label for=\"Quantity\">Quantity:</label>\r\n                            </div>\r\n                            <div class=\"col-2\">\r\n                                <input type=\"number\" class=\"form-control\" required [(ngModel)]=\"model.Quantity\"\r\n                                    name=\"{{i}}Quantity\" placeholder=\"0\" (ngModelChange)=\"updateTotal(i)\">\r\n                            </div>\r\n                            <div class=\"col-1\"></div>\r\n                            <div class=\"col-1\">\r\n                                <label for=\"Total\"><b>Total:</b></label>\r\n                            </div>\r\n                            <!-- Total -->\r\n                            <div class=\"col-2\">\r\n                                <input type=\"number\" class=\"form-control\" [(ngModel)]=\"model.Total\" name=\"{{i}}Total\"\r\n                                    readonly>\r\n                            </div>\r\n                        </div>\r\n                    </td>\r\n                </tr>\r\n\r\n                <tr>\r\n                    <div class=\"row\">\r\n                        <div class=\"col-md-3\">\r\n                            <div (click)=\"addRow()\" class=\"btn btn-outline-success\"\r\n                                style=\"cursor: pointer; margin-left: 20px;\">\r\n                                <i class=\"fa fa-plus\"> Add Another Product</i>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-md-9\" style=\"text-align: right; padding-right: 50px;\">Total:\r\n                            {{grandTotalInForm}} </div>\r\n                    </div>\r\n                </tr>\r\n            </tbody>\r\n        </table>\r\n\r\n        <div class=\"col-md-12 bg-light\">\r\n            <div class=\"col-md-4 offset-4\" style=\"padding-top: 10px; padding-bottom: 10px;\">\r\n                <button type=\"submit\" [disabled]=\"addPurchaseForm.invalid\"\r\n                    class=\"btn btn-lg btn-success submit\">Submit</button>\r\n            </div>\r\n        </div>\r\n\r\n    </form>\r\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/side-menu/side-menu.component.html":
  /*!******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/side-menu/side-menu.component.html ***!
    \******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSideMenuSideMenuComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"sidenav\">\r\n    <div class=\"logo\">\r\n        <img src=\"./../Scripts/ClientNgg/assets/logo.png\" alt=\"Logo\" width=\"180px\" />\r\n    </div>\r\n    <a routerLink=\"/dashboard\">\r\n        <i class=\"fa fa-dashboard\"></i>\r\n        Dashboard</a>\r\n\r\n    <button class=\"dropdown-btn\">\r\n        <i class=\"fa fa-money\"></i>\r\n        Sales\r\n        <i class=\"fa fa-caret-down\"></i>\r\n    </button>\r\n    <div class=\"dropdown-container\">\r\n        <a routerLink=\"/sales/add\">Add Sale</a>\r\n        <a routerLink=\"\">Manage Sales</a>\r\n    </div>\r\n\r\n    <button class=\"dropdown-btn\">\r\n        <i class=\"fa fa-handshake-o\"></i>\r\n        Customers\r\n        <i class=\"fa fa-caret-down\"></i>\r\n    </button>\r\n    <div class=\"dropdown-container\">\r\n        <a routerLink=\"/customers/add\">Add Customer</a>\r\n        <a routerLink=\"/customers/manage\">Manage Customers</a>\r\n        <a routerLink=\"/customers/add-warrenty-card\">Add Warrenty Card</a>\r\n        <!-- <a routerLink=\"\">Credit Customer</a> -->\r\n        <!-- <a routerLink=\"\">Paid Customer</a> -->\r\n        <!-- <a routerLink=\"\">Customer Advance</a> -->\r\n    </div>\r\n\r\n    <button class=\"dropdown-btn\">\r\n        <i class=\"fa fa-shopping-basket\"></i>\r\n        Products\r\n        <i class=\"fa fa-caret-down\"></i>\r\n    </button>\r\n    <div class=\"dropdown-container\">\r\n        <!-- <a routerLink=\"\">Company</a> -->\r\n        <a routerLink=\"/products/add-category\">Category</a>\r\n        <a routerLink=\"/products/add-brand\">Brand</a>\r\n        <a routerLink=\"/products/add\">Add Product</a>\r\n        <a routerLink=\"/products/manage\">Manage Products</a>\r\n    </div>\r\n\r\n    <button class=\"dropdown-btn\">\r\n        <i class=\"fa fa-industry\"></i>\r\n        Suppliers\r\n        <i class=\"fa fa-caret-down\"></i>\r\n    </button>\r\n    <div class=\"dropdown-container\">\r\n        <a routerLink=\"/suppliers/add\">Add Supplier</a>\r\n        <a routerLink=\"/suppliers/manage\">Manage Suppliers</a>\r\n        <a routerLink=\"\">Supplier Ledger</a>\r\n        <!-- <a routerLink=\"\">Supplier Advance</a> -->\r\n    </div>\r\n\r\n    <button class=\"dropdown-btn\">\r\n        <i class=\"fa fa-cart-arrow-down\"></i>\r\n        Purchases\r\n        <i class=\"fa fa-caret-down\"></i>\r\n    </button>\r\n    <div class=\"dropdown-container\">\r\n        <a routerLink=\"/purchases/add\">Add Purchase</a>\r\n        <a routerLink=\"/purchases/add-batch\">Batch/Lot No</a>\r\n        <a routerLink=\"\">Manage Purchases</a>\r\n    </div>\r\n\r\n    <a routerLink=\"/stocks/manage\">\r\n        <i class=\"fa fa-briefcase\"></i>\r\n        Stock</a>\r\n\r\n    <button class=\"dropdown-btn\">\r\n        <i class=\"fa fa-reply-all\"></i>\r\n        Returns\r\n        <i class=\"fa fa-caret-down\"></i>\r\n    </button>\r\n    <div class=\"dropdown-container\">\r\n        <button class=\"dropdown-btn\">Add Return\r\n            <i class=\"fa fa-caret-down\"></i>\r\n        </button>\r\n        <div class=\"dropdown-container\">\r\n            <a routerLink=\"\">Sales Return</a>\r\n            <a routerLink=\"\">Supplier Return</a>\r\n        </div>\r\n        <a routerLink=\"\">Sales Return List</a>\r\n        <a routerLink=\"\">Supplier Return List</a>\r\n    </div>\r\n\r\n    <button class=\"dropdown-btn\">\r\n        <i class=\"fa fa-file-text-o\"></i>\r\n        Reports\r\n        <i class=\"fa fa-caret-down\"></i>\r\n    </button>\r\n    <div class=\"dropdown-container\">\r\n        <a routerLink=\"\">Closing</a>\r\n        <a routerLink=\"\">Closing Report</a>\r\n        <a routerLink=\"\">Today's Report</a>\r\n        <a routerLink=\"\">Today's Customer Receipt</a>\r\n        <button class=\"dropdown-btn\">Sales Report\r\n            <i class=\"fa fa-caret-down\"></i>\r\n        </button>\r\n        <div class=\"dropdown-container\">\r\n            <a routerLink=\"\">All Sales</a>\r\n            <a routerLink=\"\">User Wise</a>\r\n            <a routerLink=\"\">Category Wise</a>\r\n            <a routerLink=\"\">Product Wise</a>\r\n        </div>\r\n        <button class=\"dropdown-btn\">Purchase Report\r\n            <i class=\"fa fa-caret-down\"></i>\r\n        </button>\r\n        <div class=\"dropdown-container\">\r\n            <a routerLink=\"\">All Purchases</a>\r\n            <a routerLink=\"\">Category Wise</a>\r\n        </div>\r\n        <a routerLink=\"\">Due Report</a>\r\n        <a routerLink=\"\">Shipping Cost Report</a>\r\n        <a routerLink=\"\">Sales Return</a>\r\n        <a routerLink=\"\">Supplier Return</a>\r\n        <a routerLink=\"\">Tax Report</a>\r\n        <a routerLink=\"\">Profit Report</a>\r\n    </div>\r\n\r\n    <button class=\"dropdown-btn\">\r\n        <i class=\"fa fa-dollar\"></i>\r\n        Accounts\r\n        <i class=\"fa fa-caret-down\"></i>\r\n    </button>\r\n    <div class=\"dropdown-container\">\r\n        <a routerLink=\"/accounts/chart-of-account\">Chart of Account</a>\r\n        <!-- <a routerLink=\"\">Supplier Payment</a> -->\r\n        <!-- <a routerLink=\"\">Customer Receive</a> -->\r\n        <!-- <a routerLink=\"\">Cash Adjustment</a> -->\r\n        <!-- <a routerLink=\"\">Debit Voucher</a> -->\r\n        <!-- <a routerLink=\"\">Credit Voucher</a> -->\r\n        <!-- <a routerLink=\"\">Voucher Approval</a> -->\r\n        <!-- <a routerLink=\"\">Contra Voucher</a> -->\r\n        <a routerLink=\"/accounts/journal\">Journal</a>\r\n        <a routerLink=\"/accounts/report/general-ledger\">General Ledger</a>\r\n        <a routerLink=\"/accounts/report/cash-ledger\">Cash Ledger</a>\r\n        <!-- <a routerLink=\"\">Inventory Ledger</a> -->\r\n        <!-- <a routerLink=\"\">Bank Book</a> -->\r\n        <a routerLink=\"/accounts/report/trial-balance\">Trial Balance</a>\r\n        <a routerLink=\"/accounts/report/income-statement\">Income Statement</a>\r\n        <a routerLink=\"/accounts/report/balance-sheet\">Balance Sheet</a>\r\n        <!-- <a routerLink=\"\">Cash Flow</a> -->\r\n\r\n        <button class=\"dropdown-btn\">Expense\r\n            <i class=\"fa fa-caret-down\"></i>\r\n        </button>\r\n        <div class=\"dropdown-container\">\r\n            <a routerLink=\"/accounts/expense/add\">Add Expense</a>\r\n            <a routerLink=\"\">Manage Expense</a>\r\n            <!-- <a routerLink=\"/accounts/expense/add-type\">Add Expense Type</a> -->\r\n            <!-- <a routerLink=\"\">Manage Expense Type</a> -->\r\n            <a routerLink=\"\">Expense Statement</a>\r\n        </div>\r\n    </div>\r\n\r\n    <button class=\"dropdown-btn\">\r\n        <i class=\"fa fa-bank\"></i>\r\n        Banks\r\n        <i class=\"fa fa-caret-down\"></i>\r\n    </button>\r\n    <div class=\"dropdown-container\">\r\n        <a routerLink=\"/banks/add\">Add New Bank</a>\r\n        <a routerLink=\"\">Bank Transactions</a>\r\n        <a routerLink=\"/banks/manage\">Manage Banks</a>\r\n    </div>\r\n\r\n    <!-- <button class=\"dropdown-btn\">\r\n        <i class=\"fa fa-sort-amount-desc\"></i>\r\n        Taxes\r\n        <i class=\"fa fa-caret-down\"></i>\r\n    </button>\r\n    <div class=\"dropdown-container\">\r\n        <a routerLink=\"\">Tax Settings</a>\r\n        <a routerLink=\"\">Add Income Tax</a>\r\n        <a routerLink=\"\">Manage Income Tax</a>\r\n        <a routerLink=\"\">Tax Report</a>\r\n        <a routerLink=\"\">Tax Report/Invoice</a>\r\n    </div> -->\r\n\r\n    <button class=\"dropdown-btn\">\r\n        <i class=\"fa fa-users\"></i>\r\n        Human Resource\r\n        <i class=\"fa fa-caret-down\"></i>\r\n    </button>\r\n    <div class=\"dropdown-container\">\r\n        <button class=\"dropdown-btn\">HRM\r\n            <i class=\"fa fa-caret-down\"></i>\r\n        </button>\r\n        <div class=\"dropdown-container\">\r\n            <a routerLink=\"\">Add Designation</a>\r\n            <a routerLink=\"\">Manage Designation</a>\r\n            <a routerLink=\"\">Add Employee</a>\r\n            <a routerLink=\"\">Manage Employee</a>\r\n        </div>\r\n        <!-- <button class=\"dropdown-btn\">Attendance\r\n            <i class=\"fa fa-caret-down\"></i>\r\n        </button>\r\n        <div class=\"dropdown-container\">\r\n            <a routerLink=\"\">Attendance</a>\r\n            <a routerLink=\"\">Manage Attendance</a>\r\n            <a routerLink=\"\">Attendance Report</a>\r\n        </div> -->\r\n        <button class=\"dropdown-btn\">Payroll\r\n            <i class=\"fa fa-caret-down\"></i>\r\n        </button>\r\n        <div class=\"dropdown-container\">\r\n            <a routerLink=\"\">Add Benefits</a>\r\n            <a routerLink=\"\">Manage Benefits</a>\r\n            <a routerLink=\"\">Add Salary Setup</a>\r\n            <a routerLink=\"\">Manage Salary Setup</a>\r\n            <a routerLink=\"\">Salary Generate</a>\r\n            <a routerLink=\"\">Manage Salary Generate</a>\r\n            <a routerLink=\"\">Salary Payment</a>\r\n        </div>\r\n        <!-- <button class=\"dropdown-btn\">Office Loan\r\n            <i class=\"fa fa-caret-down\"></i>\r\n        </button>\r\n        <div class=\"dropdown-container\">\r\n            <a routerLink=\"\">Add Person</a>\r\n            <a routerLink=\"\">Add Loan</a>\r\n            <a routerLink=\"\">Add Payment</a>\r\n            <a routerLink=\"\">Manage Loan</a>\r\n        </div> -->\r\n        <!-- <button class=\"dropdown-btn\">Personal Loan\r\n            <i class=\"fa fa-caret-down\"></i>\r\n        </button>\r\n        <div class=\"dropdown-container\">\r\n            <a routerLink=\"\">Add Person</a>\r\n            <a routerLink=\"\">Add Loan</a>\r\n            <a routerLink=\"\">Add Payment</a>\r\n            <a routerLink=\"\">Manage Loan</a>\r\n        </div> -->\r\n    </div>\r\n\r\n    <button class=\"dropdown-btn\">\r\n        <i class=\"fa fa-support\"></i>\r\n        Services\r\n        <i class=\"fa fa-caret-down\"></i>\r\n    </button>\r\n    <div class=\"dropdown-container\">\r\n        <a routerLink=\"\">Add Service</a>\r\n        <a routerLink=\"\">Manage Services</a>\r\n        <a routerLink=\"\">Service Invoice</a>\r\n        <a routerLink=\"\">Manage Service Invoice</a>\r\n    </div>\r\n\r\n    <button class=\"dropdown-btn\">\r\n        <i class=\"fa fa-percent\"></i>\r\n        Customer Offers\r\n        <i class=\"fa fa-caret-down\"></i>\r\n    </button>\r\n    <div class=\"dropdown-container\">\r\n        <a routerLink=\"/offers/add\">Add Offers</a>\r\n    </div>\r\n\r\n    <button class=\"dropdown-btn\">\r\n        <i class=\"fa fa-sliders\"></i>\r\n        Settings\r\n        <i class=\"fa fa-caret-down\"></i>\r\n    </button>\r\n    <div class=\"dropdown-container\">\r\n        <button class=\"dropdown-btn\">Software Settings\r\n            <i class=\"fa fa-caret-down\"></i>\r\n        </button>\r\n        <div class=\"dropdown-container\">\r\n            <a routerLink=\"\">Add User</a>\r\n            <a routerLink=\"\">Manage User</a>\r\n            <a routerLink=\"\">Settings</a>\r\n            <a routerLink=\"\">Currency</a>\r\n        </div>\r\n        <button class=\"dropdown-btn\">Role Permissions\r\n            <i class=\"fa fa-caret-down\"></i>\r\n        </button>\r\n        <div class=\"dropdown-container\">\r\n            <a routerLink=\"\">Add Role</a>\r\n            <a routerLink=\"\">Role List</a>\r\n            <a routerLink=\"\">User Assign Role</a>\r\n        </div>\r\n    </div>\r\n    <button class=\"dropdown-btn\">\r\n        <i class=\"fa fa-wrench\"></i>\r\n        Setup Existing Status\r\n        <i class=\"fa fa-caret-down\"></i>\r\n    </button>\r\n    <div class=\"dropdown-container\">\r\n        <a routerLink=\"/setup/cash\">Adjust Cash</a>\r\n        <a routerLink=\"/setup/inventory\">Adjust inventory</a>\r\n    </div>\r\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/stocks/manage-stocks/manage-stocks.component.html":
  /*!*********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/stocks/manage-stocks/manage-stocks.component.html ***!
    \*********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppStocksManageStocksManageStocksComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\n    <h1>Manage Stocks</h1>\n    <hr>\n    <table class=\"table table-hover table-striped\">\n        <thead>\n            <tr>\n                <th>Product</th>\n                <th>LOT No.</th>\n                <th>Quantity</th>\n                <th>Purchase Price</th>\n                <th>MRP/Sale Price</th>\n                <!-- <th>Date</th> -->\n                <!-- <th>Bank Sign</th> -->\n                <!-- <th><a routerLink=\"/purchases/add\"><i class=\"fa fa-plus\"></i></a></th> -->\n            </tr>\n        </thead>\n        <tbody>\n            <tr *ngFor=\"let model of modelData\">\n                <td>{{model.ProductName}}</td>\n                <td>{{model.ProductBatch}}</td>\n                <td>{{model.InStock}}</td>\n                <td>{{model.PurchasedAt}}</td>\n                <td>{{model.MRP}}</td>\n                <!-- <td>{{model.StockDate | date: 'dd-MMM-yyyy hh:mm a'}}</td> -->\n                <!-- <td>\n                    <button (click)=\"editProduct(model.ProductCode)\"><i class=\"fa fa-edit\"></i></button>\n                    <button (click)=\"deleteProduct(model.StockCode)\"><i class=\"fa fa-trash\"></i></button>\n                </td> -->\n            </tr>\n        </tbody>\n    </table>\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/suppliers/add-supplier/add-supplier.component.html":
  /*!**********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/suppliers/add-supplier/add-supplier.component.html ***!
    \**********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSuppliersAddSupplierAddSupplierComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\n    <h1>Add New Supplier</h1>\n    <hr>\n\n    <form (ngSubmit)=\"onSubmit()\" #addSupplierForm=\"ngForm\" autocomplete=\"off\">\n        <div class=\"row\">\n            <div class=\"col-md-6 offset-3\">\n                <div class=\"form-group\">\n                    <label for=\"SupplierName\">Supplier Name</label>\n                    <input type=\"text\" class=\"form-control\" required [(ngModel)]=\"model.SupplierName\"\n                        name=\"SupplierName\" #SupplierName=\"ngModel\">\n                </div>\n\n                <div class=\"form-group\">\n                    <label for=\"SupplierMobile\">Mobile No</label>\n                    <input type=\"text\" class=\"form-control\" required [(ngModel)]=\"model.SupplierMobile\"\n                        name=\"SupplierMobile\" #SupplierMobile=\"ngModel\">\n                </div>\n\n                <div class=\"form-group\">\n                    <label for=\"SupplierAddress\">Supplier Address</label>\n                    <input type=\"text\" class=\"form-control\" required [(ngModel)]=\"model.SupplierAddress\"\n                        name=\"SupplierAddress\" #SupplierAddress=\"ngModel\">\n                </div>\n                <div class=\"form-group\">\n                    <label for=\"SupplierDetails\">SupplierDetails</label>\n                    <input type=\"text\" class=\"form-control\" required [(ngModel)]=\"model.SupplierDetails\"\n                        name=\"SupplierDetails\" #SupplierDetails=\"ngModel\">\n                </div>\n\n                <div class=\"form-group\">\n                    <label for=\"SupplierPreCreditBalance\">Supplier Previous Balance</label>\n                    <input type=\"text\" class=\"form-control\" required [(ngModel)]=\"model.SupplierPreCreditBalance\"\n                        name=\"SupplierPreCreditBalance\" #SupplierPreCreditBalance=\"ngModel\">\n                </div>\n                <button type=\"submit\" class=\"btn btn-success submit\"\n                    [disabled]=\"addSupplierForm.invalid\">Submit</button>\n            </div>\n        </div>\n    </form>\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/suppliers/manage-suppliers/manage-suppliers.component.html":
  /*!******************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/suppliers/manage-suppliers/manage-suppliers.component.html ***!
    \******************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSuppliersManageSuppliersManageSuppliersComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\n    <h1>Manage Suppliers</h1>\n    <hr>\n    <table class=\"table table-hover table-striped\">\n        <thead>\n            <tr>\n                <th>Name</th>\n                <th>Mobile</th>\n                <th>Address</th>\n                <th>Details</th>\n                <th>Balance</th>\n                <!-- <th>Bank Sign</th> -->\n                <th><a routerLink=\"/suppliers/add\"><i class=\"fa fa-plus\"></i></a></th>\n            </tr>\n        </thead>\n        <tbody>\n            <tr *ngFor=\"let model of modelData\">\n                <td>{{model.SupplierName}}</td>\n                <td>{{model.SupplierMobile}}</td>\n                <td>{{model.SupplierAddress}}</td>\n                <td>{{model.SupplierDetails}}</td>\n                <td>{{model.SupplierPreCreditBalance}}</td>\n                <td>\n                    <button (click)=\"editSupplier(model.SupplierCode)\"><i class=\"fa fa-edit\"></i></button>\n                    <button (click)=\"deleteSupplier(model.SupplierCode)\"><i class=\"fa fa-trash\"></i></button>\n                </td>\n            </tr>\n        </tbody>\n    </table>\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/test/test/test.component.html":
  /*!*************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/test/test/test.component.html ***!
    \*************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppTestTestTestComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"jumbotron\">\n    <div class=\"row align-items-center border border-danger\">\n        <div class=\"col-4 justify-content-center border border-danger\">\n            <small>\n                <div>1</div>\n                <div>2</div>\n                <div>4</div>\n                <div>3</div>\n            </small>\n\n        </div>\n        <div class=\"col-4 justify-content-center border border-danger\">\n            <strong>\n                <div>7</div>\n                <div>2</div>\n            </strong>\n        </div>\n        <div class=\"col-4 justify-content-center border border-danger\">\n            <small>\n                <div>7</div>\n                <div>5</div>\n                <div>5</div>\n                <div>5</div>\n            </small>\n        </div>\n    </div>\n</div>";
    /***/
  },

  /***/
  "./node_modules/tslib/tslib.es6.js":
  /*!*****************************************!*\
    !*** ./node_modules/tslib/tslib.es6.js ***!
    \*****************************************/

  /*! exports provided: __extends, __assign, __rest, __decorate, __param, __metadata, __awaiter, __generator, __exportStar, __values, __read, __spread, __spreadArrays, __await, __asyncGenerator, __asyncDelegator, __asyncValues, __makeTemplateObject, __importStar, __importDefault, __classPrivateFieldGet, __classPrivateFieldSet */

  /***/
  function node_modulesTslibTslibEs6Js(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__extends", function () {
      return __extends;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__assign", function () {
      return _assign;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__rest", function () {
      return __rest;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__decorate", function () {
      return __decorate;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__param", function () {
      return __param;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__metadata", function () {
      return __metadata;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__awaiter", function () {
      return __awaiter;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__generator", function () {
      return __generator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__exportStar", function () {
      return __exportStar;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__values", function () {
      return __values;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__read", function () {
      return __read;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__spread", function () {
      return __spread;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__spreadArrays", function () {
      return __spreadArrays;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__await", function () {
      return __await;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function () {
      return __asyncGenerator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function () {
      return __asyncDelegator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncValues", function () {
      return __asyncValues;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function () {
      return __makeTemplateObject;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__importStar", function () {
      return __importStar;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__importDefault", function () {
      return __importDefault;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__classPrivateFieldGet", function () {
      return __classPrivateFieldGet;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__classPrivateFieldSet", function () {
      return __classPrivateFieldSet;
    });
    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0
    
    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.
    
    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */

    /* global Reflect, Promise */


    var _extendStatics = function extendStatics(d, b) {
      _extendStatics = Object.setPrototypeOf || {
        __proto__: []
      } instanceof Array && function (d, b) {
        d.__proto__ = b;
      } || function (d, b) {
        for (var p in b) {
          if (b.hasOwnProperty(p)) d[p] = b[p];
        }
      };

      return _extendStatics(d, b);
    };

    function __extends(d, b) {
      _extendStatics(d, b);

      function __() {
        this.constructor = d;
      }

      d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var _assign = function __assign() {
      _assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];

          for (var p in s) {
            if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
          }
        }

        return t;
      };

      return _assign.apply(this, arguments);
    };

    function __rest(s, e) {
      var t = {};

      for (var p in s) {
        if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
      }

      if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
      }
      return t;
    }

    function __decorate(decorators, target, key, desc) {
      var c = arguments.length,
          r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
          d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
        if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      }
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
      return function (target, key) {
        decorator(target, key, paramIndex);
      };
    }

    function __metadata(metadataKey, metadataValue) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function (resolve) {
          resolve(value);
        });
      }

      return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }

        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }

        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }

        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    }

    function __generator(thisArg, body) {
      var _ = {
        label: 0,
        sent: function sent() {
          if (t[0] & 1) throw t[1];
          return t[1];
        },
        trys: [],
        ops: []
      },
          f,
          y,
          t,
          g;
      return g = {
        next: verb(0),
        "throw": verb(1),
        "return": verb(2)
      }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
        return this;
      }), g;

      function verb(n) {
        return function (v) {
          return step([n, v]);
        };
      }

      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");

        while (_) {
          try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];

            switch (op[0]) {
              case 0:
              case 1:
                t = op;
                break;

              case 4:
                _.label++;
                return {
                  value: op[1],
                  done: false
                };

              case 5:
                _.label++;
                y = op[1];
                op = [0];
                continue;

              case 7:
                op = _.ops.pop();

                _.trys.pop();

                continue;

              default:
                if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                  _ = 0;
                  continue;
                }

                if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                  _.label = op[1];
                  break;
                }

                if (op[0] === 6 && _.label < t[1]) {
                  _.label = t[1];
                  t = op;
                  break;
                }

                if (t && _.label < t[2]) {
                  _.label = t[2];

                  _.ops.push(op);

                  break;
                }

                if (t[2]) _.ops.pop();

                _.trys.pop();

                continue;
            }

            op = body.call(thisArg, _);
          } catch (e) {
            op = [6, e];
            y = 0;
          } finally {
            f = t = 0;
          }
        }

        if (op[0] & 5) throw op[1];
        return {
          value: op[0] ? op[1] : void 0,
          done: true
        };
      }
    }

    function __exportStar(m, exports) {
      for (var p in m) {
        if (!exports.hasOwnProperty(p)) exports[p] = m[p];
      }
    }

    function __values(o) {
      var s = typeof Symbol === "function" && Symbol.iterator,
          m = s && o[s],
          i = 0;
      if (m) return m.call(o);
      if (o && typeof o.length === "number") return {
        next: function next() {
          if (o && i >= o.length) o = void 0;
          return {
            value: o && o[i++],
            done: !o
          };
        }
      };
      throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
      var m = typeof Symbol === "function" && o[Symbol.iterator];
      if (!m) return o;
      var i = m.call(o),
          r,
          ar = [],
          e;

      try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) {
          ar.push(r.value);
        }
      } catch (error) {
        e = {
          error: error
        };
      } finally {
        try {
          if (r && !r.done && (m = i["return"])) m.call(i);
        } finally {
          if (e) throw e.error;
        }
      }

      return ar;
    }

    function __spread() {
      for (var ar = [], i = 0; i < arguments.length; i++) {
        ar = ar.concat(__read(arguments[i]));
      }

      return ar;
    }

    function __spreadArrays() {
      for (var s = 0, i = 0, il = arguments.length; i < il; i++) {
        s += arguments[i].length;
      }

      for (var r = Array(s), k = 0, i = 0; i < il; i++) {
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++) {
          r[k] = a[j];
        }
      }

      return r;
    }

    ;

    function __await(v) {
      return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
      if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
      var g = generator.apply(thisArg, _arguments || []),
          i,
          q = [];
      return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
        return this;
      }, i;

      function verb(n) {
        if (g[n]) i[n] = function (v) {
          return new Promise(function (a, b) {
            q.push([n, v, a, b]) > 1 || resume(n, v);
          });
        };
      }

      function resume(n, v) {
        try {
          step(g[n](v));
        } catch (e) {
          settle(q[0][3], e);
        }
      }

      function step(r) {
        r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
      }

      function fulfill(value) {
        resume("next", value);
      }

      function reject(value) {
        resume("throw", value);
      }

      function settle(f, v) {
        if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
      }
    }

    function __asyncDelegator(o) {
      var i, p;
      return i = {}, verb("next"), verb("throw", function (e) {
        throw e;
      }), verb("return"), i[Symbol.iterator] = function () {
        return this;
      }, i;

      function verb(n, f) {
        i[n] = o[n] ? function (v) {
          return (p = !p) ? {
            value: __await(o[n](v)),
            done: n === "return"
          } : f ? f(v) : v;
        } : f;
      }
    }

    function __asyncValues(o) {
      if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
      var m = o[Symbol.asyncIterator],
          i;
      return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
        return this;
      }, i);

      function verb(n) {
        i[n] = o[n] && function (v) {
          return new Promise(function (resolve, reject) {
            v = o[n](v), settle(resolve, reject, v.done, v.value);
          });
        };
      }

      function settle(resolve, reject, d, v) {
        Promise.resolve(v).then(function (v) {
          resolve({
            value: v,
            done: d
          });
        }, reject);
      }
    }

    function __makeTemplateObject(cooked, raw) {
      if (Object.defineProperty) {
        Object.defineProperty(cooked, "raw", {
          value: raw
        });
      } else {
        cooked.raw = raw;
      }

      return cooked;
    }

    ;

    function __importStar(mod) {
      if (mod && mod.__esModule) return mod;
      var result = {};
      if (mod != null) for (var k in mod) {
        if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
      }
      result.default = mod;
      return result;
    }

    function __importDefault(mod) {
      return mod && mod.__esModule ? mod : {
        default: mod
      };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
      if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
      }

      return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
      if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to set private field on non-instance");
      }

      privateMap.set(receiver, value);
      return value;
    }
    /***/

  },

  /***/
  "./src/app/accounts/chart-of-account/chart-of-account.component.css":
  /*!**************************************************************************!*\
    !*** ./src/app/accounts/chart-of-account/chart-of-account.component.css ***!
    \**************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppAccountsChartOfAccountChartOfAccountComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "/* Remove margins and padding from the parent ul */\r\n\r\n#myUL {\r\n    margin: 0;\r\n    padding: 0;\r\n}\r\n\r\n/* Style the caret/arrow */\r\n\r\n.caret {\r\n    cursor: pointer;\r\n    -webkit-user-select: none;\r\n       -moz-user-select: none;\r\n        -ms-user-select: none;\r\n            user-select: none;\r\n    /* Prevent text selection */\r\n}\r\n\r\n/* Create the caret/arrow with a unicode, and style it */\r\n\r\n.caret::before {\r\n    content: \"\\F07B\";\r\n    color: black;\r\n    display: inline-block;\r\n    margin-right: 6px;\r\n}\r\n\r\n/* Rotate the caret/arrow icon when clicked on (using JavaScript) */\r\n\r\n.caret-down::before {\r\n    -webkit-transform: rotate(90deg);\r\n            transform: rotate(90deg);\r\n}\r\n\r\n/* Hide the nested list */\r\n\r\n.nested {\r\n    display: none;\r\n}\r\n\r\n/* Show the nested list when the user clicks on the caret/arrow (with JavaScript) */\r\n\r\n.active {\r\n    display: block;\r\n}\r\n\r\nul li {\r\n    list-style-type: none;\r\n}\r\n\r\nli::before {\r\n    content: \"\\21B3\";\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWNjb3VudHMvY2hhcnQtb2YtYWNjb3VudC9jaGFydC1vZi1hY2NvdW50LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsa0RBQWtEOztBQUVsRDtJQUNJLFNBQVM7SUFDVCxVQUFVO0FBQ2Q7O0FBRUEsMEJBQTBCOztBQUUxQjtJQUNJLGVBQWU7SUFDZix5QkFBaUI7T0FBakIsc0JBQWlCO1FBQWpCLHFCQUFpQjtZQUFqQixpQkFBaUI7SUFDakIsMkJBQTJCO0FBQy9COztBQUVBLHdEQUF3RDs7QUFFeEQ7SUFDSSxnQkFBZ0I7SUFDaEIsWUFBWTtJQUNaLHFCQUFxQjtJQUNyQixpQkFBaUI7QUFDckI7O0FBRUEsbUVBQW1FOztBQUVuRTtJQUNJLGdDQUF3QjtZQUF4Qix3QkFBd0I7QUFDNUI7O0FBRUEseUJBQXlCOztBQUV6QjtJQUNJLGFBQWE7QUFDakI7O0FBRUEsbUZBQW1GOztBQUVuRjtJQUNJLGNBQWM7QUFDbEI7O0FBRUE7SUFDSSxxQkFBcUI7QUFDekI7O0FBRUE7SUFDSSxnQkFBZ0I7QUFDcEIiLCJmaWxlIjoic3JjL2FwcC9hY2NvdW50cy9jaGFydC1vZi1hY2NvdW50L2NoYXJ0LW9mLWFjY291bnQuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi8qIFJlbW92ZSBtYXJnaW5zIGFuZCBwYWRkaW5nIGZyb20gdGhlIHBhcmVudCB1bCAqL1xyXG5cclxuI215VUwge1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgcGFkZGluZzogMDtcclxufVxyXG5cclxuLyogU3R5bGUgdGhlIGNhcmV0L2Fycm93ICovXHJcblxyXG4uY2FyZXQge1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgdXNlci1zZWxlY3Q6IG5vbmU7XHJcbiAgICAvKiBQcmV2ZW50IHRleHQgc2VsZWN0aW9uICovXHJcbn1cclxuXHJcbi8qIENyZWF0ZSB0aGUgY2FyZXQvYXJyb3cgd2l0aCBhIHVuaWNvZGUsIGFuZCBzdHlsZSBpdCAqL1xyXG5cclxuLmNhcmV0OjpiZWZvcmUge1xyXG4gICAgY29udGVudDogXCJcXEYwN0JcIjtcclxuICAgIGNvbG9yOiBibGFjaztcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIG1hcmdpbi1yaWdodDogNnB4O1xyXG59XHJcblxyXG4vKiBSb3RhdGUgdGhlIGNhcmV0L2Fycm93IGljb24gd2hlbiBjbGlja2VkIG9uICh1c2luZyBKYXZhU2NyaXB0KSAqL1xyXG5cclxuLmNhcmV0LWRvd246OmJlZm9yZSB7XHJcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZSg5MGRlZyk7XHJcbn1cclxuXHJcbi8qIEhpZGUgdGhlIG5lc3RlZCBsaXN0ICovXHJcblxyXG4ubmVzdGVkIHtcclxuICAgIGRpc3BsYXk6IG5vbmU7XHJcbn1cclxuXHJcbi8qIFNob3cgdGhlIG5lc3RlZCBsaXN0IHdoZW4gdGhlIHVzZXIgY2xpY2tzIG9uIHRoZSBjYXJldC9hcnJvdyAod2l0aCBKYXZhU2NyaXB0KSAqL1xyXG5cclxuLmFjdGl2ZSB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxufVxyXG5cclxudWwgbGkge1xyXG4gICAgbGlzdC1zdHlsZS10eXBlOiBub25lO1xyXG59XHJcblxyXG5saTo6YmVmb3JlIHtcclxuICAgIGNvbnRlbnQ6IFwiXFwyMUIzXCI7XHJcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/accounts/chart-of-account/chart-of-account.component.ts":
  /*!*************************************************************************!*\
    !*** ./src/app/accounts/chart-of-account/chart-of-account.component.ts ***!
    \*************************************************************************/

  /*! exports provided: ChartOfAccountComponent */

  /***/
  function srcAppAccountsChartOfAccountChartOfAccountComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ChartOfAccountComponent", function () {
      return ChartOfAccountComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");

    var ChartOfAccountComponent =
    /*#__PURE__*/
    function () {
      function ChartOfAccountComponent(http, cs) {
        _classCallCheck(this, ChartOfAccountComponent);

        this.http = http;
        this.cs = cs;
      }

      _createClass(ChartOfAccountComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this = this;

          this.http.get(this.cs.getApiURL() + "conf_Accounts/GetChartOfAccount").subscribe(function (data) {
            _this.AccList = data;
            console.log(_this.AccList);
          });
        }
      }]);

      return ChartOfAccountComponent;
    }();

    ChartOfAccountComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__["CommonService"]
      }];
    };

    ChartOfAccountComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-chart-of-account',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./chart-of-account.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/chart-of-account/chart-of-account.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./chart-of-account.component.css */
      "./src/app/accounts/chart-of-account/chart-of-account.component.css")).default]
    })], ChartOfAccountComponent);
    /***/
  },

  /***/
  "./src/app/accounts/chart-of-account/tree/tree.component.css":
  /*!*******************************************************************!*\
    !*** ./src/app/accounts/chart-of-account/tree/tree.component.css ***!
    \*******************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppAccountsChartOfAccountTreeTreeComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FjY291bnRzL2NoYXJ0LW9mLWFjY291bnQvdHJlZS90cmVlLmNvbXBvbmVudC5jc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/accounts/chart-of-account/tree/tree.component.ts":
  /*!******************************************************************!*\
    !*** ./src/app/accounts/chart-of-account/tree/tree.component.ts ***!
    \******************************************************************/

  /*! exports provided: TreeComponent */

  /***/
  function srcAppAccountsChartOfAccountTreeTreeComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TreeComponent", function () {
      return TreeComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var TreeComponent =
    /*#__PURE__*/
    function () {
      function TreeComponent() {
        _classCallCheck(this, TreeComponent);
      }

      _createClass(TreeComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "toggleChild",
        value: function toggleChild(node) {
          node.showChildren = !node.showChildren;
        }
      }]);

      return TreeComponent;
    }();

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], TreeComponent.prototype, "treeData", void 0);
    TreeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-tree',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./tree.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/chart-of-account/tree/tree.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./tree.component.css */
      "./src/app/accounts/chart-of-account/tree/tree.component.css")).default]
    })], TreeComponent);
    /***/
  },

  /***/
  "./src/app/accounts/expense/add-expense-type/add-expense-type.component.css":
  /*!**********************************************************************************!*\
    !*** ./src/app/accounts/expense/add-expense-type/add-expense-type.component.css ***!
    \**********************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppAccountsExpenseAddExpenseTypeAddExpenseTypeComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FjY291bnRzL2V4cGVuc2UvYWRkLWV4cGVuc2UtdHlwZS9hZGQtZXhwZW5zZS10eXBlLmNvbXBvbmVudC5jc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/accounts/expense/add-expense-type/add-expense-type.component.ts":
  /*!*********************************************************************************!*\
    !*** ./src/app/accounts/expense/add-expense-type/add-expense-type.component.ts ***!
    \*********************************************************************************/

  /*! exports provided: AddExpenseTypeComponent */

  /***/
  function srcAppAccountsExpenseAddExpenseTypeAddExpenseTypeComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AddExpenseTypeComponent", function () {
      return AddExpenseTypeComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_shared_models_account_expense_info_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/shared/models/account-expense-info.model */
    "./src/app/shared/models/account-expense-info.model.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");

    var AddExpenseTypeComponent =
    /*#__PURE__*/
    function () {
      function AddExpenseTypeComponent(http, cs, router) {
        _classCallCheck(this, AddExpenseTypeComponent);

        this.http = http;
        this.cs = cs;
        this.router = router;
        this.model = new src_app_shared_models_account_expense_info_model__WEBPACK_IMPORTED_MODULE_2__["AccountExpenseInfo"]();
      }

      _createClass(AddExpenseTypeComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this2 = this;

          // this.model.ExpenseType = "Administritive Cost";
          this.model.AccountName = "";
          this.model.GLCode = 4;
          this.http.get(this.cs.getApiURL() + "conf_Accounts/GetExpenseList").subscribe(function (data) {
            _this2.expenseAccList = data;
          }, function (error) {
            alert("Error occured. try reloading the page");
          });
        }
      }, {
        key: "onSubmit",
        value: function onSubmit() {
          this.http.post(this.cs.getApiURL() + "AccountExpenseInfo/PostAccount_ExpenseInfo", this.model, {
            headers: {
              "Content-Type": "application/json"
            }
          }).subscribe(function (data) {
            console.log("Entry success");
          }, function (error) {
            alert("Entry failed. retry please");
          });
          this.ngOnInit();
        }
      }]);

      return AddExpenseTypeComponent;
    }();

    AddExpenseTypeComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_4__["CommonService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]
      }];
    };

    AddExpenseTypeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-add-expense-type',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./add-expense-type.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/expense/add-expense-type/add-expense-type.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./add-expense-type.component.css */
      "./src/app/accounts/expense/add-expense-type/add-expense-type.component.css")).default]
    })], AddExpenseTypeComponent);
    /***/
  },

  /***/
  "./src/app/accounts/expense/add-expense/add-expense.component.css":
  /*!************************************************************************!*\
    !*** ./src/app/accounts/expense/add-expense/add-expense.component.css ***!
    \************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppAccountsExpenseAddExpenseAddExpenseComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FjY291bnRzL2V4cGVuc2UvYWRkLWV4cGVuc2UvYWRkLWV4cGVuc2UuY29tcG9uZW50LmNzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/accounts/expense/add-expense/add-expense.component.ts":
  /*!***********************************************************************!*\
    !*** ./src/app/accounts/expense/add-expense/add-expense.component.ts ***!
    \***********************************************************************/

  /*! exports provided: AddExpenseComponent */

  /***/
  function srcAppAccountsExpenseAddExpenseAddExpenseComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AddExpenseComponent", function () {
      return AddExpenseComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_shared_models_trx_record_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/shared/models/trx-record.model */
    "./src/app/shared/models/trx-record.model.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");
    /* harmony import */


    var src_app_shared_models_expense_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/shared/models/expense.model */
    "./src/app/shared/models/expense.model.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");

    var AddExpenseComponent =
    /*#__PURE__*/
    function () {
      function AddExpenseComponent(http, cs, router) {
        _classCallCheck(this, AddExpenseComponent);

        this.http = http;
        this.cs = cs;
        this.router = router;
        this.model = new src_app_shared_models_expense_model__WEBPACK_IMPORTED_MODULE_5__["Expense"]();
      }

      _createClass(AddExpenseComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this3 = this;

          this.PurchaseDateString = this.cs.datePipeISO(new Date());
          this.http.get(this.cs.getApiURL() + "conf_Accounts/GetExpenseList").subscribe(function (data) {
            _this3.expenseTypes = data; // console.log(data);
            // console.log(this.expenseTypes);
          }, function (error) {
            alert("try reloading this page");
          });
        }
      }, {
        key: "onSubmit",
        value: function onSubmit() {
          var isSuccess = true;
          var trxModel = new Array();
          var payType = new src_app_shared_models_trx_record_model__WEBPACK_IMPORTED_MODULE_2__["TrxRecord"]();
          var expn = new src_app_shared_models_trx_record_model__WEBPACK_IMPORTED_MODULE_2__["TrxRecord"]();
          var tempDate = new Date(this.PurchaseDateString);
          payType.TrxDate = tempDate;
          expn.TrxDate = tempDate;
          console.log(payType.TrxDate);
          payType.TrxNo = tempDate.getTime();
          expn.TrxNo = tempDate.getTime();
          payType.BranchID = 1;
          expn.BranchID = 1;

          if (!this.model.PaymentType.toLowerCase().localeCompare("cash")) {
            // let trx1 = new TrxRecord();
            payType.AccountNo = 10;
          } else if (!this.model.PaymentType.toLowerCase().localeCompare("cheque")) {
            payType.AccountNo = 43; // Cash in Bank
          } else {
            payType.AccountNo = 36; // credit //Account Payable
          }

          payType.AccountRef = String(payType.AccountNo);
          expn.AccountNo = Number(this.model.ExpenseNo); // expense

          expn.AccountRef = String(expn.AccountNo);
          payType.CreditAmount = this.model.Amount;
          expn.DebitAmount = this.model.Amount;
          payType.Particulars = this.model.Particulars;
          expn.Particulars = this.model.Particulars;
          trxModel.push(payType);
          trxModel.push(expn);

          for (var i = 0; i < 2; i++) {
            this.http.post(this.cs.getApiURL() + "trx_Records/Posttrx_Records", trxModel[i], {
              headers: {
                "Content-Type": "application/json"
              }
            }).subscribe(function (data) {
              console.log("Ok");
            }, function (error) {
              alert("Opps!");
              isSuccess = false;
            });
          }

          if (isSuccess) {
            alert("Expense recorded successfully!");
          }

          this.router.navigate(['/dashboard']);
        }
      }, {
        key: "onChange",
        value: function onChange(event) {
          console.log(event);
        }
      }]);

      return AddExpenseComponent;
    }();

    AddExpenseComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_4__["CommonService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"]
      }];
    };

    AddExpenseComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-add-expense',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./add-expense.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/expense/add-expense/add-expense.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./add-expense.component.css */
      "./src/app/accounts/expense/add-expense/add-expense.component.css")).default]
    })], AddExpenseComponent);
    /***/
  },

  /***/
  "./src/app/accounts/journal/journal.component.css":
  /*!********************************************************!*\
    !*** ./src/app/accounts/journal/journal.component.css ***!
    \********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppAccountsJournalJournalComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FjY291bnRzL2pvdXJuYWwvam91cm5hbC5jb21wb25lbnQuY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/accounts/journal/journal.component.ts":
  /*!*******************************************************!*\
    !*** ./src/app/accounts/journal/journal.component.ts ***!
    \*******************************************************/

  /*! exports provided: JournalComponent */

  /***/
  function srcAppAccountsJournalJournalComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "JournalComponent", function () {
      return JournalComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");

    var JournalComponent =
    /*#__PURE__*/
    function () {
      function JournalComponent(http, cs) {
        _classCallCheck(this, JournalComponent);

        this.http = http;
        this.cs = cs;
      }

      _createClass(JournalComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.FromDateStr = this.cs.dateTimeToDateOnly(new Date()); // console.log(this.FromDateStr);

          this.ToDateStr = this.cs.dateTimeToDateOnly(new Date(new Date().setDate(new Date().getDate() + 1)));
          this.onShow();
        }
      }, {
        key: "onShow",
        value: function onShow() {
          var _this4 = this;

          this.http.get(this.cs.getApiURL() + "trx_Records/GetJournal?from=" + this.FromDateStr + "&to=" + this.ToDateStr).subscribe(function (data) {
            _this4.modelData = data;
            console.log(_this4.modelData);
          });
        }
      }]);

      return JournalComponent;
    }();

    JournalComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__["CommonService"]
      }];
    };

    JournalComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-journal',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./journal.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/journal/journal.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./journal.component.css */
      "./src/app/accounts/journal/journal.component.css")).default]
    })], JournalComponent);
    /***/
  },

  /***/
  "./src/app/accounts/report/balance-sheet/balance-sheet.component.css":
  /*!***************************************************************************!*\
    !*** ./src/app/accounts/report/balance-sheet/balance-sheet.component.css ***!
    \***************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppAccountsReportBalanceSheetBalanceSheetComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".hd {\r\n    text-align: center;\r\n    font-size: 18;\r\n    font-weight: bolder;\r\n}\r\n\r\n.rt {\r\n    text-align: right;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWNjb3VudHMvcmVwb3J0L2JhbGFuY2Utc2hlZXQvYmFsYW5jZS1zaGVldC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksa0JBQWtCO0lBQ2xCLGFBQWE7SUFDYixtQkFBbUI7QUFDdkI7O0FBRUE7SUFDSSxpQkFBaUI7QUFDckIiLCJmaWxlIjoic3JjL2FwcC9hY2NvdW50cy9yZXBvcnQvYmFsYW5jZS1zaGVldC9iYWxhbmNlLXNoZWV0LmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGQge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgZm9udC1zaXplOiAxODtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkZXI7XHJcbn1cclxuXHJcbi5ydCB7XHJcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcclxufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/accounts/report/balance-sheet/balance-sheet.component.ts":
  /*!**************************************************************************!*\
    !*** ./src/app/accounts/report/balance-sheet/balance-sheet.component.ts ***!
    \**************************************************************************/

  /*! exports provided: BalanceSheetComponent */

  /***/
  function srcAppAccountsReportBalanceSheetBalanceSheetComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BalanceSheetComponent", function () {
      return BalanceSheetComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");

    var BalanceSheetComponent =
    /*#__PURE__*/
    function () {
      function BalanceSheetComponent(http, cs) {
        _classCallCheck(this, BalanceSheetComponent);

        this.http = http;
        this.cs = cs;
      }

      _createClass(BalanceSheetComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.FromDateStr = this.cs.dateTimeToDateOnly(new Date()); // console.log(this.FromDateStr);

          this.ToDateStr = this.cs.dateTimeToDateOnly(new Date(new Date().setDate(new Date().getDate() + 1)));
          this.onShow();
        }
      }, {
        key: "onShow",
        value: function onShow() {
          var _this5 = this;

          this.http.get(this.cs.getApiURL() + "trx_Records/GetBalanceSheet?from=" + this.FromDateStr + "&to=" + this.ToDateStr).subscribe(function (data) {
            _this5.modelData = data;
            console.log(_this5.modelData[0]);
          });
        }
      }]);

      return BalanceSheetComponent;
    }();

    BalanceSheetComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__["CommonService"]
      }];
    };

    BalanceSheetComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-balance-sheet',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./balance-sheet.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/report/balance-sheet/balance-sheet.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./balance-sheet.component.css */
      "./src/app/accounts/report/balance-sheet/balance-sheet.component.css")).default]
    })], BalanceSheetComponent);
    /***/
  },

  /***/
  "./src/app/accounts/report/cash-ledger/cash-ledger.component.css":
  /*!***********************************************************************!*\
    !*** ./src/app/accounts/report/cash-ledger/cash-ledger.component.css ***!
    \***********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppAccountsReportCashLedgerCashLedgerComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FjY291bnRzL3JlcG9ydC9jYXNoLWxlZGdlci9jYXNoLWxlZGdlci5jb21wb25lbnQuY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/accounts/report/cash-ledger/cash-ledger.component.ts":
  /*!**********************************************************************!*\
    !*** ./src/app/accounts/report/cash-ledger/cash-ledger.component.ts ***!
    \**********************************************************************/

  /*! exports provided: CashLedgerComponent */

  /***/
  function srcAppAccountsReportCashLedgerCashLedgerComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CashLedgerComponent", function () {
      return CashLedgerComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");

    var CashLedgerComponent =
    /*#__PURE__*/
    function () {
      function CashLedgerComponent(http, cs) {
        _classCallCheck(this, CashLedgerComponent);

        this.http = http;
        this.cs = cs;
      }

      _createClass(CashLedgerComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.FromDateStr = this.cs.dateTimeToDateOnly(new Date()); // console.log(this.FromDateStr);

          this.ToDateStr = this.cs.dateTimeToDateOnly(new Date(new Date().setDate(new Date().getDate() + 1)));
          this.onShow();
        }
      }, {
        key: "onShow",
        value: function onShow() {
          var _this6 = this;

          this.http.get(this.cs.getApiURL() + "trx_Records/GetLedger?accountNo=10&from=" + this.FromDateStr + "&to=" + this.ToDateStr).subscribe(function (data) {
            _this6.modelData = data; // console.log(this.modelData)
          });
        }
      }]);

      return CashLedgerComponent;
    }();

    CashLedgerComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__["CommonService"]
      }];
    };

    CashLedgerComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-cash-ledger',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./cash-ledger.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/report/cash-ledger/cash-ledger.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./cash-ledger.component.css */
      "./src/app/accounts/report/cash-ledger/cash-ledger.component.css")).default]
    })], CashLedgerComponent);
    /***/
  },

  /***/
  "./src/app/accounts/report/general-ladger/general-ladger.component.css":
  /*!*****************************************************************************!*\
    !*** ./src/app/accounts/report/general-ladger/general-ladger.component.css ***!
    \*****************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppAccountsReportGeneralLadgerGeneralLadgerComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FjY291bnRzL3JlcG9ydC9nZW5lcmFsLWxhZGdlci9nZW5lcmFsLWxhZGdlci5jb21wb25lbnQuY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/accounts/report/general-ladger/general-ladger.component.ts":
  /*!****************************************************************************!*\
    !*** ./src/app/accounts/report/general-ladger/general-ladger.component.ts ***!
    \****************************************************************************/

  /*! exports provided: GeneralLadgerComponent */

  /***/
  function srcAppAccountsReportGeneralLadgerGeneralLadgerComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "GeneralLadgerComponent", function () {
      return GeneralLadgerComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");

    var GeneralLadgerComponent =
    /*#__PURE__*/
    function () {
      function GeneralLadgerComponent(http, cs) {
        _classCallCheck(this, GeneralLadgerComponent);

        this.http = http;
        this.cs = cs;
      }

      _createClass(GeneralLadgerComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.FromDateStr = this.cs.dateTimeToDateOnly(new Date()); // console.log(this.FromDateStr);

          this.ToDateStr = this.cs.dateTimeToDateOnly(new Date(new Date().setDate(new Date().getDate() + 1)));
          this.onShow();
        }
      }, {
        key: "onShow",
        value: function onShow() {
          var _this7 = this;

          this.http.get(this.cs.getApiURL() + "trx_Records/GetGeneralLedger?from=" + this.FromDateStr + "&to=" + this.ToDateStr).subscribe(function (data) {
            _this7.listData = data;
            console.log(_this7.listData);
          });
        }
      }, {
        key: "changeLedger",
        value: function changeLedger(event) {
          var _this8 = this;

          // console.log(event);
          this.http.get(this.cs.getApiURL() + "trx_Records/GetLedger?accountNo=" + event + "&from=" + this.FromDateStr + "&to=" + this.ToDateStr).subscribe(function (data) {
            _this8.modelData = data;
            console.log(data);
          });
        }
      }]);

      return GeneralLadgerComponent;
    }();

    GeneralLadgerComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__["CommonService"]
      }];
    };

    GeneralLadgerComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-general-ladger',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./general-ladger.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/report/general-ladger/general-ladger.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./general-ladger.component.css */
      "./src/app/accounts/report/general-ladger/general-ladger.component.css")).default]
    })], GeneralLadgerComponent);
    /***/
  },

  /***/
  "./src/app/accounts/report/income-statement/income-statement.component.css":
  /*!*********************************************************************************!*\
    !*** ./src/app/accounts/report/income-statement/income-statement.component.css ***!
    \*********************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppAccountsReportIncomeStatementIncomeStatementComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FjY291bnRzL3JlcG9ydC9pbmNvbWUtc3RhdGVtZW50L2luY29tZS1zdGF0ZW1lbnQuY29tcG9uZW50LmNzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/accounts/report/income-statement/income-statement.component.ts":
  /*!********************************************************************************!*\
    !*** ./src/app/accounts/report/income-statement/income-statement.component.ts ***!
    \********************************************************************************/

  /*! exports provided: IncomeStatementComponent */

  /***/
  function srcAppAccountsReportIncomeStatementIncomeStatementComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "IncomeStatementComponent", function () {
      return IncomeStatementComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");

    var IncomeStatementComponent =
    /*#__PURE__*/
    function () {
      function IncomeStatementComponent(http, cs) {
        _classCallCheck(this, IncomeStatementComponent);

        this.http = http;
        this.cs = cs;
      }

      _createClass(IncomeStatementComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.FromDateStr = this.cs.dateTimeToDateOnly(new Date()); // console.log(this.FromDateStr);

          this.ToDateStr = this.cs.dateTimeToDateOnly(new Date(new Date().setDate(new Date().getDate() + 1)));
          this.onShow();
        }
      }, {
        key: "onShow",
        value: function onShow() {
          var _this9 = this;

          this.http.get(this.cs.getApiURL() + "trx_Records/GetIncomeStatement?from=" + this.FromDateStr + "&to=" + this.ToDateStr).subscribe(function (data) {
            _this9.modelData = data;
          });
        }
      }]);

      return IncomeStatementComponent;
    }();

    IncomeStatementComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__["CommonService"]
      }];
    };

    IncomeStatementComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-income-statement',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./income-statement.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/report/income-statement/income-statement.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./income-statement.component.css */
      "./src/app/accounts/report/income-statement/income-statement.component.css")).default]
    })], IncomeStatementComponent);
    /***/
  },

  /***/
  "./src/app/accounts/report/trial-balance/trial-balance.component.css":
  /*!***************************************************************************!*\
    !*** ./src/app/accounts/report/trial-balance/trial-balance.component.css ***!
    \***************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppAccountsReportTrialBalanceTrialBalanceComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FjY291bnRzL3JlcG9ydC90cmlhbC1iYWxhbmNlL3RyaWFsLWJhbGFuY2UuY29tcG9uZW50LmNzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/accounts/report/trial-balance/trial-balance.component.ts":
  /*!**************************************************************************!*\
    !*** ./src/app/accounts/report/trial-balance/trial-balance.component.ts ***!
    \**************************************************************************/

  /*! exports provided: TrialBalanceComponent */

  /***/
  function srcAppAccountsReportTrialBalanceTrialBalanceComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TrialBalanceComponent", function () {
      return TrialBalanceComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");

    var TrialBalanceComponent =
    /*#__PURE__*/
    function () {
      function TrialBalanceComponent(http, cs) {
        _classCallCheck(this, TrialBalanceComponent);

        this.http = http;
        this.cs = cs;
      }

      _createClass(TrialBalanceComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.FromDateStr = this.cs.dateTimeToDateOnly(new Date()); // console.log(this.FromDateStr);

          this.ToDateStr = this.cs.dateTimeToDateOnly(new Date(new Date().setDate(new Date().getDate() + 1)));
          this.onShow();
        }
      }, {
        key: "onShow",
        value: function onShow() {
          var _this10 = this;

          this.http.get(this.cs.getApiURL() + "trx_Records/GetTrialBalance?from=" + this.FromDateStr + "&to=" + this.ToDateStr).subscribe(function (data) {
            _this10.modelData = data;
          });
        }
      }]);

      return TrialBalanceComponent;
    }();

    TrialBalanceComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__["CommonService"]
      }];
    };

    TrialBalanceComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-trial-balance',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./trial-balance.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/accounts/report/trial-balance/trial-balance.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./trial-balance.component.css */
      "./src/app/accounts/report/trial-balance/trial-balance.component.css")).default]
    })], TrialBalanceComponent);
    /***/
  },

  /***/
  "./src/app/app-routing.module.ts":
  /*!***************************************!*\
    !*** ./src/app/app-routing.module.ts ***!
    \***************************************/

  /*! exports provided: AppRoutingModule */

  /***/
  function srcAppAppRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function () {
      return AppRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./dashboard/dashboard.component */
    "./src/app/dashboard/dashboard.component.ts");
    /* harmony import */


    var _products_add_product_add_product_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./products/add-product/add-product.component */
    "./src/app/products/add-product/add-product.component.ts");
    /* harmony import */


    var _purchases_add_purchase_add_purchase_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./purchases/add-purchase/add-purchase.component */
    "./src/app/purchases/add-purchase/add-purchase.component.ts");
    /* harmony import */


    var _sales_add_sale_add_sale_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./sales/add-sale/add-sale.component */
    "./src/app/sales/add-sale/add-sale.component.ts");
    /* harmony import */


    var _suppliers_add_supplier_add_supplier_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./suppliers/add-supplier/add-supplier.component */
    "./src/app/suppliers/add-supplier/add-supplier.component.ts");
    /* harmony import */


    var _customers_add_customer_add_customer_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ./customers/add-customer/add-customer.component */
    "./src/app/customers/add-customer/add-customer.component.ts");
    /* harmony import */


    var _accounts_chart_of_account_chart_of_account_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ./accounts/chart-of-account/chart-of-account.component */
    "./src/app/accounts/chart-of-account/chart-of-account.component.ts");
    /* harmony import */


    var _products_add_category_add_category_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ./products/add-category/add-category.component */
    "./src/app/products/add-category/add-category.component.ts");
    /* harmony import */


    var _products_add_brand_add_brand_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! ./products/add-brand/add-brand.component */
    "./src/app/products/add-brand/add-brand.component.ts");
    /* harmony import */


    var _customers_manage_customer_manage_customer_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! ./customers/manage-customer/manage-customer.component */
    "./src/app/customers/manage-customer/manage-customer.component.ts");
    /* harmony import */


    var _banks_add_new_bank_add_new_bank_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! ./banks/add-new-bank/add-new-bank.component */
    "./src/app/banks/add-new-bank/add-new-bank.component.ts");
    /* harmony import */


    var _banks_manage_banks_manage_banks_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
    /*! ./banks/manage-banks/manage-banks.component */
    "./src/app/banks/manage-banks/manage-banks.component.ts");
    /* harmony import */


    var _suppliers_manage_suppliers_manage_suppliers_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
    /*! ./suppliers/manage-suppliers/manage-suppliers.component */
    "./src/app/suppliers/manage-suppliers/manage-suppliers.component.ts");
    /* harmony import */


    var _products_manage_products_manage_products_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
    /*! ./products/manage-products/manage-products.component */
    "./src/app/products/manage-products/manage-products.component.ts");
    /* harmony import */


    var _purchases_add_new_batch_add_new_batch_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
    /*! ./purchases/add-new-batch/add-new-batch.component */
    "./src/app/purchases/add-new-batch/add-new-batch.component.ts");
    /* harmony import */


    var _stocks_manage_stocks_manage_stocks_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(
    /*! ./stocks/manage-stocks/manage-stocks.component */
    "./src/app/stocks/manage-stocks/manage-stocks.component.ts");
    /* harmony import */


    var _accounts_expense_add_expense_type_add_expense_type_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(
    /*! ./accounts/expense/add-expense-type/add-expense-type.component */
    "./src/app/accounts/expense/add-expense-type/add-expense-type.component.ts");
    /* harmony import */


    var _accounts_expense_add_expense_add_expense_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(
    /*! ./accounts/expense/add-expense/add-expense.component */
    "./src/app/accounts/expense/add-expense/add-expense.component.ts");
    /* harmony import */


    var _accounts_journal_journal_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(
    /*! ./accounts/journal/journal.component */
    "./src/app/accounts/journal/journal.component.ts");
    /* harmony import */


    var _accounts_report_cash_ledger_cash_ledger_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(
    /*! ./accounts/report/cash-ledger/cash-ledger.component */
    "./src/app/accounts/report/cash-ledger/cash-ledger.component.ts");
    /* harmony import */


    var _accounts_report_trial_balance_trial_balance_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(
    /*! ./accounts/report/trial-balance/trial-balance.component */
    "./src/app/accounts/report/trial-balance/trial-balance.component.ts");
    /* harmony import */


    var _accounts_report_income_statement_income_statement_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(
    /*! ./accounts/report/income-statement/income-statement.component */
    "./src/app/accounts/report/income-statement/income-statement.component.ts");
    /* harmony import */


    var _accounts_report_balance_sheet_balance_sheet_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(
    /*! ./accounts/report/balance-sheet/balance-sheet.component */
    "./src/app/accounts/report/balance-sheet/balance-sheet.component.ts");
    /* harmony import */


    var _offers_add_offer_add_offer_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(
    /*! ./offers/add-offer/add-offer.component */
    "./src/app/offers/add-offer/add-offer.component.ts");
    /* harmony import */


    var _test_test_test_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(
    /*! ./test/test/test.component */
    "./src/app/test/test/test.component.ts");
    /* harmony import */


    var _customers_add_warrenty_card_add_warrenty_card_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(
    /*! ./customers/add-warrenty-card/add-warrenty-card.component */
    "./src/app/customers/add-warrenty-card/add-warrenty-card.component.ts");
    /* harmony import */


    var _accounts_report_general_ladger_general_ladger_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(
    /*! ./accounts/report/general-ladger/general-ladger.component */
    "./src/app/accounts/report/general-ladger/general-ladger.component.ts");
    /* harmony import */


    var _setup_add_previous_cash_add_previous_cash_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(
    /*! ./setup/add-previous-cash/add-previous-cash.component */
    "./src/app/setup/add-previous-cash/add-previous-cash.component.ts");
    /* harmony import */


    var _setup_add_previous_stock_add_previous_stock_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(
    /*! ./setup/add-previous-stock/add-previous-stock.component */
    "./src/app/setup/add-previous-stock/add-previous-stock.component.ts");

    var routes = [{
      path: 'dashboard',
      component: _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_3__["DashboardComponent"]
    }, {
      path: '',
      redirectTo: '/dashboard',
      pathMatch: 'full'
    }, {
      path: 'products/add',
      component: _products_add_product_add_product_component__WEBPACK_IMPORTED_MODULE_4__["AddProductComponent"]
    }, {
      path: 'products/add-category',
      component: _products_add_category_add_category_component__WEBPACK_IMPORTED_MODULE_10__["AddCategoryComponent"]
    }, {
      path: 'products/add-brand',
      component: _products_add_brand_add_brand_component__WEBPACK_IMPORTED_MODULE_11__["AddBrandComponent"]
    }, {
      path: 'products/manage',
      component: _products_manage_products_manage_products_component__WEBPACK_IMPORTED_MODULE_16__["ManageProductsComponent"]
    }, {
      path: 'purchases/add',
      component: _purchases_add_purchase_add_purchase_component__WEBPACK_IMPORTED_MODULE_5__["AddPurchaseComponent"]
    }, {
      path: 'purchases/add-batch',
      component: _purchases_add_new_batch_add_new_batch_component__WEBPACK_IMPORTED_MODULE_17__["AddNewBatchComponent"]
    }, {
      path: 'sales/add',
      component: _sales_add_sale_add_sale_component__WEBPACK_IMPORTED_MODULE_6__["AddSaleComponent"]
    }, {
      path: 'suppliers/add',
      component: _suppliers_add_supplier_add_supplier_component__WEBPACK_IMPORTED_MODULE_7__["AddSupplierComponent"]
    }, {
      path: 'suppliers/manage',
      component: _suppliers_manage_suppliers_manage_suppliers_component__WEBPACK_IMPORTED_MODULE_15__["ManageSuppliersComponent"]
    }, {
      path: 'customers/add',
      component: _customers_add_customer_add_customer_component__WEBPACK_IMPORTED_MODULE_8__["AddCustomerComponent"]
    }, {
      path: 'customers/manage',
      component: _customers_manage_customer_manage_customer_component__WEBPACK_IMPORTED_MODULE_12__["ManageCustomerComponent"]
    }, {
      path: 'customers/add-warrenty-card',
      component: _customers_add_warrenty_card_add_warrenty_card_component__WEBPACK_IMPORTED_MODULE_28__["AddWarrentyCardComponent"]
    }, {
      path: 'accounts/chart-of-account',
      component: _accounts_chart_of_account_chart_of_account_component__WEBPACK_IMPORTED_MODULE_9__["ChartOfAccountComponent"]
    }, {
      path: 'accounts/expense/add-type',
      component: _accounts_expense_add_expense_type_add_expense_type_component__WEBPACK_IMPORTED_MODULE_19__["AddExpenseTypeComponent"]
    }, {
      path: 'accounts/expense/add',
      component: _accounts_expense_add_expense_add_expense_component__WEBPACK_IMPORTED_MODULE_20__["AddExpenseComponent"]
    }, {
      path: 'accounts/journal',
      component: _accounts_journal_journal_component__WEBPACK_IMPORTED_MODULE_21__["JournalComponent"]
    }, {
      path: 'accounts/report/cash-ledger',
      component: _accounts_report_cash_ledger_cash_ledger_component__WEBPACK_IMPORTED_MODULE_22__["CashLedgerComponent"]
    }, {
      path: 'accounts/report/trial-balance',
      component: _accounts_report_trial_balance_trial_balance_component__WEBPACK_IMPORTED_MODULE_23__["TrialBalanceComponent"]
    }, {
      path: 'accounts/report/income-statement',
      component: _accounts_report_income_statement_income_statement_component__WEBPACK_IMPORTED_MODULE_24__["IncomeStatementComponent"]
    }, {
      path: 'accounts/report/balance-sheet',
      component: _accounts_report_balance_sheet_balance_sheet_component__WEBPACK_IMPORTED_MODULE_25__["BalanceSheetComponent"]
    }, {
      path: 'accounts/report/general-ledger',
      component: _accounts_report_general_ladger_general_ladger_component__WEBPACK_IMPORTED_MODULE_29__["GeneralLadgerComponent"]
    }, {
      path: 'banks/add',
      component: _banks_add_new_bank_add_new_bank_component__WEBPACK_IMPORTED_MODULE_13__["AddNewBankComponent"]
    }, {
      path: 'banks/manage',
      component: _banks_manage_banks_manage_banks_component__WEBPACK_IMPORTED_MODULE_14__["ManageBanksComponent"]
    }, {
      path: 'stocks/manage',
      component: _stocks_manage_stocks_manage_stocks_component__WEBPACK_IMPORTED_MODULE_18__["ManageStocksComponent"]
    }, {
      path: 'offers/add',
      component: _offers_add_offer_add_offer_component__WEBPACK_IMPORTED_MODULE_26__["AddOfferComponent"]
    }, {
      path: 'test',
      component: _test_test_test_component__WEBPACK_IMPORTED_MODULE_27__["TestComponent"]
    }, {
      path: 'setup/cash',
      component: _setup_add_previous_cash_add_previous_cash_component__WEBPACK_IMPORTED_MODULE_30__["AddPreviousCashComponent"]
    }, {
      path: 'setup/inventory',
      component: _setup_add_previous_stock_add_previous_stock_component__WEBPACK_IMPORTED_MODULE_31__["AddPreviousStockComponent"]
    }];

    var AppRoutingModule = function AppRoutingModule() {
      _classCallCheck(this, AppRoutingModule);
    };

    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], AppRoutingModule);
    /***/
  },

  /***/
  "./src/app/app.component.css":
  /*!***********************************!*\
    !*** ./src/app/app.component.css ***!
    \***********************************/

  /*! exports provided: default */

  /***/
  function srcAppAppComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".wrapper {\r\n  display: -webkit-box;\r\n  display: flex;\r\n}\r\n\r\n.left {\r\n  -webkit-box-flex: 0;\r\n          flex: 0 0 280px;\r\n}\r\n\r\n.right {\r\n  -webkit-box-flex: 1;\r\n          flex: 1;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxvQkFBYTtFQUFiLGFBQWE7QUFDZjs7QUFFQTtFQUNFLG1CQUFlO1VBQWYsZUFBZTtBQUNqQjs7QUFFQTtFQUNFLG1CQUFPO1VBQVAsT0FBTztBQUNUIiwiZmlsZSI6InNyYy9hcHAvYXBwLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIud3JhcHBlciB7XHJcbiAgZGlzcGxheTogZmxleDtcclxufVxyXG5cclxuLmxlZnQge1xyXG4gIGZsZXg6IDAgMCAyODBweDtcclxufVxyXG5cclxuLnJpZ2h0IHtcclxuICBmbGV4OiAxO1xyXG59Il19 */";
    /***/
  },

  /***/
  "./src/app/app.component.ts":
  /*!**********************************!*\
    !*** ./src/app/app.component.ts ***!
    \**********************************/

  /*! exports provided: AppComponent */

  /***/
  function srcAppAppComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
      return AppComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var AppComponent =
    /*#__PURE__*/
    function () {
      function AppComponent() {
        _classCallCheck(this, AppComponent);

        this.title = 'EErpFrontEnd';
      }

      _createClass(AppComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var un = localStorage.getItem('username');
          var pw = localStorage.getItem('password'); // console.log(un, pw);

          if (un == null || pw == null) {
            this.isLoggedIn = false;
            return;
          }

          if (!un.localeCompare('admin') && !pw.localeCompare('112233')) {
            this.isLoggedIn = true;
          } else {
            this.isLoggedIn = false;
          }
        }
      }, {
        key: "onSubmit",
        value: function onSubmit() {
          if (!this.username.localeCompare('admin') && !this.password.localeCompare('112233')) {
            localStorage.setItem('username', this.username);
            localStorage.setItem('password', this.password);
            this.isLoggedIn = true;
          } else {
            this.isLoggedIn = false;
            alert("Invalid Credentials. Try again with valid username and password.");
          }
        }
      }]);

      return AppComponent;
    }();

    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-root',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./app.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./app.component.css */
      "./src/app/app.component.css")).default]
    })], AppComponent);
    /***/
  },

  /***/
  "./src/app/app.module.ts":
  /*!*******************************!*\
    !*** ./src/app/app.module.ts ***!
    \*******************************/

  /*! exports provided: AppModule */

  /***/
  function srcAppAppModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppModule", function () {
      return AppModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/platform-browser */
    "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _app_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./app-routing.module */
    "./src/app/app-routing.module.ts");
    /* harmony import */


    var _app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./app.component */
    "./src/app/app.component.ts");
    /* harmony import */


    var _side_menu_side_menu_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./side-menu/side-menu.component */
    "./src/app/side-menu/side-menu.component.ts");
    /* harmony import */


    var _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./dashboard/dashboard.component */
    "./src/app/dashboard/dashboard.component.ts");
    /* harmony import */


    var _products_add_product_add_product_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./products/add-product/add-product.component */
    "./src/app/products/add-product/add-product.component.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _purchases_add_purchase_add_purchase_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ./purchases/add-purchase/add-purchase.component */
    "./src/app/purchases/add-purchase/add-purchase.component.ts");
    /* harmony import */


    var _sales_add_sale_add_sale_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ./sales/add-sale/add-sale.component */
    "./src/app/sales/add-sale/add-sale.component.ts");
    /* harmony import */


    var _suppliers_add_supplier_add_supplier_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! ./suppliers/add-supplier/add-supplier.component */
    "./src/app/suppliers/add-supplier/add-supplier.component.ts");
    /* harmony import */


    var _customers_add_customer_add_customer_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! ./customers/add-customer/add-customer.component */
    "./src/app/customers/add-customer/add-customer.component.ts");
    /* harmony import */


    var _accounts_chart_of_account_chart_of_account_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! ./accounts/chart-of-account/chart-of-account.component */
    "./src/app/accounts/chart-of-account/chart-of-account.component.ts");
    /* harmony import */


    var _products_add_category_add_category_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
    /*! ./products/add-category/add-category.component */
    "./src/app/products/add-category/add-category.component.ts");
    /* harmony import */


    var _products_add_brand_add_brand_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
    /*! ./products/add-brand/add-brand.component */
    "./src/app/products/add-brand/add-brand.component.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _customers_manage_customer_manage_customer_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
    /*! ./customers/manage-customer/manage-customer.component */
    "./src/app/customers/manage-customer/manage-customer.component.ts");
    /* harmony import */


    var _banks_add_new_bank_add_new_bank_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(
    /*! ./banks/add-new-bank/add-new-bank.component */
    "./src/app/banks/add-new-bank/add-new-bank.component.ts");
    /* harmony import */


    var _banks_manage_banks_manage_banks_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(
    /*! ./banks/manage-banks/manage-banks.component */
    "./src/app/banks/manage-banks/manage-banks.component.ts");
    /* harmony import */


    var _suppliers_manage_suppliers_manage_suppliers_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(
    /*! ./suppliers/manage-suppliers/manage-suppliers.component */
    "./src/app/suppliers/manage-suppliers/manage-suppliers.component.ts");
    /* harmony import */


    var _products_manage_products_manage_products_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(
    /*! ./products/manage-products/manage-products.component */
    "./src/app/products/manage-products/manage-products.component.ts");
    /* harmony import */


    var _purchases_add_new_batch_add_new_batch_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(
    /*! ./purchases/add-new-batch/add-new-batch.component */
    "./src/app/purchases/add-new-batch/add-new-batch.component.ts");
    /* harmony import */


    var _stocks_manage_stocks_manage_stocks_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(
    /*! ./stocks/manage-stocks/manage-stocks.component */
    "./src/app/stocks/manage-stocks/manage-stocks.component.ts");
    /* harmony import */


    var _accounts_expense_add_expense_type_add_expense_type_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(
    /*! ./accounts/expense/add-expense-type/add-expense-type.component */
    "./src/app/accounts/expense/add-expense-type/add-expense-type.component.ts");
    /* harmony import */


    var _accounts_expense_add_expense_add_expense_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(
    /*! ./accounts/expense/add-expense/add-expense.component */
    "./src/app/accounts/expense/add-expense/add-expense.component.ts");
    /* harmony import */


    var _accounts_journal_journal_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(
    /*! ./accounts/journal/journal.component */
    "./src/app/accounts/journal/journal.component.ts");
    /* harmony import */


    var _accounts_report_cash_ledger_cash_ledger_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(
    /*! ./accounts/report/cash-ledger/cash-ledger.component */
    "./src/app/accounts/report/cash-ledger/cash-ledger.component.ts");
    /* harmony import */


    var _accounts_report_trial_balance_trial_balance_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(
    /*! ./accounts/report/trial-balance/trial-balance.component */
    "./src/app/accounts/report/trial-balance/trial-balance.component.ts");
    /* harmony import */


    var _accounts_report_income_statement_income_statement_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(
    /*! ./accounts/report/income-statement/income-statement.component */
    "./src/app/accounts/report/income-statement/income-statement.component.ts");
    /* harmony import */


    var _accounts_report_balance_sheet_balance_sheet_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(
    /*! ./accounts/report/balance-sheet/balance-sheet.component */
    "./src/app/accounts/report/balance-sheet/balance-sheet.component.ts");
    /* harmony import */


    var _offers_add_offer_add_offer_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(
    /*! ./offers/add-offer/add-offer.component */
    "./src/app/offers/add-offer/add-offer.component.ts");
    /* harmony import */


    var _test_test_test_component__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(
    /*! ./test/test/test.component */
    "./src/app/test/test/test.component.ts");
    /* harmony import */


    var _customers_add_warrenty_card_add_warrenty_card_component__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(
    /*! ./customers/add-warrenty-card/add-warrenty-card.component */
    "./src/app/customers/add-warrenty-card/add-warrenty-card.component.ts");
    /* harmony import */


    var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(
    /*! @ng-select/ng-select */
    "./node_modules/@ng-select/ng-select/fesm2015/ng-select-ng-select.js");
    /* harmony import */


    var _accounts_chart_of_account_tree_tree_component__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(
    /*! ./accounts/chart-of-account/tree/tree.component */
    "./src/app/accounts/chart-of-account/tree/tree.component.ts");
    /* harmony import */


    var _accounts_report_general_ladger_general_ladger_component__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(
    /*! ./accounts/report/general-ladger/general-ladger.component */
    "./src/app/accounts/report/general-ladger/general-ladger.component.ts");
    /* harmony import */


    var _setup_add_previous_cash_add_previous_cash_component__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(
    /*! ./setup/add-previous-cash/add-previous-cash.component */
    "./src/app/setup/add-previous-cash/add-previous-cash.component.ts");
    /* harmony import */


    var _setup_add_previous_stock_add_previous_stock_component__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(
    /*! ./setup/add-previous-stock/add-previous-stock.component */
    "./src/app/setup/add-previous-stock/add-previous-stock.component.ts");

    var AppModule = function AppModule() {
      _classCallCheck(this, AppModule);
    };

    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
      declarations: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"], _side_menu_side_menu_component__WEBPACK_IMPORTED_MODULE_5__["SideMenuComponent"], _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_6__["DashboardComponent"], _products_add_product_add_product_component__WEBPACK_IMPORTED_MODULE_7__["AddProductComponent"], _purchases_add_purchase_add_purchase_component__WEBPACK_IMPORTED_MODULE_9__["AddPurchaseComponent"], _sales_add_sale_add_sale_component__WEBPACK_IMPORTED_MODULE_10__["AddSaleComponent"], _suppliers_add_supplier_add_supplier_component__WEBPACK_IMPORTED_MODULE_11__["AddSupplierComponent"], _customers_add_customer_add_customer_component__WEBPACK_IMPORTED_MODULE_12__["AddCustomerComponent"], _accounts_chart_of_account_chart_of_account_component__WEBPACK_IMPORTED_MODULE_13__["ChartOfAccountComponent"], _products_add_category_add_category_component__WEBPACK_IMPORTED_MODULE_14__["AddCategoryComponent"], _products_add_brand_add_brand_component__WEBPACK_IMPORTED_MODULE_15__["AddBrandComponent"], _customers_manage_customer_manage_customer_component__WEBPACK_IMPORTED_MODULE_17__["ManageCustomerComponent"], _banks_add_new_bank_add_new_bank_component__WEBPACK_IMPORTED_MODULE_18__["AddNewBankComponent"], _banks_manage_banks_manage_banks_component__WEBPACK_IMPORTED_MODULE_19__["ManageBanksComponent"], _suppliers_manage_suppliers_manage_suppliers_component__WEBPACK_IMPORTED_MODULE_20__["ManageSuppliersComponent"], _products_manage_products_manage_products_component__WEBPACK_IMPORTED_MODULE_21__["ManageProductsComponent"], _purchases_add_new_batch_add_new_batch_component__WEBPACK_IMPORTED_MODULE_22__["AddNewBatchComponent"], _stocks_manage_stocks_manage_stocks_component__WEBPACK_IMPORTED_MODULE_23__["ManageStocksComponent"], _accounts_expense_add_expense_type_add_expense_type_component__WEBPACK_IMPORTED_MODULE_24__["AddExpenseTypeComponent"], _accounts_expense_add_expense_add_expense_component__WEBPACK_IMPORTED_MODULE_25__["AddExpenseComponent"], _accounts_journal_journal_component__WEBPACK_IMPORTED_MODULE_26__["JournalComponent"], _accounts_report_cash_ledger_cash_ledger_component__WEBPACK_IMPORTED_MODULE_27__["CashLedgerComponent"], _accounts_report_trial_balance_trial_balance_component__WEBPACK_IMPORTED_MODULE_28__["TrialBalanceComponent"], _accounts_report_income_statement_income_statement_component__WEBPACK_IMPORTED_MODULE_29__["IncomeStatementComponent"], _accounts_report_balance_sheet_balance_sheet_component__WEBPACK_IMPORTED_MODULE_30__["BalanceSheetComponent"], _offers_add_offer_add_offer_component__WEBPACK_IMPORTED_MODULE_31__["AddOfferComponent"], _test_test_test_component__WEBPACK_IMPORTED_MODULE_32__["TestComponent"], _customers_add_warrenty_card_add_warrenty_card_component__WEBPACK_IMPORTED_MODULE_33__["AddWarrentyCardComponent"], _accounts_chart_of_account_tree_tree_component__WEBPACK_IMPORTED_MODULE_35__["TreeComponent"], _accounts_report_general_ladger_general_ladger_component__WEBPACK_IMPORTED_MODULE_36__["GeneralLadgerComponent"], _setup_add_previous_cash_add_previous_cash_component__WEBPACK_IMPORTED_MODULE_37__["AddPreviousCashComponent"], _setup_add_previous_stock_add_previous_stock_component__WEBPACK_IMPORTED_MODULE_38__["AddPreviousStockComponent"]],
      imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_3__["AppRoutingModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormsModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_16__["HttpClientModule"], _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_34__["NgSelectModule"]],
      providers: [],
      bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"]]
    })], AppModule);
    /***/
  },

  /***/
  "./src/app/banks/add-new-bank/add-new-bank.component.css":
  /*!***************************************************************!*\
    !*** ./src/app/banks/add-new-bank/add-new-bank.component.css ***!
    \***************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppBanksAddNewBankAddNewBankComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2JhbmtzL2FkZC1uZXctYmFuay9hZGQtbmV3LWJhbmsuY29tcG9uZW50LmNzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/banks/add-new-bank/add-new-bank.component.ts":
  /*!**************************************************************!*\
    !*** ./src/app/banks/add-new-bank/add-new-bank.component.ts ***!
    \**************************************************************/

  /*! exports provided: AddNewBankComponent */

  /***/
  function srcAppBanksAddNewBankAddNewBankComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AddNewBankComponent", function () {
      return AddNewBankComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_shared_models_bank_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/shared/models/bank.model */
    "./src/app/shared/models/bank.model.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");

    var AddNewBankComponent =
    /*#__PURE__*/
    function () {
      function AddNewBankComponent(http, router, cs) {
        _classCallCheck(this, AddNewBankComponent);

        this.http = http;
        this.router = router;
        this.cs = cs;
        this.model = new src_app_shared_models_bank_model__WEBPACK_IMPORTED_MODULE_2__["Bank"]();
      }

      _createClass(AddNewBankComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "onSubmit",
        value: function onSubmit() {
          console.log(this.model);
          this.http.post(this.cs.getApiURL() + "Banks/PostBankInfo", this.model, {
            headers: {
              "Content-Type": "application/json"
            }
          }).subscribe(function (data) {
            alert("Data Entry Success");
          }, function (error) {
            alert("Error Occured");
          });
          this.router.navigate(['/dashboard']);
        }
      }]);

      return AddNewBankComponent;
    }();

    AddNewBankComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"]
      }];
    };

    AddNewBankComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-add-new-bank',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./add-new-bank.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/banks/add-new-bank/add-new-bank.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./add-new-bank.component.css */
      "./src/app/banks/add-new-bank/add-new-bank.component.css")).default]
    })], AddNewBankComponent);
    /***/
  },

  /***/
  "./src/app/banks/manage-banks/manage-banks.component.css":
  /*!***************************************************************!*\
    !*** ./src/app/banks/manage-banks/manage-banks.component.css ***!
    \***************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppBanksManageBanksManageBanksComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "th a {\r\n    text-decoration: none;\r\n    text-align: center;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYmFua3MvbWFuYWdlLWJhbmtzL21hbmFnZS1iYW5rcy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0kscUJBQXFCO0lBQ3JCLGtCQUFrQjtBQUN0QiIsImZpbGUiOiJzcmMvYXBwL2JhbmtzL21hbmFnZS1iYW5rcy9tYW5hZ2UtYmFua3MuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbInRoIGEge1xyXG4gICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59Il19 */";
    /***/
  },

  /***/
  "./src/app/banks/manage-banks/manage-banks.component.ts":
  /*!**************************************************************!*\
    !*** ./src/app/banks/manage-banks/manage-banks.component.ts ***!
    \**************************************************************/

  /*! exports provided: ManageBanksComponent */

  /***/
  function srcAppBanksManageBanksManageBanksComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ManageBanksComponent", function () {
      return ManageBanksComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");

    var ManageBanksComponent =
    /*#__PURE__*/
    function () {
      function ManageBanksComponent(http, cs) {
        _classCallCheck(this, ManageBanksComponent);

        this.http = http;
        this.cs = cs;
      }

      _createClass(ManageBanksComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this11 = this;

          this.http.get(this.cs.getApiURL() + "Banks/GetBankInfoes").subscribe(function (data) {
            _this11.modelData = data;
            console.log(data);
          }, function (error) {
            console.log(error);
          });
        }
      }, {
        key: "editBank",
        value: function editBank(bankCode) {
          console.log(bankCode);
        }
      }, {
        key: "deleteBank",
        value: function deleteBank(bankCode) {
          this.http.delete(this.cs.getApiURL() + "Banks/DeleteBankInfo/" + bankCode).subscribe(function (data) {
            alert("Data Deletion Successful");
          }, function (error) {
            alert("Error Occurred");
          });
        }
      }]);

      return ManageBanksComponent;
    }();

    ManageBanksComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__["CommonService"]
      }];
    };

    ManageBanksComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-manage-banks',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./manage-banks.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/banks/manage-banks/manage-banks.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./manage-banks.component.css */
      "./src/app/banks/manage-banks/manage-banks.component.css")).default]
    })], ManageBanksComponent);
    /***/
  },

  /***/
  "./src/app/customers/add-customer/add-customer.component.css":
  /*!*******************************************************************!*\
    !*** ./src/app/customers/add-customer/add-customer.component.css ***!
    \*******************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppCustomersAddCustomerAddCustomerComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2N1c3RvbWVycy9hZGQtY3VzdG9tZXIvYWRkLWN1c3RvbWVyLmNvbXBvbmVudC5jc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/customers/add-customer/add-customer.component.ts":
  /*!******************************************************************!*\
    !*** ./src/app/customers/add-customer/add-customer.component.ts ***!
    \******************************************************************/

  /*! exports provided: AddCustomerComponent */

  /***/
  function srcAppCustomersAddCustomerAddCustomerComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AddCustomerComponent", function () {
      return AddCustomerComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_shared_models_customer_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/shared/models/customer.model */
    "./src/app/shared/models/customer.model.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");

    var AddCustomerComponent =
    /*#__PURE__*/
    function () {
      function AddCustomerComponent(router, route, http, cs) {
        _classCallCheck(this, AddCustomerComponent);

        this.router = router;
        this.route = route;
        this.http = http;
        this.cs = cs;
        this.model = new src_app_shared_models_customer_model__WEBPACK_IMPORTED_MODULE_2__["Customer"]();
      }

      _createClass(AddCustomerComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "onSubmit",
        value: function onSubmit() {
          var _this12 = this;

          console.log(this.model);
          var redirectUrl = this.route.snapshot.queryParams;
          this.http.post(this.cs.getApiURL() + "Customers/PostCustomerInfo", this.model, {
            headers: {
              "Content-Type": "application/json"
            }
          }).subscribe(function (data) {
            alert("Data Entry Success");

            if (redirectUrl['redirectUrl']) {
              _this12.router.navigateByUrl(redirectUrl['redirectUrl']).catch(function () {
                return _this12.ngOnInit();
              });
            } else {
              _this12.ngOnInit();
            }
          }, function (error) {
            alert("Error Occured");
          }); // this.router.navigate(['/dashboard']);
        }
      }]);

      return AddCustomerComponent;
    }();

    AddCustomerComponent.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }, {
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"]
      }];
    };

    AddCustomerComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-add-customer',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./add-customer.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/customers/add-customer/add-customer.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./add-customer.component.css */
      "./src/app/customers/add-customer/add-customer.component.css")).default]
    })], AddCustomerComponent);
    /***/
  },

  /***/
  "./src/app/customers/add-warrenty-card/add-warrenty-card.component.css":
  /*!*****************************************************************************!*\
    !*** ./src/app/customers/add-warrenty-card/add-warrenty-card.component.css ***!
    \*****************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppCustomersAddWarrentyCardAddWarrentyCardComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2N1c3RvbWVycy9hZGQtd2FycmVudHktY2FyZC9hZGQtd2FycmVudHktY2FyZC5jb21wb25lbnQuY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/customers/add-warrenty-card/add-warrenty-card.component.ts":
  /*!****************************************************************************!*\
    !*** ./src/app/customers/add-warrenty-card/add-warrenty-card.component.ts ***!
    \****************************************************************************/

  /*! exports provided: AddWarrentyCardComponent */

  /***/
  function srcAppCustomersAddWarrentyCardAddWarrentyCardComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AddWarrentyCardComponent", function () {
      return AddWarrentyCardComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var AddWarrentyCardComponent =
    /*#__PURE__*/
    function () {
      function AddWarrentyCardComponent() {
        _classCallCheck(this, AddWarrentyCardComponent);
      }

      _createClass(AddWarrentyCardComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "onSubmit",
        value: function onSubmit() {}
      }]);

      return AddWarrentyCardComponent;
    }();

    AddWarrentyCardComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-add-warrenty-card',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./add-warrenty-card.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/customers/add-warrenty-card/add-warrenty-card.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./add-warrenty-card.component.css */
      "./src/app/customers/add-warrenty-card/add-warrenty-card.component.css")).default]
    })], AddWarrentyCardComponent);
    /***/
  },

  /***/
  "./src/app/customers/manage-customer/manage-customer.component.css":
  /*!*************************************************************************!*\
    !*** ./src/app/customers/manage-customer/manage-customer.component.css ***!
    \*************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppCustomersManageCustomerManageCustomerComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2N1c3RvbWVycy9tYW5hZ2UtY3VzdG9tZXIvbWFuYWdlLWN1c3RvbWVyLmNvbXBvbmVudC5jc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/customers/manage-customer/manage-customer.component.ts":
  /*!************************************************************************!*\
    !*** ./src/app/customers/manage-customer/manage-customer.component.ts ***!
    \************************************************************************/

  /*! exports provided: ManageCustomerComponent */

  /***/
  function srcAppCustomersManageCustomerManageCustomerComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ManageCustomerComponent", function () {
      return ManageCustomerComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");

    var ManageCustomerComponent =
    /*#__PURE__*/
    function () {
      function ManageCustomerComponent(http, cs) {
        _classCallCheck(this, ManageCustomerComponent);

        this.http = http;
        this.cs = cs;
      }

      _createClass(ManageCustomerComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this13 = this;

          this.http.get(this.cs.getApiURL() + "Customers/GetCustomerInfoes").subscribe(function (data) {
            _this13.modelData = data;
          }, function (error) {
            console.log(error);
          });
        }
      }]);

      return ManageCustomerComponent;
    }();

    ManageCustomerComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__["CommonService"]
      }];
    };

    ManageCustomerComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-manage-customer',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./manage-customer.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/customers/manage-customer/manage-customer.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./manage-customer.component.css */
      "./src/app/customers/manage-customer/manage-customer.component.css")).default]
    })], ManageCustomerComponent);
    /***/
  },

  /***/
  "./src/app/dashboard/dashboard.component.css":
  /*!***************************************************!*\
    !*** ./src/app/dashboard/dashboard.component.css ***!
    \***************************************************/

  /*! exports provided: default */

  /***/
  function srcAppDashboardDashboardComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Rhc2hib2FyZC9kYXNoYm9hcmQuY29tcG9uZW50LmNzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/dashboard/dashboard.component.ts":
  /*!**************************************************!*\
    !*** ./src/app/dashboard/dashboard.component.ts ***!
    \**************************************************/

  /*! exports provided: DashboardComponent */

  /***/
  function srcAppDashboardDashboardComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DashboardComponent", function () {
      return DashboardComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../shared/services/common.service */
    "./src/app/shared/services/common.service.ts");

    var DashboardComponent =
    /*#__PURE__*/
    function () {
      function DashboardComponent(http, cs) {
        _classCallCheck(this, DashboardComponent);

        this.http = http;
        this.cs = cs;
      }

      _createClass(DashboardComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this14 = this;

          // console.log(btoa("admin::r4sel::123456"));
          this.http.get(this.cs.getApiURL() + "conf_Accounts/GetDashboard").subscribe(function (data) {
            _this14.dashElements = data;
          }, function (error) {
            alert("try reloading this page");
          });
        }
      }]);

      return DashboardComponent;
    }();

    DashboardComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: _shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__["CommonService"]
      }];
    };

    DashboardComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-dashboard',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./dashboard.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/dashboard/dashboard.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./dashboard.component.css */
      "./src/app/dashboard/dashboard.component.css")).default]
    })], DashboardComponent);
    /***/
  },

  /***/
  "./src/app/offers/add-offer/add-offer.component.css":
  /*!**********************************************************!*\
    !*** ./src/app/offers/add-offer/add-offer.component.css ***!
    \**********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppOffersAddOfferAddOfferComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL29mZmVycy9hZGQtb2ZmZXIvYWRkLW9mZmVyLmNvbXBvbmVudC5jc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/offers/add-offer/add-offer.component.ts":
  /*!*********************************************************!*\
    !*** ./src/app/offers/add-offer/add-offer.component.ts ***!
    \*********************************************************/

  /*! exports provided: AddOfferComponent */

  /***/
  function srcAppOffersAddOfferAddOfferComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AddOfferComponent", function () {
      return AddOfferComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_shared_models_offers_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/shared/models/offers.model */
    "./src/app/shared/models/offers.model.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");

    var AddOfferComponent =
    /*#__PURE__*/
    function () {
      function AddOfferComponent(http, cs, router) {
        _classCallCheck(this, AddOfferComponent);

        this.http = http;
        this.cs = cs;
        this.router = router;
        this.model = new src_app_shared_models_offers_model__WEBPACK_IMPORTED_MODULE_2__["Offers"]();
      }

      _createClass(AddOfferComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this15 = this;

          this.http.get(this.cs.getApiURL() + "Products/GetProductInfoes").subscribe(function (data) {
            _this15.ProductList = data;
          });
          this.http.get(this.cs.getApiURL() + "Offers/GetOffersInfoes").subscribe(function (data) {
            _this15.OfferList = data;
          });
        }
      }, {
        key: "onSubmit",
        value: function onSubmit() {
          console.log(this.model);
          this.http.post(this.cs.getApiURL() + "Offers/PostOffersInfo", this.model, {
            headers: {
              "Content-Type": "application/json"
            }
          }).subscribe(function (data) {
            alert("Offer saved successfully");
          }, function (error) {
            alert("Error! please try again.");
          });
        }
      }]);

      return AddOfferComponent;
    }();

    AddOfferComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_4__["CommonService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]
      }];
    };

    AddOfferComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-add-offer',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./add-offer.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/offers/add-offer/add-offer.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./add-offer.component.css */
      "./src/app/offers/add-offer/add-offer.component.css")).default]
    })], AddOfferComponent);
    /***/
  },

  /***/
  "./src/app/products/add-brand/add-brand.component.css":
  /*!************************************************************!*\
    !*** ./src/app/products/add-brand/add-brand.component.css ***!
    \************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppProductsAddBrandAddBrandComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "span {\r\n    padding-right: 15px;\r\n}\r\n\r\nspan::after {\r\n    content: \",\";\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJvZHVjdHMvYWRkLWJyYW5kL2FkZC1icmFuZC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksbUJBQW1CO0FBQ3ZCOztBQUVBO0lBQ0ksWUFBWTtBQUNoQiIsImZpbGUiOiJzcmMvYXBwL3Byb2R1Y3RzL2FkZC1icmFuZC9hZGQtYnJhbmQuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbInNwYW4ge1xyXG4gICAgcGFkZGluZy1yaWdodDogMTVweDtcclxufVxyXG5cclxuc3Bhbjo6YWZ0ZXIge1xyXG4gICAgY29udGVudDogXCIsXCI7XHJcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/products/add-brand/add-brand.component.ts":
  /*!***********************************************************!*\
    !*** ./src/app/products/add-brand/add-brand.component.ts ***!
    \***********************************************************/

  /*! exports provided: AddBrandComponent */

  /***/
  function srcAppProductsAddBrandAddBrandComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AddBrandComponent", function () {
      return AddBrandComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");
    /* harmony import */


    var src_app_shared_models_brand_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/shared/models/brand.model */
    "./src/app/shared/models/brand.model.ts");

    var AddBrandComponent =
    /*#__PURE__*/
    function () {
      function AddBrandComponent(http, router, cs) {
        _classCallCheck(this, AddBrandComponent);

        this.http = http;
        this.router = router;
        this.cs = cs;
        this.model = new src_app_shared_models_brand_model__WEBPACK_IMPORTED_MODULE_5__["Brand"]();
      }

      _createClass(AddBrandComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this16 = this;

          this.http.get(this.cs.getApiURL() + "Brands/GetBrandInfoes").subscribe(function (data) {
            _this16.brandList = data;
          }, function (error) {
            alert("Error occured! Try reloading this page.");
          });
        }
      }, {
        key: "onSubmit",
        value: function onSubmit() {
          this.http.post(this.cs.getApiURL() + "Brands/PostBrandInfo", this.model).subscribe(function (data) {
            alert("Data Entry Success!");
          }, function (error) {
            alert("Failed. Try agin please!");
          });
          this.router.navigate(['/dashboard']);
        }
      }]);

      return AddBrandComponent;
    }();

    AddBrandComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_4__["CommonService"]
      }];
    };

    AddBrandComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-add-brand',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./add-brand.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/products/add-brand/add-brand.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./add-brand.component.css */
      "./src/app/products/add-brand/add-brand.component.css")).default]
    })], AddBrandComponent);
    /***/
  },

  /***/
  "./src/app/products/add-category/add-category.component.css":
  /*!******************************************************************!*\
    !*** ./src/app/products/add-category/add-category.component.css ***!
    \******************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppProductsAddCategoryAddCategoryComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "span {\r\n    padding-right: 15px;\r\n}\r\n\r\nspan::after {\r\n    content: \",\";\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJvZHVjdHMvYWRkLWNhdGVnb3J5L2FkZC1jYXRlZ29yeS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksbUJBQW1CO0FBQ3ZCOztBQUVBO0lBQ0ksWUFBWTtBQUNoQiIsImZpbGUiOiJzcmMvYXBwL3Byb2R1Y3RzL2FkZC1jYXRlZ29yeS9hZGQtY2F0ZWdvcnkuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbInNwYW4ge1xyXG4gICAgcGFkZGluZy1yaWdodDogMTVweDtcclxufVxyXG5cclxuc3Bhbjo6YWZ0ZXIge1xyXG4gICAgY29udGVudDogXCIsXCI7XHJcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/products/add-category/add-category.component.ts":
  /*!*****************************************************************!*\
    !*** ./src/app/products/add-category/add-category.component.ts ***!
    \*****************************************************************/

  /*! exports provided: AddCategoryComponent */

  /***/
  function srcAppProductsAddCategoryAddCategoryComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AddCategoryComponent", function () {
      return AddCategoryComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_shared_models_category_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/shared/models/category.model */
    "./src/app/shared/models/category.model.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");

    var AddCategoryComponent =
    /*#__PURE__*/
    function () {
      function AddCategoryComponent(http, cs, router) {
        _classCallCheck(this, AddCategoryComponent);

        this.http = http;
        this.cs = cs;
        this.router = router;
        this.model = new src_app_shared_models_category_model__WEBPACK_IMPORTED_MODULE_2__["Category"]();
      }

      _createClass(AddCategoryComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this17 = this;

          this.http.get(this.cs.getApiURL() + "Categories/GetCategoryInfoes").subscribe(function (data) {
            _this17.categoryList = data;
          }, function (error) {
            alert("Error! Try reloading this page");
          });
        }
      }, {
        key: "onSubmit",
        value: function onSubmit() {
          this.http.post(this.cs.getApiURL() + "Categories/PostCategoryInfo", this.model).subscribe(function (data) {
            alert("Data Entry Success!");
          }, function (error) {
            alert("Failed. Try agin please!");
          });
          this.router.navigate(['/dashboard']);
        }
      }]);

      return AddCategoryComponent;
    }();

    AddCategoryComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_4__["CommonService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]
      }];
    };

    AddCategoryComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-add-category',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./add-category.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/products/add-category/add-category.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./add-category.component.css */
      "./src/app/products/add-category/add-category.component.css")).default]
    })], AddCategoryComponent);
    /***/
  },

  /***/
  "./src/app/products/add-product/add-product.component.css":
  /*!****************************************************************!*\
    !*** ./src/app/products/add-product/add-product.component.css ***!
    \****************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppProductsAddProductAddProductComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3Byb2R1Y3RzL2FkZC1wcm9kdWN0L2FkZC1wcm9kdWN0LmNvbXBvbmVudC5jc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/products/add-product/add-product.component.ts":
  /*!***************************************************************!*\
    !*** ./src/app/products/add-product/add-product.component.ts ***!
    \***************************************************************/

  /*! exports provided: AddProductComponent */

  /***/
  function srcAppProductsAddProductAddProductComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AddProductComponent", function () {
      return AddProductComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_shared_models_product_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/shared/models/product.model */
    "./src/app/shared/models/product.model.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");

    var AddProductComponent =
    /*#__PURE__*/
    function () {
      function AddProductComponent(router, http, cs) {
        _classCallCheck(this, AddProductComponent);

        this.router = router;
        this.http = http;
        this.cs = cs; // Some Bulk Data

        this.ProductUnits = ["Pcs", "Kg", "Lbs", "Litre"];
        this.commissionType = 'percentage';
        this.model = new src_app_shared_models_product_model__WEBPACK_IMPORTED_MODULE_2__["Product"]();
      }

      _createClass(AddProductComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this18 = this;

          this.http.get(this.cs.getApiURL() + "Suppliers/GetSupplierInfoes").subscribe(function (data) {
            _this18.Suppliers = data;
            console.log(data);
          }, function (error) {
            alert("Error occurred. try reloading the page.");
          });
          this.http.get(this.cs.getApiURL() + "Categories/GetCategoryInfoes").subscribe(function (data) {
            _this18.Categories = data;
          }, function (error) {
            alert("Error occurred.. try reloading the page.");
          });
          this.http.get(this.cs.getApiURL() + "Brands/GetBrandInfoes").subscribe(function (data) {
            _this18.Brands = data;
          }, function (error) {
            alert("Error occurred.. try reloading the page.");
          });
          this.model.ProductUnit = "Pcs";
          this.model.CommissionInPercent = 0;
        }
      }, {
        key: "onSubmit",
        value: function onSubmit() {
          console.log(this.model);
          this.model.ProductSupplier = Number(this.model.ProductSupplier);
          this.model.ProductCategory = Number(this.model.ProductCategory);
          this.model.ProductBrand = Number(this.model.ProductBrand);
          this.model.ProductDetails += "ICTforma";

          if (this.commissionType == 'percentage') {
            this.model.CommissionInPercent = this.commissionAmount;
          } else if (this.commissionType == "rawAmount") {
            this.model.CommissionInPercent = this.commissionAmount / this.model.ProductSalePrice * 100;
          }

          console.log("----------------------------");
          console.log(this.model);
          this.http.post(this.cs.getApiURL() + "Products/PostProductInfo", this.model, {
            headers: {
              "Content-Type": "application/json"
            }
          }).subscribe(function (data) {
            alert("data record success"); // defaultBatch.ProductCode = data.ProductCode;
          }, function (error) {
            alert("error! try agin please");
          });
          this.router.navigate(['/dashboard']);
        }
      }, {
        key: "onSupplierChange",
        value: function onSupplierChange(event) {
          console.log(event);
          console.log(this.model.ProductSupplier);
        }
      }, {
        key: "commissionTypeChange",
        value: function commissionTypeChange(event) {
          console.log(this.model.ProductSalePrice);

          if (this.model.ProductSalePrice == undefined) {
            alert("Sale Price (MRP) is required");
            return;
          }

          this.commissionAmount = undefined;
        }
      }, {
        key: "commissionAmountChange",
        value: function commissionAmountChange(event) {
          if (this.model.ProductSalePrice == undefined) {
            alert("Sale Price (MRP) is required");
            return;
          }

          if (this.commissionType == 'percentage') {
            this.model.ProductPurchasePrice = this.model.ProductSalePrice - this.model.ProductSalePrice * this.commissionAmount / 100;
          } else if (this.commissionType == "rawAmount") {
            this.model.ProductPurchasePrice = this.model.ProductSalePrice - this.commissionAmount;
          }
        }
      }]);

      return AddProductComponent;
    }();

    AddProductComponent.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"]
      }];
    };

    AddProductComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-add-product',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./add-product.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/products/add-product/add-product.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./add-product.component.css */
      "./src/app/products/add-product/add-product.component.css")).default]
    })], AddProductComponent);
    /***/
  },

  /***/
  "./src/app/products/manage-products/manage-products.component.css":
  /*!************************************************************************!*\
    !*** ./src/app/products/manage-products/manage-products.component.css ***!
    \************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppProductsManageProductsManageProductsComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3Byb2R1Y3RzL21hbmFnZS1wcm9kdWN0cy9tYW5hZ2UtcHJvZHVjdHMuY29tcG9uZW50LmNzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/products/manage-products/manage-products.component.ts":
  /*!***********************************************************************!*\
    !*** ./src/app/products/manage-products/manage-products.component.ts ***!
    \***********************************************************************/

  /*! exports provided: ManageProductsComponent */

  /***/
  function srcAppProductsManageProductsManageProductsComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ManageProductsComponent", function () {
      return ManageProductsComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");

    var ManageProductsComponent =
    /*#__PURE__*/
    function () {
      function ManageProductsComponent(http, cs) {
        _classCallCheck(this, ManageProductsComponent);

        this.http = http;
        this.cs = cs;
      }

      _createClass(ManageProductsComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this19 = this;

          this.http.get(this.cs.getApiURL() + "Products/GetProductInfoes").subscribe(function (data) {
            _this19.modelData = data; // console.log(data);
          }, function (error) {
            console.log(error);
          });
        }
      }, {
        key: "editProduct",
        value: function editProduct(productCode) {
          console.log(productCode);
        }
      }, {
        key: "deleteProduct",
        value: function deleteProduct(productCode) {
          var _this20 = this;

          this.http.delete(this.cs.getApiURL() + "Products/DeleteProductInfo/" + productCode).subscribe(function (data) {
            alert("Data Deletion Successful");

            _this20.ngOnInit();
          }, function (error) {
            alert("Error Occurred");
          });
        }
      }]);

      return ManageProductsComponent;
    }();

    ManageProductsComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__["CommonService"]
      }];
    };

    ManageProductsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-manage-products',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./manage-products.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/products/manage-products/manage-products.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./manage-products.component.css */
      "./src/app/products/manage-products/manage-products.component.css")).default]
    })], ManageProductsComponent);
    /***/
  },

  /***/
  "./src/app/purchases/add-new-batch/add-new-batch.component.css":
  /*!*********************************************************************!*\
    !*** ./src/app/purchases/add-new-batch/add-new-batch.component.css ***!
    \*********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPurchasesAddNewBatchAddNewBatchComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".ng-select.custom {\r\n    border:0px;\r\n    min-height: 0px;\r\n    border-radius: 0;\r\n    background-color: white;\r\n}\r\n.ng-select.custom .ng-select-container  {            \r\n    min-height: 0px;\r\n    border-radius: 0;\r\n    background-color: wheat;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHVyY2hhc2VzL2FkZC1uZXctYmF0Y2gvYWRkLW5ldy1iYXRjaC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksVUFBVTtJQUNWLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsdUJBQXVCO0FBQzNCO0FBQ0E7SUFDSSxlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLHVCQUF1QjtBQUMzQiIsImZpbGUiOiJzcmMvYXBwL3B1cmNoYXNlcy9hZGQtbmV3LWJhdGNoL2FkZC1uZXctYmF0Y2guY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5uZy1zZWxlY3QuY3VzdG9tIHtcclxuICAgIGJvcmRlcjowcHg7XHJcbiAgICBtaW4taGVpZ2h0OiAwcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbn1cclxuLm5nLXNlbGVjdC5jdXN0b20gLm5nLXNlbGVjdC1jb250YWluZXIgIHsgICAgICAgICAgICBcclxuICAgIG1pbi1oZWlnaHQ6IDBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDA7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGVhdDtcclxufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/purchases/add-new-batch/add-new-batch.component.ts":
  /*!********************************************************************!*\
    !*** ./src/app/purchases/add-new-batch/add-new-batch.component.ts ***!
    \********************************************************************/

  /*! exports provided: AddNewBatchComponent */

  /***/
  function srcAppPurchasesAddNewBatchAddNewBatchComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AddNewBatchComponent", function () {
      return AddNewBatchComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_shared_models_batch_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/shared/models/batch.model */
    "./src/app/shared/models/batch.model.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");

    var AddNewBatchComponent =
    /*#__PURE__*/
    function () {
      function AddNewBatchComponent(http, cs, router, route) {
        _classCallCheck(this, AddNewBatchComponent);

        this.http = http;
        this.cs = cs;
        this.router = router;
        this.route = route;
        this.model = new src_app_shared_models_batch_model__WEBPACK_IMPORTED_MODULE_2__["Batch"]();
        this.commissionType = 'percentage';
      }

      _createClass(AddNewBatchComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this21 = this;

          this.model.CommissionAmount = 0;
          this.http.get(this.cs.getApiURL() + "Products/GetProductInfoes").subscribe(function (data) {
            _this21.ProductList = data;
          });
          this.http.get(this.cs.getApiURL() + "Batches/GetBatchInfoes").subscribe(function (data) {
            _this21.BatchList = data;
          });
        }
      }, {
        key: "onSubmit",
        value: function onSubmit() {
          var _this22 = this;

          var redirectUrl = this.route.snapshot.queryParams;
          this.model.CommissionAmount = this.productPurchasePrice;
          console.log(this.model);
          this.http.post(this.cs.getApiURL() + "Batches/PostBatchInfo", this.model, {
            headers: {
              "Content-Type": "application/json"
            }
          }).subscribe(function (data) {
            alert("LOT saved successfully"); // this.ngOnInit();

            if (redirectUrl['redirectUrl']) {
              _this22.router.navigateByUrl(redirectUrl['redirectUrl']).catch(function () {
                return _this22.ngOnInit();
              });
            } else {
              _this22.ngOnInit();
            }
          }, function (error) {
            alert("Error! please try again.");
          });
        }
      }, {
        key: "commissionTypeChange",
        value: function commissionTypeChange(event) {
          if (this.model.ProductCode == undefined) {
            alert("Select Product First");
            return;
          }

          this.commissionAmount = 0;
          this.commissionAmountChange();
        }
      }, {
        key: "onProductChange",
        value: function onProductChange(productCode) {
          var _this23 = this;

          console.log(productCode);
          this.http.get(this.cs.getApiURL() + "Products/GetProductBasePrice?id=" + productCode).subscribe(function (data) {
            _this23.productSalePrice = data;

            _this23.commissionAmountChange();
          });
        }
      }, {
        key: "commissionAmountChange",
        value: function commissionAmountChange() {
          if (!this.commissionType.localeCompare('percentage')) {
            this.productPurchasePrice = this.productSalePrice - this.productSalePrice * this.model.CommissionAmount / 100;
          } else {
            this.productPurchasePrice = this.productSalePrice - this.model.CommissionAmount;
          }
        }
      }, {
        key: "showProductDropDown",
        value: function showProductDropDown() {
          document.getElementById("myDropdown").classList.toggle("show");
        }
      }, {
        key: "filterProductOnDropDown",
        value: function filterProductOnDropDown() {
          var input = document.getElementById("myInput");
          var filter = input.value.toUpperCase();
          var div = document.getElementById("myDropdown");
          var a = div.getElementsByTagName("a");
          var txtValue;

          for (var i = 0; i < a.length; i++) {
            txtValue = a[i].textContent || a[i].innerText;

            if (txtValue.toUpperCase().indexOf(filter) > -1) {
              a[i].style.display = "";
            } else {
              a[i].style.display = "none";
            }
          }
        }
      }]);

      return AddNewBatchComponent;
    }();

    AddNewBatchComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }];
    };

    AddNewBatchComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-add-new-batch',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./add-new-batch.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/purchases/add-new-batch/add-new-batch.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./add-new-batch.component.css */
      "./src/app/purchases/add-new-batch/add-new-batch.component.css")).default]
    })], AddNewBatchComponent);
    /***/
  },

  /***/
  "./src/app/purchases/add-purchase/add-purchase.component.css":
  /*!*******************************************************************!*\
    !*** ./src/app/purchases/add-purchase/add-purchase.component.css ***!
    \*******************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPurchasesAddPurchaseAddPurchaseComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".row {\r\n    margin-bottom: 5px;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHVyY2hhc2VzL2FkZC1wdXJjaGFzZS9hZGQtcHVyY2hhc2UuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGtCQUFrQjtBQUN0QiIsImZpbGUiOiJzcmMvYXBwL3B1cmNoYXNlcy9hZGQtcHVyY2hhc2UvYWRkLXB1cmNoYXNlLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucm93IHtcclxuICAgIG1hcmdpbi1ib3R0b206IDVweDtcclxufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/purchases/add-purchase/add-purchase.component.ts":
  /*!******************************************************************!*\
    !*** ./src/app/purchases/add-purchase/add-purchase.component.ts ***!
    \******************************************************************/

  /*! exports provided: AddPurchaseComponent */

  /***/
  function srcAppPurchasesAddPurchaseAddPurchaseComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AddPurchaseComponent", function () {
      return AddPurchaseComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_shared_models_purchase_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/shared/models/purchase.model */
    "./src/app/shared/models/purchase.model.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");
    /* harmony import */


    var src_app_shared_models_stock_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/shared/models/stock.model */
    "./src/app/shared/models/stock.model.ts");
    /* harmony import */


    var src_app_shared_models_purchase_info_model__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/shared/models/purchase-info.model */
    "./src/app/shared/models/purchase-info.model.ts");
    /* harmony import */


    var src_app_shared_models_trx_record_model__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! src/app/shared/models/trx-record.model */
    "./src/app/shared/models/trx-record.model.ts");

    var AddPurchaseComponent =
    /*#__PURE__*/
    function () {
      function AddPurchaseComponent(router, http, cs) {
        _classCallCheck(this, AddPurchaseComponent);

        this.router = router;
        this.http = http;
        this.cs = cs;
        this.ProductNames = [];
        this.Brands = [];
        this.Categories = [];
        this.Suppliers = [];
        this.Batches = [];
        this.CommissionType = [];
        this.modelHead = new src_app_shared_models_purchase_model__WEBPACK_IMPORTED_MODULE_2__["Purchase"]();
        this.purchaseInfo = new src_app_shared_models_purchase_info_model__WEBPACK_IMPORTED_MODULE_7__["PurchaseInfo"]();
        this.models = [];
        this.grandTotalInForm = 0;
      }

      _createClass(AddPurchaseComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this24 = this;

          this.PurchaseDateString = this.cs.datePipeISO(new Date());
          this.Batches.push([]);
          this.Categories.push([]);
          this.Brands.push([]);
          this.ProductNames.push([]);
          this.http.get(this.cs.getApiURL() + "Suppliers/GetSupplierInfoes").subscribe(function (data) {
            // console.log(data)
            _this24.Suppliers.push(data); // console.log(this.Suppliers);

          }, function (error) {
            alert("Error occurred.. try reloading the page.");
          });
          this.CommissionType.push("Percentage"); // this.modelHead.PurchaseDate = new Date();

          this.modelHead.PaymentType = "cash";
          var first = new src_app_shared_models_purchase_model__WEBPACK_IMPORTED_MODULE_2__["Purchase"](); // first.Quantity = 25;

          this.models.push(first);
        }
      }, {
        key: "onSubmit",
        value: function onSubmit() {
          var _this25 = this;

          // console.log(this.modelHead)
          // console.log(this.models);
          var ifSuccess = true;
          this.modelHead.PurchaseDate = new Date(this.PurchaseDateString);
          var totalAmount = 0;
          this.models.forEach(function (product, index) {
            var stockModel = new src_app_shared_models_stock_model__WEBPACK_IMPORTED_MODULE_6__["Stock"]();
            stockModel.StockDate = _this25.modelHead.PurchaseDate;
            stockModel.ProductBatch = product.BatchNo;
            stockModel.ProductCode = product.ProductName;
            stockModel.ProductQuantity = product.Quantity; // Things are currently fixed in C#

            stockModel.ProductRate = product.Rate; //This should be MRP

            stockModel.ProductCommission = 0; //product.Commission / product.Quantity; // This is not right!

            stockModel.ProductPurchaseRate = 0; //product.Rate; //- (product.Commission / product.Quantity);

            stockModel.BranchID = 1; //Hardcoded for now

            stockModel.SupplierId = product.Company;
            stockModel.SupplierInvoiceId = _this25.modelHead.InvoiceID;
            totalAmount += product.Total;

            _this25.http.post(_this25.cs.getApiURL() + "Stocks/PostStockInfo", stockModel, {
              headers: {
                "Content-Type": "application/json"
              }
            }).subscribe(function (data) {
              console.log("ok");
            }, function (error) {
              ifSuccess = false;
              alert("Error Occured. Try again please");
            });
          });
          this.purchaseInfo.PurchaseAmount = totalAmount;
          this.purchaseInfo.PurchaseDate = this.modelHead.PurchaseDate;
          this.purchaseInfo.SupplierId = this.models[0].Company;
          this.purchaseInfo.SupplierInvoice = this.modelHead.InvoiceID;
          this.purchaseInfo.PaymentType = this.modelHead.PaymentType;
          this.http.post(this.cs.getApiURL() + "Purchases/PostPurchaseInfo", this.purchaseInfo, {
            headers: {
              "Content-Type": "application/json"
            }
          }).subscribe(function (data) {
            console.log("Ok");
          }, function (error) {
            ifSuccess = false;
            alert("Error. Please retry");
          }); //Setting up for trx_Record table

          var trxModel = new Array();
          var payType = new src_app_shared_models_trx_record_model__WEBPACK_IMPORTED_MODULE_8__["TrxRecord"](); // For PaymentType

          var invn = new src_app_shared_models_trx_record_model__WEBPACK_IMPORTED_MODULE_8__["TrxRecord"](); // For Inventory
          // AccountNo  AccountName         GLCode
          // 4	        Account Payable	    2
          // 3      	  Account Receivable	1
          // 2	        Bank Cheque	        1
          // 1	        Cash	              1
          // 6	        Cost on Goods Sold	4
          // 7	        Inventory	          1
          // 5	        Revenue	            3

          if (!this.modelHead.PaymentType.toLowerCase().localeCompare("cash")) {
            // let trx1 = new TrxRecord();
            payType.AccountNo = 10;
          } else if (!this.modelHead.PaymentType.toLowerCase().localeCompare("cheque")) {
            payType.AccountNo = 43;
          } else {
            payType.AccountNo = 36; // credit
          }

          payType.AccountRef = String(payType.AccountNo);
          invn.AccountNo = 7;
          invn.AccountRef = String(invn.AccountNo);
          payType.BranchID = 1;
          invn.BranchID = 1;
          payType.TrxDate = this.modelHead.PurchaseDate;
          invn.TrxDate = this.modelHead.PurchaseDate;
          payType.TrxNo = 9;
          invn.TrxNo = 9;
          payType.CreditAmount = totalAmount;
          payType.DebitAmount = 0;
          invn.DebitAmount = totalAmount;
          invn.CreditAmount = 0;
          payType.Particulars = "Purchase" + this.modelHead.InvoiceID;
          invn.Particulars = "Purchase" + this.modelHead.InvoiceID;
          trxModel.push(payType);
          trxModel.push(invn);

          for (var i = 0; i < 2; i++) {
            this.http.post(this.cs.getApiURL() + "trx_Records/Posttrx_Records", trxModel[i], {
              headers: {
                "Content-Type": "application/json"
              }
            }).subscribe(function (data) {
              console.log("Ok");
            }, function (error) {
              ifSuccess = false;
              alert("Opps!");
            });
          }

          if (ifSuccess) {
            alert("data record success!");
          }

          this.router.navigate(['/dashboard']);
        }
      }, {
        key: "addRow",
        value: function addRow() {
          var _this26 = this;

          var newRow = new src_app_shared_models_purchase_model__WEBPACK_IMPORTED_MODULE_2__["Purchase"](); // newRow.Quantity = 20;
          // newRow.Rate = 25;

          this.models.push(newRow);
          this.Batches.push([]);
          this.Categories.push([]);
          this.Brands.push([]);
          this.ProductNames.push([]);
          this.http.get(this.cs.getApiURL() + "Suppliers/GetSupplierInfoes").subscribe(function (data) {
            // console.log(data)
            _this26.Suppliers.push(data); // console.log(this.Suppliers);

          }, function (error) {
            alert("Error occurred.. try reloading the page.");
          });
        }
      }, {
        key: "removeRow",
        value: function removeRow(rowIndex) {
          if (this.models.length == 1) {
            // Can't Delete Bro. You got only one ROW.
            return false;
          } else {
            this.models.splice(rowIndex, 1);
            return true;
          }

          this.updateGrandTotal();
        }
      }, {
        key: "onSupplierChange",
        value: function onSupplierChange(event) {
          var _this27 = this;

          var i = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
          this.http.get(this.cs.getApiURL() + "Products/GetCategories?supplier=" + event).subscribe(function (data) {
            _this27.Categories[i] = data; // console.log(this.Brands);
          }, function (error) {
            console.log(error);
          });
          this.Brands[i] = [];
          this.ProductNames[i] = [];
        }
      }, {
        key: "onCategoryChange",
        value: function onCategoryChange(event, i) {
          var _this28 = this;

          // console.log(event);
          this.http.get(this.cs.getApiURL() + "Products/GetBrands?category=" + event + "&supplier=" + this.models[i].Company).subscribe(function (data) {
            _this28.Brands[i] = data;
            console.log(_this28.Brands);
          }, function (error) {
            console.log(error);
          });
          this.ProductNames[i] = [];
        }
      }, {
        key: "onBrandChange",
        value: function onBrandChange(event, i) {
          var _this29 = this;

          this.http.get(this.cs.getApiURL() + "Products/GetProducts?category=" + this.models[i].Category + "&brand=" + event + "&supplier=" + this.models[i].Company).subscribe(function (data) {
            console.log(data);
            _this29.ProductNames[i] = data;
          }, function (error) {
            console.log(error);
          });
        }
      }, {
        key: "OnProductSelect",
        value: function OnProductSelect(event, i) {
          var _this30 = this;

          // this.http.get(this.cs.getApiURL() + "Products/GetProductPrice/" + event).subscribe(
          //   data => {
          //     this.models[i].Rate = data as number;
          //     this.updateTotal(i);
          //   },
          //   error => {
          //     alert("Error, try reloading...");
          //   }
          // );
          var tempDate = new Date(this.PurchaseDateString);
          var temp = "Batches/CheckBatch?productCode=" + this.models[i].ProductName + "&date=" + String(tempDate.getFullYear()) + "-" + String(tempDate.getMonth() + 1) + "-" + String(tempDate.getDate()); // console.log(temp)

          this.http.get(this.cs.getApiURL() + temp).subscribe(function (data) {
            _this30.Batches[i] = data;
            console.log(data);
          }, function (error) {
            alert("Alerty on Batches!");
          });
        }
      }, {
        key: "onBatchChange",
        value: function onBatchChange(event, rowIndex) {
          var _this31 = this;

          var tempDate = new Date(this.PurchaseDateString);
          this.http.get(this.cs.getApiURL() + "Batches/GetCommissionAmount?productCode=" + this.models[rowIndex].ProductName + "&batchCode=" + this.models[rowIndex].BatchNo + "&date= +" + String(tempDate.getFullYear()) + "-" + String(tempDate.getMonth() + 1) + "-" + String(tempDate.getDate())).subscribe(function (data) {
            _this31.models[rowIndex].Rate = data;
            console.log(data);
          }, function (error) {
            alert("Error! try again.");
          });
        }
      }, {
        key: "updateTotal",
        value: function updateTotal(rowIndex) {
          this.models[rowIndex].Total = this.models[rowIndex].Quantity * this.models[rowIndex].Rate;
          this.updateGrandTotal();
        }
      }, {
        key: "updateGrandTotal",
        value: function updateGrandTotal() {
          var _this32 = this;

          this.grandTotalInForm = 0;
          this.models.forEach(function (model) {
            _this32.grandTotalInForm += model.Total;
          });
        }
      }, {
        key: "addLOT",
        value: function addLOT(form) {
          sessionStorage.setItem('addPurchaseForm', JSON.stringify(form.value));
          this.router.navigate(['/purchases/add-batch'], {
            queryParams: {
              'redirectUrl': this.router.url
            }
          });
        }
      }]);

      return AddPurchaseComponent;
    }();

    AddPurchaseComponent.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"]
      }];
    };

    AddPurchaseComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-add-purchase',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./add-purchase.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/purchases/add-purchase/add-purchase.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./add-purchase.component.css */
      "./src/app/purchases/add-purchase/add-purchase.component.css")).default]
    })], AddPurchaseComponent);
    /***/
  },

  /***/
  "./src/app/sales/add-sale/add-sale.component.css":
  /*!*******************************************************!*\
    !*** ./src/app/sales/add-sale/add-sale.component.css ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSalesAddSaleAddSaleComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "/* .no-gutters {\r\n    margin-right: 0;\r\n    margin-left: 0;\r\n    .col, [class*=\"col-\"] {\r\n        padding-right: 0;\r\n        padding-left: 0;\r\n    }\r\n} */\r\n\r\n.col-1 {\r\n    padding-left: 10px;\r\n}\r\n\r\n#percent-sign {\r\n    top: 5px;\r\n    right: 5px;\r\n    color: #555;\r\n    position: absolute;\r\n    z-index: 1;\r\n}\r\n\r\n.no-spinner::-webkit-inner-spin-button, .no-spinner::-webkit-outer-spin-button {\r\n    -webkit-appearance: none;\r\n    margin: 0;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2FsZXMvYWRkLXNhbGUvYWRkLXNhbGUuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7OztHQU9HOztBQUVIO0lBQ0ksa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0ksUUFBUTtJQUNSLFVBQVU7SUFDVixXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLFVBQVU7QUFDZDs7QUFFQTtJQUNJLHdCQUF3QjtJQUN4QixTQUFTO0FBQ2IiLCJmaWxlIjoic3JjL2FwcC9zYWxlcy9hZGQtc2FsZS9hZGQtc2FsZS5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLyogLm5vLWd1dHRlcnMge1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAwO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDA7XHJcbiAgICAuY29sLCBbY2xhc3MqPVwiY29sLVwiXSB7XHJcbiAgICAgICAgcGFkZGluZy1yaWdodDogMDtcclxuICAgICAgICBwYWRkaW5nLWxlZnQ6IDA7XHJcbiAgICB9XHJcbn0gKi9cclxuXHJcbi5jb2wtMSB7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XHJcbn1cclxuXHJcbiNwZXJjZW50LXNpZ24ge1xyXG4gICAgdG9wOiA1cHg7XHJcbiAgICByaWdodDogNXB4O1xyXG4gICAgY29sb3I6ICM1NTU7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB6LWluZGV4OiAxO1xyXG59XHJcblxyXG4ubm8tc3Bpbm5lcjo6LXdlYmtpdC1pbm5lci1zcGluLWJ1dHRvbiwgLm5vLXNwaW5uZXI6Oi13ZWJraXQtb3V0ZXItc3Bpbi1idXR0b24ge1xyXG4gICAgLXdlYmtpdC1hcHBlYXJhbmNlOiBub25lO1xyXG4gICAgbWFyZ2luOiAwO1xyXG59Il19 */";
    /***/
  },

  /***/
  "./src/app/sales/add-sale/add-sale.component.ts":
  /*!******************************************************!*\
    !*** ./src/app/sales/add-sale/add-sale.component.ts ***!
    \******************************************************/

  /*! exports provided: AddSaleComponent */

  /***/
  function srcAppSalesAddSaleAddSaleComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AddSaleComponent", function () {
      return AddSaleComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_shared_models_sale_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/shared/models/sale.model */
    "./src/app/shared/models/sale.model.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");
    /* harmony import */


    var src_app_shared_models_sale_info_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/shared/models/sale-info.model */
    "./src/app/shared/models/sale-info.model.ts");
    /* harmony import */


    var src_app_shared_models_trx_record_model__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/shared/models/trx-record.model */
    "./src/app/shared/models/trx-record.model.ts");

    var AddSaleComponent =
    /*#__PURE__*/
    function () {
      function AddSaleComponent(router, http, cs) {
        _classCallCheck(this, AddSaleComponent);

        this.router = router;
        this.http = http;
        this.cs = cs; // Bulk Data

        this.Products = [];
        this.Brands = [];
        this.Categories = [];
        this.Suppliers = [];
        this.Batches = [];
        this.modelHead = new src_app_shared_models_sale_model__WEBPACK_IMPORTED_MODULE_2__["Sale"]();
        this.models = [];
        this.grandTotalInForm = 0;
      }

      _createClass(AddSaleComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this33 = this;

          this.SaleDateString = this.cs.datePipeISO(new Date()); // console.log(this.SaleDateString);

          this.modelHead.PaymentType = "cash";
          this.Batches.push([]);
          this.Categories.push([]);
          this.Brands.push([]);
          this.Products.push([]);
          this.http.get(this.cs.getApiURL() + "Suppliers/GetSupplierInfoes").subscribe(function (data) {
            // console.log(data)
            _this33.Suppliers.push(data);
          }, function (error) {
            alert("Error occurred.. try reloading the page.");
          });
          this.http.get(this.cs.getApiURL() + "Customers/GetCustomerInfoes").subscribe(function (data) {
            _this33.CustomerList = data;
          }, function (error) {
            alert("Error! Try reloading this page");
          });
          var first = new src_app_shared_models_sale_model__WEBPACK_IMPORTED_MODULE_2__["Sale"]();
          first.AvailableQuantity = 0;
          first.ProductUnit = "PCs";
          this.models.push(first);
        }
      }, {
        key: "onSubmit",
        value: function onSubmit() {
          var _this34 = this;

          this.modelHead.SaleDate = new Date(this.SaleDateString); // console.log(this.modelHead.SaleDate);
          // console.log(this.modelHead);
          // console.log(this.models);

          var trxModel = new Array();
          var myInvoice = this.cs.generateInvoice(this.modelHead);
          console.log(myInvoice);
          var grandTotal = 0;
          var grandSaleTotal = 0;
          var ifSuccess = true;
          this.models.forEach(function (sale) {
            // console.log(sale);
            var saleinfo = new src_app_shared_models_sale_info_model__WEBPACK_IMPORTED_MODULE_6__["SaleInfo"]();
            saleinfo.CustomerID = _this34.modelHead.CustomerName;
            saleinfo.PaymentType = _this34.modelHead.PaymentType;
            saleinfo.SaleDate = _this34.modelHead.SaleDate;
            saleinfo.SaleDetails = _this34.modelHead.SaleDetails;
            saleinfo.BatchNo = sale.BatchNo;
            saleinfo.ProductCode = sale.Product;
            saleinfo.ProductMRP = sale.SaleRate;
            saleinfo.Quantity = sale.SaleQuantity;
            saleinfo.DiscountAmount = sale.SaleRate * sale.DiscountInPercent / 100;
            saleinfo.OfferAmount = sale.SaleRate * sale.Offers / 100;
            saleinfo.Total = sale.Total;
            grandTotal += sale.Total;
            grandSaleTotal += sale.PurchaseTotal;
            saleinfo.InvoiceID = myInvoice;
            console.log(saleinfo.InvoiceID);

            _this34.http.post(_this34.cs.getApiURL() + "Sales/PostSaleInfo", saleinfo, {
              headers: {
                "Content-Type": "application/json"
              }
            }).subscribe(function (data) {
              console.log("Ok");
            }, function (error) {
              ifSuccess = false;
              alert("Error! Try again please");
            }); // window.open(this.cs.getApiURL() + "Sales/CustomerInvoice?invoiceId=" + myInvoice);

          }); //Setting up for trx_Record table

          var payType = new src_app_shared_models_trx_record_model__WEBPACK_IMPORTED_MODULE_7__["TrxRecord"](); // For PaymentType

          var revn = new src_app_shared_models_trx_record_model__WEBPACK_IMPORTED_MODULE_7__["TrxRecord"](); // For Revenue

          var cogs = new src_app_shared_models_trx_record_model__WEBPACK_IMPORTED_MODULE_7__["TrxRecord"](); // For COGS

          var invn = new src_app_shared_models_trx_record_model__WEBPACK_IMPORTED_MODULE_7__["TrxRecord"](); // For Inventory
          // AccountNo  AccountName         AccountType
          // 36	        Account Payable	    2
          // 6      	  Account Receivable	1
          // 43	        Cash in Bank        1
          // 10	        Cash in hand        1
          // 44	        Cost on Goods Sold	4
          // 7	        Inventory	          1
          // 41	        Sales Revenue	      3

          if (!this.modelHead.PaymentType.toLowerCase().localeCompare("cash")) {
            payType.AccountNo = 10;
          } else if (!this.modelHead.PaymentType.toLowerCase().localeCompare("cheque")) {
            payType.AccountNo = 43;
          } else {
            payType.AccountNo = 6;
          }

          revn.AccountNo = 41;
          cogs.AccountNo = 44;
          invn.AccountNo = 7;
          payType.AccountRef = String(payType.AccountNo);
          revn.AccountRef = String(revn.AccountNo);
          cogs.AccountRef = String(cogs.AccountNo);
          invn.AccountRef = String(invn.AccountNo);
          payType.TrxDate = this.modelHead.SaleDate;
          revn.TrxDate = this.modelHead.SaleDate;
          cogs.TrxDate = this.modelHead.SaleDate;
          invn.TrxDate = this.modelHead.SaleDate;
          payType.TrxNo = 5;
          revn.TrxNo = 5;
          cogs.TrxNo = 5;
          invn.TrxNo = 5; //Hardcoding the Branch

          payType.BranchID = 1;
          revn.BranchID = 1;
          cogs.BranchID = 1;
          invn.BranchID = 1;
          payType.CreditAmount = 0;
          revn.CreditAmount = grandTotal;
          cogs.CreditAmount = 0;
          invn.CreditAmount = grandSaleTotal;
          payType.DebitAmount = grandTotal;
          revn.DebitAmount = 0;
          cogs.DebitAmount = grandSaleTotal;
          invn.DebitAmount = 0;
          payType.Particulars = "Sale" + myInvoice;
          revn.Particulars = "Sale" + myInvoice;
          cogs.Particulars = "Sale" + myInvoice;
          invn.Particulars = "Sale" + myInvoice;
          trxModel.push(payType);
          trxModel.push(revn);
          trxModel.push(cogs);
          trxModel.push(invn); // Posting in trx-Records table.

          for (var i = 0; i < 4; i++) {
            this.http.post(this.cs.getApiURL() + "trx_Records/Posttrx_Records", trxModel[i], {
              headers: {
                "Content-Type": "application/json"
              }
            }).subscribe(function (data) {
              console.log("Ok");
            }, function (error) {
              ifSuccess = false;
              alert("Opps!");
            });
          }

          if (ifSuccess) {
            alert("Data recorded successfully.");
          }

          this.router.navigate(['/dashboard']);
        }
      }, {
        key: "updateTotal",
        value: function updateTotal(rowIndex) {
          this.models[rowIndex].Total = this.models[rowIndex].SaleQuantity * this.models[rowIndex].SaleRate - this.models[rowIndex].SaleQuantity * this.models[rowIndex].SaleRate * this.models[rowIndex].DiscountInPercent / 100;
          this.models[rowIndex].Total -= this.models[rowIndex].Offers * this.models[rowIndex].SaleQuantity;
          this.models[rowIndex].PurchaseTotal = this.models[rowIndex].SaleQuantity * this.models[rowIndex].PurchaseRate;
          this.updateGrandTotal();
        }
      }, {
        key: "addRow",
        value: function addRow() {
          var _this35 = this;

          // console.log(rowIndex);
          var newRow = new src_app_shared_models_sale_model__WEBPACK_IMPORTED_MODULE_2__["Sale"]();
          this.Batches.push([]);
          this.Categories.push([]);
          this.Brands.push([]);
          this.Products.push([]);
          this.http.get(this.cs.getApiURL() + "Suppliers/GetSupplierInfoes").subscribe(function (data) {
            // console.log(data)
            _this35.Suppliers.push(data);
          }, function (error) {
            alert("Error occurred.. try reloading the page.");
          });
          this.models.push(newRow); // console.log(this.models);

          return true;
        }
      }, {
        key: "removeRow",
        value: function removeRow(rowIndex) {
          console.log(rowIndex);

          if (this.models.length == 1) {
            return false;
          } else {
            this.models.splice(rowIndex, 1);
            return true;
          }

          this.updateGrandTotal();
        }
      }, {
        key: "onSupplierChange",
        value: function onSupplierChange(event, i) {
          var _this36 = this;

          this.http.get(this.cs.getApiURL() + "Products/GetCategories?supplier=" + event).subscribe(function (data) {
            _this36.Categories[i] = data; // console.log(this.Brands);
          }, function (error) {
            console.log(error);
          });
        }
      }, {
        key: "onCategoryChange",
        value: function onCategoryChange(event, i) {
          var _this37 = this;

          // console.log(event);
          this.http.get(this.cs.getApiURL() + "Products/GetBrands?category=" + event + "&supplier=" + this.models[i].Company).subscribe(function (data) {
            _this37.Brands[i] = data; // console.log(this.Brands);
          }, function (error) {
            console.log(error);
          });
        }
      }, {
        key: "onBrandChange",
        value: function onBrandChange(event, i) {
          var _this38 = this;

          this.http.get(this.cs.getApiURL() + "Products/GetProducts?category=" + this.models[i].Category + "&brand=" + event + "&supplier=" + this.models[i].Company).subscribe(function (data) {
            // console.log(data);
            _this38.Products[i] = data;
          }, function (error) {
            console.log(error);
          });
        }
      }, {
        key: "onProductSelect",
        value: function onProductSelect(event, i) {
          var _this39 = this;

          this.http.get(this.cs.getApiURL() + "Stocks/GetQuantityByProduct?productCode=" + event).subscribe(function (data) {
            _this39.Batches[i] = data;
          }, function (error) {
            alert("Error, try reloading...");
          });
          var tempDate = new Date(this.SaleDateString);
          var temp = "Offers/CheckOffer?productCode=" + this.models[i].Product + "&date=" + String(tempDate.getFullYear()) + "-" + String(tempDate.getMonth() + 1) + "-" + String(tempDate.getDate()); // console.log(temp)

          this.http.get(this.cs.getApiURL() + temp).subscribe(function (data) {
            _this39.models[i].Offers = data;
          }, function (error) {
            alert("Alerty on Offer!");
          }); // console.log("OnProductSelect");
        }
      }, {
        key: "onBatchChange",
        value: function onBatchChange(event, i) {
          var temp = this.Batches[i].find(function (x) {
            return x.Batch === Number(event);
          });
          this.models[i].AvailableQuantity = temp.Quantity;
          this.models[i].SaleRate = temp.MRP;
          this.models[i].PurchaseRate = temp.PurchaseRate;
        }
      }, {
        key: "updateGrandTotal",
        value: function updateGrandTotal() {
          var _this40 = this;

          this.grandTotalInForm = 0;
          this.models.forEach(function (model) {
            _this40.grandTotalInForm += model.Total;
          }); // this.grandTotalInForm -= this.grandTotalInForm * this.modelHead.DiscountInPercent / 100;
        }
      }, {
        key: "addCustomer",
        value: function addCustomer() {
          this.router.navigate(['/customers/add'], {
            queryParams: {
              'redirectUrl': this.router.url
            }
          });
        }
      }]);

      return AddSaleComponent;
    }();

    AddSaleComponent.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"]
      }];
    };

    AddSaleComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-add-sale',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./add-sale.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/sales/add-sale/add-sale.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./add-sale.component.css */
      "./src/app/sales/add-sale/add-sale.component.css")).default]
    })], AddSaleComponent);
    /***/
  },

  /***/
  "./src/app/setup/add-previous-cash/add-previous-cash.component.css":
  /*!*************************************************************************!*\
    !*** ./src/app/setup/add-previous-cash/add-previous-cash.component.css ***!
    \*************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSetupAddPreviousCashAddPreviousCashComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NldHVwL2FkZC1wcmV2aW91cy1jYXNoL2FkZC1wcmV2aW91cy1jYXNoLmNvbXBvbmVudC5jc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/setup/add-previous-cash/add-previous-cash.component.ts":
  /*!************************************************************************!*\
    !*** ./src/app/setup/add-previous-cash/add-previous-cash.component.ts ***!
    \************************************************************************/

  /*! exports provided: AddPreviousCashComponent */

  /***/
  function srcAppSetupAddPreviousCashAddPreviousCashComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AddPreviousCashComponent", function () {
      return AddPreviousCashComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_shared_models_trx_record_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/shared/models/trx-record.model */
    "./src/app/shared/models/trx-record.model.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");

    var AddPreviousCashComponent =
    /*#__PURE__*/
    function () {
      function AddPreviousCashComponent(http, cs, router) {
        _classCallCheck(this, AddPreviousCashComponent);

        this.http = http;
        this.cs = cs;
        this.router = router;
      }

      _createClass(AddPreviousCashComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "onSubmit",
        value: function onSubmit() {
          var ifSuccess = true;
          var trxModel = new Array();
          var cash = new src_app_shared_models_trx_record_model__WEBPACK_IMPORTED_MODULE_2__["TrxRecord"](); // For PaymentType

          var equity = new src_app_shared_models_trx_record_model__WEBPACK_IMPORTED_MODULE_2__["TrxRecord"](); // For Inventory

          var today = new Date("2020-03-01");
          cash.AccountNo = 10;
          cash.AccountRef = String(cash.AccountNo);
          equity.AccountNo = 32;
          equity.AccountRef = String(equity.AccountNo);
          cash.BranchID = 1;
          equity.BranchID = 1;
          cash.TrxDate = today;
          equity.TrxDate = today;
          cash.TrxNo = 9;
          equity.TrxNo = 9;
          cash.CreditAmount = 0; // this.amount;

          cash.DebitAmount = this.amount;
          equity.DebitAmount = 0; // this.amount;

          equity.CreditAmount = this.amount;
          cash.Particulars = "Adjustments";
          equity.Particulars = "Adjustments";
          trxModel.push(cash);
          trxModel.push(equity);

          for (var i = 0; i < 2; i++) {
            this.http.post(this.cs.getApiURL() + "trx_Records/Posttrx_Records", trxModel[i], {
              headers: {
                "Content-Type": "application/json"
              }
            }).subscribe(function (data) {
              console.log("Ok");
            }, function (error) {
              ifSuccess = false;
              alert("Opps!");
            });
          }

          if (ifSuccess) {
            alert("data record success!");
          }

          this.router.navigate(['/dashboard']);
        }
      }]);

      return AddPreviousCashComponent;
    }();

    AddPreviousCashComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_4__["CommonService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]
      }];
    };

    AddPreviousCashComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-add-previous-cash',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./add-previous-cash.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/setup/add-previous-cash/add-previous-cash.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./add-previous-cash.component.css */
      "./src/app/setup/add-previous-cash/add-previous-cash.component.css")).default]
    })], AddPreviousCashComponent);
    /***/
  },

  /***/
  "./src/app/setup/add-previous-stock/add-previous-stock.component.css":
  /*!***************************************************************************!*\
    !*** ./src/app/setup/add-previous-stock/add-previous-stock.component.css ***!
    \***************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSetupAddPreviousStockAddPreviousStockComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NldHVwL2FkZC1wcmV2aW91cy1zdG9jay9hZGQtcHJldmlvdXMtc3RvY2suY29tcG9uZW50LmNzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/setup/add-previous-stock/add-previous-stock.component.ts":
  /*!**************************************************************************!*\
    !*** ./src/app/setup/add-previous-stock/add-previous-stock.component.ts ***!
    \**************************************************************************/

  /*! exports provided: AddPreviousStockComponent */

  /***/
  function srcAppSetupAddPreviousStockAddPreviousStockComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AddPreviousStockComponent", function () {
      return AddPreviousStockComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");
    /* harmony import */


    var src_app_shared_models_purchase_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/shared/models/purchase.model */
    "./src/app/shared/models/purchase.model.ts");
    /* harmony import */


    var src_app_shared_models_purchase_info_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/shared/models/purchase-info.model */
    "./src/app/shared/models/purchase-info.model.ts");
    /* harmony import */


    var src_app_shared_models_trx_record_model__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/shared/models/trx-record.model */
    "./src/app/shared/models/trx-record.model.ts");
    /* harmony import */


    var src_app_shared_models_stock_model__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! src/app/shared/models/stock.model */
    "./src/app/shared/models/stock.model.ts");

    var AddPreviousStockComponent =
    /*#__PURE__*/
    function () {
      function AddPreviousStockComponent(router, http, cs) {
        _classCallCheck(this, AddPreviousStockComponent);

        this.router = router;
        this.http = http;
        this.cs = cs;
        this.ProductNames = [];
        this.Brands = [];
        this.Categories = [];
        this.Suppliers = [];
        this.Batches = [];
        this.CommissionType = [];
        this.modelHead = new src_app_shared_models_purchase_model__WEBPACK_IMPORTED_MODULE_5__["Purchase"]();
        this.purchaseInfo = new src_app_shared_models_purchase_info_model__WEBPACK_IMPORTED_MODULE_6__["PurchaseInfo"]();
        this.models = [];
        this.grandTotalInForm = 0;
      }

      _createClass(AddPreviousStockComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this41 = this;

          this.PurchaseDateString = this.cs.datePipeISO(new Date());
          this.Batches.push([]);
          this.Categories.push([]);
          this.Brands.push([]);
          this.ProductNames.push([]);
          this.http.get(this.cs.getApiURL() + "Suppliers/GetSupplierInfoes").subscribe(function (data) {
            // console.log(data)
            _this41.Suppliers.push(data); // console.log(this.Suppliers);

          }, function (error) {
            alert("Error occurred.. try reloading the page.");
          });
          this.CommissionType.push("Percentage"); // this.modelHead.PurchaseDate = new Date();

          this.modelHead.PaymentType = "cash";
          var first = new src_app_shared_models_purchase_model__WEBPACK_IMPORTED_MODULE_5__["Purchase"](); // first.Quantity = 25;

          this.models.push(first);
        }
      }, {
        key: "onSubmit",
        value: function onSubmit() {
          var _this42 = this;

          // console.log(this.modelHead)
          // console.log(this.models);
          var ifSuccess = true;
          this.modelHead.PurchaseDate = new Date("2020-03-01");
          this.modelHead.PaymentType = "cash";
          this.modelHead.Details = "Adjustments";
          this.modelHead.InvoiceID = "1234567890";
          var totalAmount = 0;
          this.models.forEach(function (product, index) {
            var stockModel = new src_app_shared_models_stock_model__WEBPACK_IMPORTED_MODULE_8__["Stock"]();
            stockModel.StockDate = _this42.modelHead.PurchaseDate;
            stockModel.ProductBatch = product.BatchNo;
            stockModel.ProductCode = product.ProductName;
            stockModel.ProductQuantity = product.Quantity; // Things are currently fixed in C#

            stockModel.ProductRate = product.Rate; //This should be MRP

            stockModel.ProductCommission = 0; //product.Commission / product.Quantity; // This is not right!

            stockModel.ProductPurchaseRate = 0; //product.Rate; //- (product.Commission / product.Quantity);

            stockModel.BranchID = 1; //Hardcoded for now

            stockModel.SupplierId = product.Company;
            stockModel.SupplierInvoiceId = _this42.modelHead.InvoiceID;
            totalAmount += product.Total;

            _this42.http.post(_this42.cs.getApiURL() + "Stocks/PostStockInfo", stockModel, {
              headers: {
                "Content-Type": "application/json"
              }
            }).subscribe(function (data) {
              console.log("ok");
            }, function (error) {
              ifSuccess = false;
              alert("Error Occured. Try again please");
            });
          });
          this.purchaseInfo.PurchaseAmount = totalAmount;
          this.purchaseInfo.PurchaseDate = this.modelHead.PurchaseDate;
          this.purchaseInfo.SupplierId = 0;
          this.purchaseInfo.SupplierInvoice = this.modelHead.InvoiceID;
          this.purchaseInfo.PaymentType = this.modelHead.PaymentType;
          this.http.post(this.cs.getApiURL() + "Purchases/PostPurchaseInfo", this.purchaseInfo, {
            headers: {
              "Content-Type": "application/json"
            }
          }).subscribe(function (data) {
            console.log("Ok");
          }, function (error) {
            ifSuccess = false;
            alert("Error. Please retry");
          }); //Setting up for trx_Record table

          var trxModel = new Array();
          var equity = new src_app_shared_models_trx_record_model__WEBPACK_IMPORTED_MODULE_7__["TrxRecord"](); // For PaymentType

          var invn = new src_app_shared_models_trx_record_model__WEBPACK_IMPORTED_MODULE_7__["TrxRecord"](); // For Inventory
          // AccountNo  AccountName         GLCode
          // 4	        Account Payable	    2
          // 3      	  Account Receivable	1
          // 2	        Bank Cheque	        1
          // 1	        Cash	              1
          // 6	        Cost on Goods Sold	4
          // 7	        Inventory	          1
          // 5	        Revenue	            3

          equity.AccountNo = 32;
          equity.AccountRef = String(equity.AccountNo);
          invn.AccountNo = 7;
          invn.AccountRef = String(invn.AccountNo);
          equity.BranchID = 1;
          invn.BranchID = 1;
          equity.TrxDate = this.modelHead.PurchaseDate;
          invn.TrxDate = this.modelHead.PurchaseDate;
          equity.TrxNo = 9;
          invn.TrxNo = 9;
          equity.CreditAmount = totalAmount;
          equity.DebitAmount = 0;
          invn.DebitAmount = totalAmount;
          invn.CreditAmount = 0;
          equity.Particulars = "Purchase" + this.modelHead.InvoiceID;
          invn.Particulars = "Purchase" + this.modelHead.InvoiceID;
          trxModel.push(equity);
          trxModel.push(invn);

          for (var i = 0; i < 2; i++) {
            this.http.post(this.cs.getApiURL() + "trx_Records/Posttrx_Records", trxModel[i], {
              headers: {
                "Content-Type": "application/json"
              }
            }).subscribe(function (data) {
              console.log("Ok");
            }, function (error) {
              ifSuccess = false;
              alert("Opps!");
            });
          }

          if (ifSuccess) {
            alert("data record success!");
          }

          this.router.navigate(['/dashboard']);
        }
      }, {
        key: "addRow",
        value: function addRow() {
          var _this43 = this;

          var newRow = new src_app_shared_models_purchase_model__WEBPACK_IMPORTED_MODULE_5__["Purchase"](); // newRow.Quantity = 20;
          // newRow.Rate = 25;

          this.models.push(newRow);
          this.Batches.push([]);
          this.Categories.push([]);
          this.Brands.push([]);
          this.ProductNames.push([]);
          this.http.get(this.cs.getApiURL() + "Suppliers/GetSupplierInfoes").subscribe(function (data) {
            // console.log(data)
            _this43.Suppliers.push(data); // console.log(this.Suppliers);

          }, function (error) {
            alert("Error occurred.. try reloading the page.");
          });
        }
      }, {
        key: "removeRow",
        value: function removeRow(rowIndex) {
          if (this.models.length == 1) {
            // Can't Delete Bro. You got only one ROW.
            return false;
          } else {
            this.models.splice(rowIndex, 1);
            return true;
          }

          this.updateGrandTotal();
        }
      }, {
        key: "onSupplierChange",
        value: function onSupplierChange(event) {
          var _this44 = this;

          var i = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
          this.http.get(this.cs.getApiURL() + "Products/GetCategories?supplier=" + event).subscribe(function (data) {
            _this44.Categories[i] = data; // console.log(this.Brands);
          }, function (error) {
            console.log(error);
          });
          this.Brands[i] = [];
          this.ProductNames[i] = [];
        }
      }, {
        key: "onCategoryChange",
        value: function onCategoryChange(event, i) {
          var _this45 = this;

          // console.log(event);
          this.http.get(this.cs.getApiURL() + "Products/GetBrands?category=" + event + "&supplier=" + this.models[i].Company).subscribe(function (data) {
            _this45.Brands[i] = data;
            console.log(_this45.Brands);
          }, function (error) {
            console.log(error);
          });
          this.ProductNames[i] = [];
        }
      }, {
        key: "onBrandChange",
        value: function onBrandChange(event, i) {
          var _this46 = this;

          this.http.get(this.cs.getApiURL() + "Products/GetProducts?category=" + this.models[i].Category + "&brand=" + event + "&supplier=" + this.models[i].Company).subscribe(function (data) {
            console.log(data);
            _this46.ProductNames[i] = data;
          }, function (error) {
            console.log(error);
          });
        }
      }, {
        key: "OnProductSelect",
        value: function OnProductSelect(event, i) {
          var _this47 = this;

          var tempDate = new Date(this.PurchaseDateString);
          var temp = "Batches/CheckBatch?productCode=" + this.models[i].ProductName + "&date=" + String(tempDate.getFullYear()) + "-" + String(tempDate.getMonth() + 1) + "-" + String(tempDate.getDate()); // console.log(temp)

          this.http.get(this.cs.getApiURL() + temp).subscribe(function (data) {
            _this47.Batches[i] = data;
            console.log(data);
          }, function (error) {
            alert("Alerty on Batches!");
          });
        }
      }, {
        key: "onBatchChange",
        value: function onBatchChange(event, rowIndex) {
          var _this48 = this;

          var tempDate = new Date(this.PurchaseDateString);
          this.http.get(this.cs.getApiURL() + "Batches/GetCommissionAmount?productCode=" + this.models[rowIndex].ProductName + "&batchCode=" + this.models[rowIndex].BatchNo + "&date= +" + String(tempDate.getFullYear()) + "-" + String(tempDate.getMonth() + 1) + "-" + String(tempDate.getDate())).subscribe(function (data) {
            _this48.models[rowIndex].Rate = data;
            console.log(data);
          }, function (error) {
            alert("Error! try again.");
          });
        }
      }, {
        key: "updateTotal",
        value: function updateTotal(rowIndex) {
          this.models[rowIndex].Total = this.models[rowIndex].Quantity * this.models[rowIndex].Rate;
          this.updateGrandTotal();
        }
      }, {
        key: "updateGrandTotal",
        value: function updateGrandTotal() {
          var _this49 = this;

          this.grandTotalInForm = 0;
          this.models.forEach(function (model) {
            _this49.grandTotalInForm += model.Total;
          });
        }
      }, {
        key: "addLOT",
        value: function addLOT(form) {
          sessionStorage.setItem('addPurchaseForm', JSON.stringify(form.value));
          this.router.navigate(['/purchases/add-batch'], {
            queryParams: {
              'redirectUrl': this.router.url
            }
          });
        }
      }]);

      return AddPreviousStockComponent;
    }();

    AddPreviousStockComponent.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_4__["CommonService"]
      }];
    };

    AddPreviousStockComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-add-previous-stock',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./add-previous-stock.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/setup/add-previous-stock/add-previous-stock.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./add-previous-stock.component.css */
      "./src/app/setup/add-previous-stock/add-previous-stock.component.css")).default]
    })], AddPreviousStockComponent);
    /***/
  },

  /***/
  "./src/app/shared/models/account-expense-info.model.ts":
  /*!*************************************************************!*\
    !*** ./src/app/shared/models/account-expense-info.model.ts ***!
    \*************************************************************/

  /*! exports provided: AccountExpenseInfo */

  /***/
  function srcAppSharedModelsAccountExpenseInfoModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AccountExpenseInfo", function () {
      return AccountExpenseInfo;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var AccountExpenseInfo = function AccountExpenseInfo() {
      _classCallCheck(this, AccountExpenseInfo);

      this.GLCode = 4;
    };
    /***/

  },

  /***/
  "./src/app/shared/models/bank.model.ts":
  /*!*********************************************!*\
    !*** ./src/app/shared/models/bank.model.ts ***!
    \*********************************************/

  /*! exports provided: Bank */

  /***/
  function srcAppSharedModelsBankModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Bank", function () {
      return Bank;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var Bank = function Bank() {
      _classCallCheck(this, Bank);
    };
    /***/

  },

  /***/
  "./src/app/shared/models/batch.model.ts":
  /*!**********************************************!*\
    !*** ./src/app/shared/models/batch.model.ts ***!
    \**********************************************/

  /*! exports provided: Batch */

  /***/
  function srcAppSharedModelsBatchModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Batch", function () {
      return Batch;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var Batch = function Batch() {
      _classCallCheck(this, Batch);
    };
    /***/

  },

  /***/
  "./src/app/shared/models/brand.model.ts":
  /*!**********************************************!*\
    !*** ./src/app/shared/models/brand.model.ts ***!
    \**********************************************/

  /*! exports provided: Brand */

  /***/
  function srcAppSharedModelsBrandModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Brand", function () {
      return Brand;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var Brand = function Brand() {
      _classCallCheck(this, Brand);
    };
    /***/

  },

  /***/
  "./src/app/shared/models/category.model.ts":
  /*!*************************************************!*\
    !*** ./src/app/shared/models/category.model.ts ***!
    \*************************************************/

  /*! exports provided: Category */

  /***/
  function srcAppSharedModelsCategoryModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Category", function () {
      return Category;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var Category = function Category() {
      _classCallCheck(this, Category);
    };
    /***/

  },

  /***/
  "./src/app/shared/models/customer.model.ts":
  /*!*************************************************!*\
    !*** ./src/app/shared/models/customer.model.ts ***!
    \*************************************************/

  /*! exports provided: Customer */

  /***/
  function srcAppSharedModelsCustomerModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Customer", function () {
      return Customer;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var Customer = function Customer() {
      _classCallCheck(this, Customer);
    };
    /***/

  },

  /***/
  "./src/app/shared/models/expense.model.ts":
  /*!************************************************!*\
    !*** ./src/app/shared/models/expense.model.ts ***!
    \************************************************/

  /*! exports provided: Expense */

  /***/
  function srcAppSharedModelsExpenseModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Expense", function () {
      return Expense;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var Expense = function Expense() {
      _classCallCheck(this, Expense);
    };
    /***/

  },

  /***/
  "./src/app/shared/models/offers.model.ts":
  /*!***********************************************!*\
    !*** ./src/app/shared/models/offers.model.ts ***!
    \***********************************************/

  /*! exports provided: Offers */

  /***/
  function srcAppSharedModelsOffersModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Offers", function () {
      return Offers;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var Offers = function Offers() {
      _classCallCheck(this, Offers);
    };
    /***/

  },

  /***/
  "./src/app/shared/models/product.model.ts":
  /*!************************************************!*\
    !*** ./src/app/shared/models/product.model.ts ***!
    \************************************************/

  /*! exports provided: Product */

  /***/
  function srcAppSharedModelsProductModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Product", function () {
      return Product;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var Product = function Product() {
      _classCallCheck(this, Product);
    };
    /***/

  },

  /***/
  "./src/app/shared/models/purchase-info.model.ts":
  /*!******************************************************!*\
    !*** ./src/app/shared/models/purchase-info.model.ts ***!
    \******************************************************/

  /*! exports provided: PurchaseInfo */

  /***/
  function srcAppSharedModelsPurchaseInfoModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PurchaseInfo", function () {
      return PurchaseInfo;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var PurchaseInfo = function PurchaseInfo() {
      _classCallCheck(this, PurchaseInfo);
    };
    /***/

  },

  /***/
  "./src/app/shared/models/purchase.model.ts":
  /*!*************************************************!*\
    !*** ./src/app/shared/models/purchase.model.ts ***!
    \*************************************************/

  /*! exports provided: Purchase */

  /***/
  function srcAppSharedModelsPurchaseModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Purchase", function () {
      return Purchase;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var Purchase = function Purchase() {
      _classCallCheck(this, Purchase);
    };
    /***/

  },

  /***/
  "./src/app/shared/models/sale-info.model.ts":
  /*!**************************************************!*\
    !*** ./src/app/shared/models/sale-info.model.ts ***!
    \**************************************************/

  /*! exports provided: SaleInfo */

  /***/
  function srcAppSharedModelsSaleInfoModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SaleInfo", function () {
      return SaleInfo;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var SaleInfo = function SaleInfo() {
      _classCallCheck(this, SaleInfo);
    };
    /***/

  },

  /***/
  "./src/app/shared/models/sale.model.ts":
  /*!*********************************************!*\
    !*** ./src/app/shared/models/sale.model.ts ***!
    \*********************************************/

  /*! exports provided: Sale */

  /***/
  function srcAppSharedModelsSaleModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Sale", function () {
      return Sale;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var Sale = function Sale() {
      _classCallCheck(this, Sale);

      this.DiscountInPercent = 0.0;
      this.Offers = 0;
    };
    /***/

  },

  /***/
  "./src/app/shared/models/stock.model.ts":
  /*!**********************************************!*\
    !*** ./src/app/shared/models/stock.model.ts ***!
    \**********************************************/

  /*! exports provided: Stock */

  /***/
  function srcAppSharedModelsStockModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Stock", function () {
      return Stock;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var Stock = function Stock() {
      _classCallCheck(this, Stock);
    };
    /***/

  },

  /***/
  "./src/app/shared/models/supplier.model.ts":
  /*!*************************************************!*\
    !*** ./src/app/shared/models/supplier.model.ts ***!
    \*************************************************/

  /*! exports provided: Supplier */

  /***/
  function srcAppSharedModelsSupplierModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Supplier", function () {
      return Supplier;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var Supplier = function Supplier() {
      _classCallCheck(this, Supplier);
    };
    /***/

  },

  /***/
  "./src/app/shared/models/trx-record.model.ts":
  /*!***************************************************!*\
    !*** ./src/app/shared/models/trx-record.model.ts ***!
    \***************************************************/

  /*! exports provided: TrxRecord */

  /***/
  function srcAppSharedModelsTrxRecordModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TrxRecord", function () {
      return TrxRecord;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var TrxRecord = function TrxRecord() {
      _classCallCheck(this, TrxRecord);
    };
    /***/

  },

  /***/
  "./src/app/shared/services/common.service.ts":
  /*!***************************************************!*\
    !*** ./src/app/shared/services/common.service.ts ***!
    \***************************************************/

  /*! exports provided: CommonService */

  /***/
  function srcAppSharedServicesCommonServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CommonService", function () {
      return CommonService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var CommonService =
    /*#__PURE__*/
    function () {
      function CommonService() {
        _classCallCheck(this, CommonService);

        this.apiURL = "http://localhost:60842/r/";
      }

      _createClass(CommonService, [{
        key: "getApiURL",
        value: function getApiURL() {
          return this.apiURL;
        }
      }, {
        key: "datePipeISO",
        value: function datePipeISO(date) {
          var temp = String(date.getUTCFullYear());
          temp += "-";
          temp += this.fixZero(date.getMonth() + 1);
          temp += "-";
          temp += this.fixZero(date.getDate());
          temp += "T";
          temp += this.fixZero(date.getHours());
          temp += ":";
          temp += this.fixZero(date.getMinutes());
          return temp;
        }
      }, {
        key: "fixZero",
        value: function fixZero(val) {
          if (val < 10) {
            return "0" + String(val);
          } else {
            return String(val);
          }
        }
      }, {
        key: "generateInvoice",
        value: function generateInvoice(saleInfo) {
          var invoice = "C";
          invoice += String(saleInfo.SaleDate.getFullYear());
          invoice += String(saleInfo.SaleDate.getMonth());
          invoice += String(saleInfo.SaleDate.getDate());
          invoice += String(saleInfo.SaleDate.getHours());
          invoice += String(saleInfo.SaleDate.getMinutes());
          invoice += "R";
          invoice += String(saleInfo.CustomerName);
          return invoice;
        }
      }, {
        key: "dateTimeToDateOnly",
        value: function dateTimeToDateOnly(date) {
          var result = "";
          result += String(date.getFullYear());
          result += "-";
          result += this.fixZero(date.getMonth() + 1);
          result += "-";
          result += this.fixZero(date.getDate());
          return result;
        }
      }]);

      return CommonService;
    }();

    CommonService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], CommonService);
    /***/
  },

  /***/
  "./src/app/side-menu/side-menu.component.css":
  /*!***************************************************!*\
    !*** ./src/app/side-menu/side-menu.component.css ***!
    \***************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSideMenuSideMenuComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "/* Fixed sidenav, full height */\r\n\r\n.sidenav {\r\n  height: 100%;\r\n  width: 280px;\r\n  position: fixed;\r\n  z-index: 1;\r\n  top: 0;\r\n  left: 0;\r\n  background-color: #000;\r\n  overflow-x: hidden;\r\n  padding-top: 20px;\r\n}\r\n\r\n/* Style the sidenav links and the dropdown button */\r\n\r\n.sidenav a, .dropdown-btn {\r\n  padding: 6px 8px 6px 16px;\r\n  text-decoration: none;\r\n  font-size: 16px;\r\n  color: #818181;\r\n  display: block;\r\n  border: none;\r\n  background: none;\r\n  width: 100%;\r\n  text-align: left;\r\n  cursor: pointer;\r\n  outline: none;\r\n}\r\n\r\n/* On mouse-over */\r\n\r\n.sidenav a:hover, .dropdown-btn:hover {\r\n  color: #f1f1f1;\r\n}\r\n\r\n/* Main content */\r\n\r\n.main {\r\n  margin-left: 280px;\r\n  /* Same as the width of the sidenav */\r\n  font-size: 16px;\r\n  /* Increased text to enable scrolling */\r\n  padding: 0px 10px;\r\n}\r\n\r\n/* Add an active class to the active dropdown button */\r\n\r\n.active {\r\n  background-color: green;\r\n  color: white;\r\n}\r\n\r\n/* Dropdown container (hidden by default). Optional: add a lighter background color and some left padding to change the design of the dropdown content */\r\n\r\n.dropdown-container {\r\n  display: none;\r\n  background-color: #262626;\r\n  padding-left: 32px;\r\n}\r\n\r\n/* Optional: Style the caret down icon */\r\n\r\n.fa-caret-down {\r\n  float: right;\r\n  padding-right: 8px;\r\n}\r\n\r\n.fa {\r\n  margin-right: 16px;\r\n  width: 16px;\r\n}\r\n\r\n.logo {\r\n  background-color: black;\r\n  text-align: center;\r\n  margin-bottom: 24px;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2lkZS1tZW51L3NpZGUtbWVudS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLCtCQUErQjs7QUFFL0I7RUFDRSxZQUFZO0VBQ1osWUFBWTtFQUNaLGVBQWU7RUFDZixVQUFVO0VBQ1YsTUFBTTtFQUNOLE9BQU87RUFDUCxzQkFBc0I7RUFDdEIsa0JBQWtCO0VBQ2xCLGlCQUFpQjtBQUNuQjs7QUFFQSxvREFBb0Q7O0FBRXBEO0VBQ0UseUJBQXlCO0VBQ3pCLHFCQUFxQjtFQUNyQixlQUFlO0VBQ2YsY0FBYztFQUNkLGNBQWM7RUFDZCxZQUFZO0VBQ1osZ0JBQWdCO0VBQ2hCLFdBQVc7RUFDWCxnQkFBZ0I7RUFDaEIsZUFBZTtFQUNmLGFBQWE7QUFDZjs7QUFFQSxrQkFBa0I7O0FBRWxCO0VBQ0UsY0FBYztBQUNoQjs7QUFFQSxpQkFBaUI7O0FBRWpCO0VBQ0Usa0JBQWtCO0VBQ2xCLHFDQUFxQztFQUNyQyxlQUFlO0VBQ2YsdUNBQXVDO0VBQ3ZDLGlCQUFpQjtBQUNuQjs7QUFFQSxzREFBc0Q7O0FBRXREO0VBQ0UsdUJBQXVCO0VBQ3ZCLFlBQVk7QUFDZDs7QUFFQSx3SkFBd0o7O0FBRXhKO0VBQ0UsYUFBYTtFQUNiLHlCQUF5QjtFQUN6QixrQkFBa0I7QUFDcEI7O0FBRUEsd0NBQXdDOztBQUV4QztFQUNFLFlBQVk7RUFDWixrQkFBa0I7QUFDcEI7O0FBRUE7RUFDRSxrQkFBa0I7RUFDbEIsV0FBVztBQUNiOztBQUVBO0VBQ0UsdUJBQXVCO0VBQ3ZCLGtCQUFrQjtFQUNsQixtQkFBbUI7QUFDckIiLCJmaWxlIjoic3JjL2FwcC9zaWRlLW1lbnUvc2lkZS1tZW51LmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBGaXhlZCBzaWRlbmF2LCBmdWxsIGhlaWdodCAqL1xyXG5cclxuLnNpZGVuYXYge1xyXG4gIGhlaWdodDogMTAwJTtcclxuICB3aWR0aDogMjgwcHg7XHJcbiAgcG9zaXRpb246IGZpeGVkO1xyXG4gIHotaW5kZXg6IDE7XHJcbiAgdG9wOiAwO1xyXG4gIGxlZnQ6IDA7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzAwMDtcclxuICBvdmVyZmxvdy14OiBoaWRkZW47XHJcbiAgcGFkZGluZy10b3A6IDIwcHg7XHJcbn1cclxuXHJcbi8qIFN0eWxlIHRoZSBzaWRlbmF2IGxpbmtzIGFuZCB0aGUgZHJvcGRvd24gYnV0dG9uICovXHJcblxyXG4uc2lkZW5hdiBhLCAuZHJvcGRvd24tYnRuIHtcclxuICBwYWRkaW5nOiA2cHggOHB4IDZweCAxNnB4O1xyXG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbiAgY29sb3I6ICM4MTgxODE7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgYm9yZGVyOiBub25lO1xyXG4gIGJhY2tncm91bmQ6IG5vbmU7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgdGV4dC1hbGlnbjogbGVmdDtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgb3V0bGluZTogbm9uZTtcclxufVxyXG5cclxuLyogT24gbW91c2Utb3ZlciAqL1xyXG5cclxuLnNpZGVuYXYgYTpob3ZlciwgLmRyb3Bkb3duLWJ0bjpob3ZlciB7XHJcbiAgY29sb3I6ICNmMWYxZjE7XHJcbn1cclxuXHJcbi8qIE1haW4gY29udGVudCAqL1xyXG5cclxuLm1haW4ge1xyXG4gIG1hcmdpbi1sZWZ0OiAyODBweDtcclxuICAvKiBTYW1lIGFzIHRoZSB3aWR0aCBvZiB0aGUgc2lkZW5hdiAqL1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICAvKiBJbmNyZWFzZWQgdGV4dCB0byBlbmFibGUgc2Nyb2xsaW5nICovXHJcbiAgcGFkZGluZzogMHB4IDEwcHg7XHJcbn1cclxuXHJcbi8qIEFkZCBhbiBhY3RpdmUgY2xhc3MgdG8gdGhlIGFjdGl2ZSBkcm9wZG93biBidXR0b24gKi9cclxuXHJcbi5hY3RpdmUge1xyXG4gIGJhY2tncm91bmQtY29sb3I6IGdyZWVuO1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxufVxyXG5cclxuLyogRHJvcGRvd24gY29udGFpbmVyIChoaWRkZW4gYnkgZGVmYXVsdCkuIE9wdGlvbmFsOiBhZGQgYSBsaWdodGVyIGJhY2tncm91bmQgY29sb3IgYW5kIHNvbWUgbGVmdCBwYWRkaW5nIHRvIGNoYW5nZSB0aGUgZGVzaWduIG9mIHRoZSBkcm9wZG93biBjb250ZW50ICovXHJcblxyXG4uZHJvcGRvd24tY29udGFpbmVyIHtcclxuICBkaXNwbGF5OiBub25lO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICMyNjI2MjY7XHJcbiAgcGFkZGluZy1sZWZ0OiAzMnB4O1xyXG59XHJcblxyXG4vKiBPcHRpb25hbDogU3R5bGUgdGhlIGNhcmV0IGRvd24gaWNvbiAqL1xyXG5cclxuLmZhLWNhcmV0LWRvd24ge1xyXG4gIGZsb2F0OiByaWdodDtcclxuICBwYWRkaW5nLXJpZ2h0OiA4cHg7XHJcbn1cclxuXHJcbi5mYSB7XHJcbiAgbWFyZ2luLXJpZ2h0OiAxNnB4O1xyXG4gIHdpZHRoOiAxNnB4O1xyXG59XHJcblxyXG4ubG9nbyB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIG1hcmdpbi1ib3R0b206IDI0cHg7XHJcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/side-menu/side-menu.component.ts":
  /*!**************************************************!*\
    !*** ./src/app/side-menu/side-menu.component.ts ***!
    \**************************************************/

  /*! exports provided: SideMenuComponent */

  /***/
  function srcAppSideMenuSideMenuComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SideMenuComponent", function () {
      return SideMenuComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var SideMenuComponent =
    /*#__PURE__*/
    function () {
      function SideMenuComponent() {
        _classCallCheck(this, SideMenuComponent);
      }

      _createClass(SideMenuComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var dropdown = document.getElementsByClassName("dropdown-btn");
          var i;

          for (i = 0; i < dropdown.length; i++) {
            dropdown[i].addEventListener("click", function () {
              this.classList.toggle("active");
              var dropdownContent = this.nextElementSibling;

              if (dropdownContent.style.display === "block") {
                dropdownContent.style.display = "none";
              } else {
                dropdownContent.style.display = "block";
              } //* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */

            });
          }
        }
      }]);

      return SideMenuComponent;
    }();

    SideMenuComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-side-menu',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./side-menu.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/side-menu/side-menu.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./side-menu.component.css */
      "./src/app/side-menu/side-menu.component.css")).default]
    })], SideMenuComponent);
    /***/
  },

  /***/
  "./src/app/stocks/manage-stocks/manage-stocks.component.css":
  /*!******************************************************************!*\
    !*** ./src/app/stocks/manage-stocks/manage-stocks.component.css ***!
    \******************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppStocksManageStocksManageStocksComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3N0b2Nrcy9tYW5hZ2Utc3RvY2tzL21hbmFnZS1zdG9ja3MuY29tcG9uZW50LmNzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/stocks/manage-stocks/manage-stocks.component.ts":
  /*!*****************************************************************!*\
    !*** ./src/app/stocks/manage-stocks/manage-stocks.component.ts ***!
    \*****************************************************************/

  /*! exports provided: ManageStocksComponent */

  /***/
  function srcAppStocksManageStocksManageStocksComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ManageStocksComponent", function () {
      return ManageStocksComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");

    var ManageStocksComponent =
    /*#__PURE__*/
    function () {
      function ManageStocksComponent(http, cs) {
        _classCallCheck(this, ManageStocksComponent);

        this.http = http;
        this.cs = cs;
      }

      _createClass(ManageStocksComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this50 = this;

          this.http.get(this.cs.getApiURL() + "Stocks/GetProductsCounts").subscribe(function (data) {
            _this50.modelData = data; // console.log(data);
          }, function (error) {
            console.log(error);
          });
        }
      }, {
        key: "editProduct",
        value: function editProduct(stockCode) {
          console.log(stockCode);
        }
      }, {
        key: "deleteProduct",
        value: function deleteProduct(stockCode) {
          // this.http.delete(this.cs.getApiURL() + "Stocks/DeleteStockInfo/" + stockCode).subscribe(
          //   data => {
          //     alert("Data Deletion Successful");
          //     this.ngOnInit()
          //   },
          //   error => {
          //     alert("Error Occurred");
          //   }
          // );
          console.log("Deleted! fake.");
        }
      }]);

      return ManageStocksComponent;
    }();

    ManageStocksComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__["CommonService"]
      }];
    };

    ManageStocksComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-manage-stocks',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./manage-stocks.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/stocks/manage-stocks/manage-stocks.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./manage-stocks.component.css */
      "./src/app/stocks/manage-stocks/manage-stocks.component.css")).default]
    })], ManageStocksComponent);
    /***/
  },

  /***/
  "./src/app/suppliers/add-supplier/add-supplier.component.css":
  /*!*******************************************************************!*\
    !*** ./src/app/suppliers/add-supplier/add-supplier.component.css ***!
    \*******************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSuppliersAddSupplierAddSupplierComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3N1cHBsaWVycy9hZGQtc3VwcGxpZXIvYWRkLXN1cHBsaWVyLmNvbXBvbmVudC5jc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/suppliers/add-supplier/add-supplier.component.ts":
  /*!******************************************************************!*\
    !*** ./src/app/suppliers/add-supplier/add-supplier.component.ts ***!
    \******************************************************************/

  /*! exports provided: AddSupplierComponent */

  /***/
  function srcAppSuppliersAddSupplierAddSupplierComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AddSupplierComponent", function () {
      return AddSupplierComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var src_app_shared_models_supplier_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/shared/models/supplier.model */
    "./src/app/shared/models/supplier.model.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");

    var AddSupplierComponent =
    /*#__PURE__*/
    function () {
      function AddSupplierComponent(router, http, cs) {
        _classCallCheck(this, AddSupplierComponent);

        this.router = router;
        this.http = http;
        this.cs = cs;
        this.model = new src_app_shared_models_supplier_model__WEBPACK_IMPORTED_MODULE_3__["Supplier"]();
      }

      _createClass(AddSupplierComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "onSubmit",
        value: function onSubmit() {
          console.log(this.model);
          this.http.post(this.cs.getApiURL() + "Suppliers/PostSupplierInfo", this.model).subscribe(function (data) {
            alert("Data Entry Success!");
          }, function (error) {
            alert("Failed. Try agin please!");
          });
          this.router.navigate(['/dashboard']);
        }
      }]);

      return AddSupplierComponent;
    }();

    AddSupplierComponent.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"]
      }];
    };

    AddSupplierComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-add-supplier',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./add-supplier.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/suppliers/add-supplier/add-supplier.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./add-supplier.component.css */
      "./src/app/suppliers/add-supplier/add-supplier.component.css")).default]
    })], AddSupplierComponent);
    /***/
  },

  /***/
  "./src/app/suppliers/manage-suppliers/manage-suppliers.component.css":
  /*!***************************************************************************!*\
    !*** ./src/app/suppliers/manage-suppliers/manage-suppliers.component.css ***!
    \***************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSuppliersManageSuppliersManageSuppliersComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3N1cHBsaWVycy9tYW5hZ2Utc3VwcGxpZXJzL21hbmFnZS1zdXBwbGllcnMuY29tcG9uZW50LmNzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/suppliers/manage-suppliers/manage-suppliers.component.ts":
  /*!**************************************************************************!*\
    !*** ./src/app/suppliers/manage-suppliers/manage-suppliers.component.ts ***!
    \**************************************************************************/

  /*! exports provided: ManageSuppliersComponent */

  /***/
  function srcAppSuppliersManageSuppliersManageSuppliersComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ManageSuppliersComponent", function () {
      return ManageSuppliersComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/shared/services/common.service */
    "./src/app/shared/services/common.service.ts");

    var ManageSuppliersComponent =
    /*#__PURE__*/
    function () {
      function ManageSuppliersComponent(http, cs) {
        _classCallCheck(this, ManageSuppliersComponent);

        this.http = http;
        this.cs = cs;
      }

      _createClass(ManageSuppliersComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this51 = this;

          this.http.get(this.cs.getApiURL() + "Suppliers/GetSupplierInfoes").subscribe(function (data) {
            _this51.modelData = data;
            console.log(data);
          }, function (error) {
            console.log(error);
          });
        }
      }, {
        key: "editSupplier",
        value: function editSupplier(supplierCode) {
          console.log(supplierCode);
        }
      }, {
        key: "deleteSupplier",
        value: function deleteSupplier(supplierCode) {
          var _this52 = this;

          this.http.delete(this.cs.getApiURL() + "Suppliers/DeleteSupplierInfo/" + supplierCode).subscribe(function (data) {
            alert("Data Deletion Successful");

            _this52.ngOnInit();
          }, function (error) {
            alert("Error Occurred");
          });
        }
      }]);

      return ManageSuppliersComponent;
    }();

    ManageSuppliersComponent.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: src_app_shared_services_common_service__WEBPACK_IMPORTED_MODULE_3__["CommonService"]
      }];
    };

    ManageSuppliersComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-manage-suppliers',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./manage-suppliers.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/suppliers/manage-suppliers/manage-suppliers.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./manage-suppliers.component.css */
      "./src/app/suppliers/manage-suppliers/manage-suppliers.component.css")).default]
    })], ManageSuppliersComponent);
    /***/
  },

  /***/
  "./src/app/test/test/test.component.css":
  /*!**********************************************!*\
    !*** ./src/app/test/test/test.component.css ***!
    \**********************************************/

  /*! exports provided: default */

  /***/
  function srcAppTestTestTestComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3Rlc3QvdGVzdC90ZXN0LmNvbXBvbmVudC5jc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/test/test/test.component.ts":
  /*!*********************************************!*\
    !*** ./src/app/test/test/test.component.ts ***!
    \*********************************************/

  /*! exports provided: TestComponent */

  /***/
  function srcAppTestTestTestComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TestComponent", function () {
      return TestComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var TestComponent =
    /*#__PURE__*/
    function () {
      function TestComponent() {
        _classCallCheck(this, TestComponent);
      }

      _createClass(TestComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return TestComponent;
    }();

    TestComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-test',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./test.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/test/test/test.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./test.component.css */
      "./src/app/test/test/test.component.css")).default]
    })], TestComponent);
    /***/
  },

  /***/
  "./src/environments/environment.ts":
  /*!*****************************************!*\
    !*** ./src/environments/environment.ts ***!
    \*****************************************/

  /*! exports provided: environment */

  /***/
  function srcEnvironmentsEnvironmentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "environment", function () {
      return environment;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js"); // This file can be replaced during build by using the `fileReplacements` array.
    // `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
    // The list of file replacements can be found in `angular.json`.


    var environment = {
      production: false
    };
    /*
     * For easier debugging in development mode, you can import the following file
     * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
     *
     * This import should be commented out in production mode because it will have a negative impact
     * on performance if an error is thrown.
     */
    // import 'zone.js/dist/zone-error';  // Included with Angular CLI.

    /***/
  },

  /***/
  "./src/main.ts":
  /*!*********************!*\
    !*** ./src/main.ts ***!
    \*********************/

  /*! no exports provided */

  /***/
  function srcMainTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/platform-browser-dynamic */
    "./node_modules/@angular/platform-browser-dynamic/fesm2015/platform-browser-dynamic.js");
    /* harmony import */


    var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./app/app.module */
    "./src/app/app.module.ts");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./environments/environment */
    "./src/environments/environment.ts");

    if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
      Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
    }

    Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"]).catch(function (err) {
      console.log("Hi");
      console.error(err);
    });
    /***/
  },

  /***/
  0:
  /*!***************************!*\
    !*** multi ./src/main.ts ***!
    \***************************/

  /*! no static exports found */

  /***/
  function _(module, exports, __webpack_require__) {
    module.exports = __webpack_require__(
    /*! C:\Users\ra1h4\source\repos\ElectronERP\ElectronERP\ClientNg\src\main.ts */
    "./src/main.ts");
    /***/
  }
}, [[0, "runtime", "vendor"]]]);
//# sourceMappingURL=main-es5.js.map